class CfgRemoteExec
{
	class Functions
	{
		mode =2;
		jip = 0;
		class fnc_AdminReq { allowedTargets=2; };	// infiSTAR AntiHack
		class fn_xm8apps_server { allowedTargets=2; };	// infiSTAR xm8apps
		class ExileServer_system_network_dispatchIncomingMessage { allowedTargets=2; };	// ExileMod
	};
	class Commands
	{
		mode=2;
		jip=0;
		
		//TEST GOM_fnc_handleResources
	    class GOM_fnc_handleResources                            { allowedTargets = 2;};		
	    class SetPylonLoadout									 { allowedTargets = 2;};
	    class SetAmmoOnPylon									 { allowedTargets = 2;};
	    class removeWeaponGlobal								 { allowedTargets = 2;};
	    class setPylonsPriority									 { allowedTargets = 2;};
	    class setFuelCargo                                       { allowedTargets = 2;};
	    class setAmmoCargo                                       { allowedTargets = 2;};
	    class setRepairCargo                                     { allowedTargets = 2;};
	    class setFuel                                            { allowedTargets = 2;};
	};
};