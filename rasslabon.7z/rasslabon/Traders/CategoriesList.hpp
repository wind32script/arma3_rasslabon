//CategoriesList.hpp

	class Community
	{
		name = "Community Items";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\uniform_ca.paa";
		items[] =
		{
			// Add your items here <3
		};
	};

	class Community2
	{
		name = "Community Items 2";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\uniform_ca.paa";
		items[] =
		{
			// Add your items here <3
		};
	};

	class Community3
	{
		name = "Community Items 3";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\uniform_ca.paa";
		items[] =
		{
			// Add your items here <3
		};
	};

	class Community4
	{
		name = "Community Items 4";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\uniform_ca.paa";
		items[] =
		{
			// Add your items here <3
		};
	};

	class Community5
	{
		name = "Community Items 5";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\uniform_ca.paa";
		items[] =
		{
			// Add your items here <3
		};
	};

	class Community6
	{
		name = "Community Items 6";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\uniform_ca.paa";
		items[] =
		{
			// Add your items here <3
		};
	};

	class Community7
	{
		name = "Community Items 7";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\uniform_ca.paa";
		items[] =
		{
			// Add your items here <3
		};
	};

	class Community8
	{
		name = "Community Items 8";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\uniform_ca.paa";
		items[] =
		{
			// Add your items here <3
		};
	};

	class Community9
	{
		name = "Community Items 9";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\uniform_ca.paa";
		items[] =
		{
			// Add your items here <3
		};
	};

	class Community10
	{
		name = "Community Items 10";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\uniform_ca.paa";
		items[] =
		{
			// Add your items here <3
		};
	};
	
	
//////////////////////////////////////КЕПКИ Шлемы///////////////////////////////////////////
class contactheadgear
	{
		name = "Contact Headgear";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"H_MilCap_grn",
			"H_MilCap_wdl",
			"H_MilCap_taiga",
			"H_MilCap_eaf",
			"H_PilotHelmetFighter_I_E",
			"H_Beret_EAF_01_F",
			"H_Booniehat_mgrn",
			"H_Booniehat_wdl",
			"H_Booniehat_taiga",
			"H_Booniehat_eaf",
			"H_Tank_eaf_F",
			"H_HelmetCrew_I_E",
			"H_PilotHelmetHeli_I_E",
			"H_CrewHelmetHeli_I_E",
			"H_Hat_Tinfoil_F",
			"H_HelmetB_light_wdl",
			"H_HelmetSpecB_wdl",
			"H_HelmetHBK_headset_F",
			"H_HelmetHBK_chops_F",
			"H_HelmetHBK_ear_F",
			"H_HelmetHBK_F",
			"H_HelmetAggressor_F",
			"H_HelmetAggressor_cover_taiga_F",
			"H_HelmetAggressor_cover_F",
			"H_HelmetB_plain_wdl",
			"H_HelmetO_ViperSP_hex_F",
			"H_HelmetO_ViperSP_ghex_F"
		};
	};
	
/////////////////////////////////////////////НАМОРДНИКИ////////////////////////////////////
class contactglasses
	{
		name = "Contact Glasses";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"G_Blindfold_01_white_F",
			"G_Blindfold_01_black_F",
			"G_RegulatorMask_F",
			"G_AirPurifyingRespirator_02_olive_F",
			"G_AirPurifyingRespirator_02_sand_F",
			"G_AirPurifyingRespirator_02_black_F",
			"G_AirPurifyingRespirator_01_F"
		};
	};	
	
/////////////////////////////////ЖИЛЕТЫ///////////////////////////////////////////////
class contactvests
	{
		name = "Contact Vests";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"V_SmershVest_01_F",
			"V_SmershVest_01_radio_F",
			"V_PlateCarrierGL_wdl",
			"V_CarrierRigKBT_01_heavy_EAF_F",
			"V_CarrierRigKBT_01_heavy_olive_F",
			"V_CarrierRigKBT_01_light_EAF_F",
			"V_CarrierRigKBT_01_light_olive_F",
			"V_CarrierRigKBT_01_EAF_F",
			"V_CarrierRigKBT_01_olive_F",
			"V_PlateCarrier1_wdl",
			"V_PlateCarrier2_wdl",
			"V_PlateCarrierSpec_wdl"
		};
	};

////////////////////////////////////ОДЕЖДА//////////////////////////////////////////////
class contactuniforms
	{
		name = "Contact Uniforms";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"U_I_L_Uniform_01_camo_F",
			"U_I_L_Uniform_01_deserter_F",
			"U_C_Uniform_Farmer_01_F",
			"U_C_E_LooterJacket_01_F",
			"U_I_L_Uniform_01_tshirt_olive_F",
			"U_I_L_Uniform_01_tshirt_sport_F",
			"U_I_L_Uniform_01_tshirt_skull_F",
			"U_I_L_Uniform_01_tshirt_black_F",
			"U_I_E_Uniform_01_coveralls_F",
			"U_O_R_Gorka_01_F",
			"U_O_R_Gorka_01_brown_F",
			"U_O_R_Gorka_01_camo_F",
			"U_C_Uniform_Scientist_02_formal_F",
			"U_C_Uniform_Scientist_02_F",
			"U_C_Uniform_Scientist_01_F",
			"U_C_Uniform_Scientist_01_formal_F",
			"U_B_CombatUniform_mcam_wdl_f",
			"U_B_CombatUniform_tshirt_mcam_wdL_f",
			"U_I_E_Uniform_01_tanktop_F",
			"U_I_E_Uniform_01_officer_F",
			"U_I_E_Uniform_01_sweater_F",
			"U_I_E_Uniform_01_shortsleeve_F",
			"U_I_E_Uniform_01_F",
			"U_O_R_Gorka_01_black_F",
			"U_B_CombatUniform_vest_mcam_wdl_f",
			"U_C_CBRN_Suit_01_White_F",
			"U_B_CBRN_Suit_01_Wdl_F",
			"U_C_CBRN_Suit_01_Blue_F",
			"U_B_CBRN_Suit_01_Tropic_F",
			"U_B_CBRN_Suit_01_MTP_F",
			"U_I_E_CBRN_Suit_01_EAF_F",
			"U_I_CBRN_Suit_01_AAF_F"
		};
	};

//////////////////////////////////////////////////////////РЮКЗАКИ///////////////////////////////////////////////
class contactbackpacks
	{
		name = "Contact Backpacks";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"B_SCBA_01_F",
			"B_CombinationUnitRespirator_01_F",
			"B_FieldPack_green_F",
			"B_FieldPack_taiga_F",
			"B_RadioBag_01_hex_F",
			"B_RadioBag_01_eaf_F",
			"B_RadioBag_01_oucamo_F",
			"B_RadioBag_01_ghex_F",
			"B_RadioBag_01_wdl_F",
			"B_RadioBag_01_tropic_F",
			"B_RadioBag_01_digi_F",
			"B_RadioBag_01_black_F",
			"B_RadioBag_01_mtp_F",
			"B_Carryall_eaf_F",
			"B_Carryall_green_F",
			"B_Carryall_wdl_F",
			"B_Carryall_taiga_F",
			"B_AssaultPack_eaf_F",
			"B_AssaultPack_wdl_F"
		};
	};	
	
//////////////////////////////////////////////////РЮКЗАКИ-БЕСПИЛОТНИКИ/////////////////////////////////////////////
class contactbackpacksuav
	{
		name = "Contact UAVs";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"C_IDAP_UGV_02_Demining_backpack_F",
			"I_E_UGV_02_Demining_backpack_F",
			"B_UGV_02_Demining_backpack_F",
			"I_UGV_02_Demining_backpack_F",
			"O_UGV_02_Demining_backpack_F",
			"I_E_UGV_02_Science_backpack_F",
			"B_UGV_02_Science_backpack_F",
			"I_UGV_02_Science_backpack_F",
			"O_UGV_02_Science_backpack_F",
			"I_E_UAV_06_backpack_F",
			"I_E_UAV_06_medical_backpack_F",
			"I_E_UAV_01_backpack_F"
		};
	};
	
////////////////////////////////////////////ОРУЖИЕ/////////////////////////////////////////////////////////////////////
class contactweapons
	{
		name = "Contact Weapons";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"hgun_Pistol_heavy_01_green_F",
			"sgun_HunterShotgun_01_F",
			"sgun_HunterShotgun_01_sawedoff_F",
			"srifle_DMR_06_hunter_F",
			"arifle_AK12U_F",
			"arifle_AK12U_lush_f",
			"arifle_AK12U_arid_f",
			"arifle_MSBS65_black_F",
			"arifle_MSBS65_Mark_F",
			"arifle_MSBS65_Mark_camo_F",
			"arifle_MSBS65_Mark_sand_F",
			"arifle_MSBS65_Mark_black_F",
			"arifle_MSBS65_GL_F",
			"arifle_MSBS65_GL_camo_F",
			"arifle_MSBS65_GL_sand_F",
			"arifle_MSBS65_GL_black_F",
			"arifle_AK12_lush_f",
			"arifle_AK12_arid_f",
			"arifle_AK12_GL_lush_F",
			"arifle_AK12_GL_arid_F",
			"arifle_MSBS65_UBS_F",
			"arifle_MSBS65_UBS_camo_F",
			"arifle_MSBS65_UBS_sand_F",
			"arifle_MSBS65_UBS_black_F",
			"arifle_RPK12_F",
			"arifle_RPK12_lush_f",
			"arifle_RPK12_arid_f",
			"LMG_Mk200_black_F"
		};
	};	

//////////////////////////////////////////////////////////////ПАТРОНЫ//////////////////////////////////////////////////////
class contactammo
	{
		name = "Contact Ammo";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"30rnd_762x39_AK12_Lush_Mag_F",
			"30rnd_762x39_AK12_Lush_Mag_Tracer_F",
			"30Rnd_762x39_AK12_Mag_F",
			"30Rnd_762x39_AK12_Mag_Tracer_F",
			"30rnd_762x39_AK12_Arid_Mag_F",
			"30rnd_762x39_AK12_Arid_Mag_Tracer_F",
			"75rnd_762x39_AK12_Mag_F",
			"75rnd_762x39_AK12_Mag_Tracer_F",
			"75rnd_762x39_AK12_Lush_Mag_F",
			"75rnd_762x39_AK12_Lush_Mag_Tracer_F",
			"75rnd_762x39_AK12_Arid_Mag_F",
			"75rnd_762x39_AK12_Arid_Mag_Tracer_F",
			"2Rnd_12Gauge_Pellets",
			"2Rnd_12Gauge_Slug",
			"200Rnd_65x39_cased_Box_Red",
			"200Rnd_65x39_cased_Box_Tracer_Red",
			//"200Rnd_65x39_cased_box_blank",
			"30Rnd_65x39_caseless_msbs_mag",
			"30Rnd_65x39_caseless_msbs_mag_Tracer",
			//"30Rnd_65x39_caseless_msbs_blank_mag",
			"6Rnd_12Gauge_Slug",
			"6Rnd_12Gauge_Pellets"
		};
	};

////////////////////////////////////////////////////////ПУСКОВЫЕ УСТАНОВКИ///////////////////////////////////
class contaclaunchers
	{
		name = "Contact Launchers";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"launch_RPG32_green_F",
			"launch_I_Titan_eaf_F",
			"launch_B_Titan_olive_F"
		};
	};	
	
/////////////////////////////////////////////////////////ВЫСТРЕЛЫ К ПУ///////////////////////////////////////////	
class contaclaunchersammo
	{
		name = "Contact Launchers Ammo";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"RPG32_F",
			"RPG32_HE_F",
			"Titan_AA"
		};
	};	
	
/////////////////////////////////////////////////////////НАВЕСНОЕ///////////////////////////////////////////////////
class contactgadgets
	{
		name = "Contact Weapon's Gadgets";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"muzzle_snds_B_lush_F",
			"muzzle_snds_B_arid_F",
			"optic_Holosight_lush_F",
			"optic_Holosight_arid_F",
			"optic_ico_01_f",
			"optic_ico_01_camo_f",
			"optic_ico_01_sand_f",
			"optic_ico_01_black_f",
			"optic_Arco_lush_F",
			"optic_Arco_arid_F",
			"optic_Arco_AK_lush_F",
			"optic_Arco_AK_arid_F",
			"optic_Arco_AK_blk_F",
			"optic_DMS_weathered_F",
			"optic_DMS_weathered_Kir_F",
			"optic_MRD_black",
			"bipod_02_F_lush",
			"bipod_02_F_arid"
		};
	};	
/*	
class SnowWeapon
{
	name = "Зимние Оружие";
	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemmuzzle_ca.paa";
	items[] =
    {
        "WY_Snow_cheytac_m200_A",
        "WY_Snow_cheytac_m200_B",
        "WY_Snow_Rahim_a",		
        "WY_Snow_Rahim_b",		
        "WY_Snow_Mar10_a",		
        "WY_Snow_Mar10_b",		
        "WY_Snow_MK_I_EMR_a",	
        "WY_Snow_MK_I_EMR_b",	
        "WY_Snow_MMG_01_a",		
        "WY_Snow_MMG_01_b",		
        "WY_Snow_LMG_Zafir_F_a",	
        "WY_Snow_LMG_Zafir_F_b",	
        "WY_Snow_MX_F_a",		
        "WY_Snow_MX_F_b",		
        "WY_Snow_MXM_F_a",		

        "WY_Snow_GM6_F_a",		
        "WY_Snow_GM6_F_b",		
        "WY_Snow_GM6_F_c",		
        "WY_Snow_MMG_02_a",		
        "WY_Snow_MMG_02_b",		
        "WY_Snow_MMG_02_c"		
	};
};

class SnowVests
{
	name = "Зимнии Жилеты";
	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\vest_ca.paa";
	items[] =
    {
	    "WY_Vest_snow_a",	
        "WY_Vest_snow_b",	
        "WY_Vest_snow_c",	 
        "WY_Vest_snow_tact_a",
        "WY_Vest_snow_tact_b",
        "WY_Vest_snow_tact_c"
	};
};

class SnowHeadGears
{
	name = "Зимнии Головные уборы";
	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\headgear_ca.paa";
	items[] =
    {
	    "WY_Snow_Boonie_a",			
        "WY_Snow_Boonie_b",			
        "WY_Snow_Boonie_c",	        
        "WY_Snow_Boonie_d",			
        "WY_Snow_Boonie_e",			
        "WY_Snow_Boonie_f",	        

        "WY_Snow_Shemag_a",			
        "WY_Snow_Shemag_b",			
        "WY_Snow_Shemag_c",	        
        "WY_Snow_Shemag_d",			
        "WY_Snow_Shemag_e",			
        "WY_Snow_Shemag_f",	        

        "WY_Snow_PilotHelmetHeli_O",	
        "WY_Snow_CrewtHelmetHeli_O",	
        "WY_Snow_H_HelmetO_ocamo_a",	
        "WY_Snow_H_HelmetO_ocamo_b",	

        "WY_Snow_H_Watchcap_a",		
        "WY_Snow_H_Watchcap_b"
	};
};

class SnowBackpacks
{
	name = "Зимнии Рюкзаки";
	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\backpack_ca.paa";
	items[] =
    {
	    "WY_Snow_Carryall_A",	
        "WY_Snow_Carryall_B",	
        "WY_Snow_Carryall_C",	
        "WY_Snow_Carryall_D",	   
        "WY_Snow_Carryall_E",	
        "WY_Snow_Carryall_F",	

        "WY_Snow_AssoultPack_A",
        "WY_Snow_AssoultPack_B",
        "WY_Snow_AssoultPack_C",
        "WY_Snow_AssoultPack_D",
        "WY_Snow_AssoultPack_E"
	};
};

class SnowFacewear
{
	name = "Зимнии Маски для лица";
	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\headgear_ca.paa";
	items[] =
    {
	    "WY_Snow_G_Combat_a",			
        "WY_Snow_G_Combat_b",			
        "WY_Snow_G_Combat_c",	       
        "WY_Snow_G_Balaclava_combat_a",	
        "WY_Snow_G_Balaclava_combat_b",	
        "WY_Snow_G_Balaclava_combat_c",	
        "WY_Snow_G_Balaclava"
	};
};

class SnowUniforms
{
	name = "Зимния Униформа";
	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\uniform_ca.paa";
	items[] =
    {
	    "WY_Snow_co_a",			
        "WY_Snow_co_b",			     
        "WY_Snow_co_c",			
        "WY_GhillieFull_Night",	
        "WY_GhillieFull_Day",	
        "WY_GhillieLeo",			
        "WY_Snow_i_a",			
        "WY_Snow_i_b",			
        "WY_Snow_i_c",			
        "WY_Ghillie_coverall_a",	
        "WY_Ghillie_coverall_b"
	};
};

class SnowTransport
{
	name = "Зимний Транспорт";
	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
	items[] =
    {
	    "WY_Snow_Offroad_A",						   
        "WY_Snow_Offroad_B",					   
        "WY_Snow_Offroad_C",						   
        "WY_Snow_Offroad_armed_D",				   
        "WY_Snow_Offroad_armed_E",				   
        "WY_Snow_Offroad_F",						   

        "WY_Snow_Quadbike_F_A",						
        "WY_Snow_Quadbike_F_B",						
        "WY_Snow_Quadbike_F_C",	                   
        "WY_Snow_Quadbike_F_D",						
        "WY_Snow_Quadbike_F_E",						
        "WY_Snow_Quadbike_F_F",	                   

        "WY_Snow_B_MRAP_01_F_A",						
        "WY_Snow_B_MRAP_01_armed_F_B",				
        "WY_Snow_B_MRAP_01_F_C",						
        "WY_Snow_B_MRAP_01_F_D",						
        "WY_Snow_B_MRAP_01_armed_F_E",				
        "WY_Snow_B_MRAP_01_armed_F_F",				
        
        "WY_Snow_B_Truck_01_fuel_F_A",				
        "WY_Snow_B_Truck_01_fuel_F_B",				
        "WY_Snow_B_Truck_01_ammo_F_C",	           
        "WY_Snow_B_Truck_01_ammo_F_D",				
        "WY_Snow_B_Truck_01_mover_F_E",				
        "WY_Snow_B_Truck_01_mover_F_F",	           

        "WY_Snow_I_Truck_02_fuel_F_A",				
        "WY_Snow_I_Truck_02_fuel_F_B",				
        "WY_Snow_I_Truck_02_covered_F_C",	       
        "WY_Snow_I_Truck_02_covered_F_D",			
        "WY_Snow_I_Truck_02_transport_F_E",			
        "WY_Snow_I_Truck_02_transport_F_F",	       

        "WY_Snow_I_mrap_03_F_A",						
        "WY_Snow_I_mrap_03_F_B",						
        "WY_Snow_I_mrap_03_gmg_F_C",	               
        "WY_Snow_I_mrap_03_gmg_F_D",	

        "WY_Snow_O_APC_Wheeled_02_rcws_F_a",				   
        "WY_Snow_O_APC_Wheeled_02_rcws_F_b",	
        "WY_Snow_O_APC_Wheeled_02_rcws_F_c",	 

        "WY_Snow_O_MRAP_02_base_F_a",		
        "WY_Snow_O_MRAP_02_gmg_F_b",		
        "WY_Snow_O_MRAP_02_gmg_F_c"
	};
};

class SnowHeli
{
	name = "Зимнии Вертолёты";
	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
	items[] =
    {
	    "WY_Snow_B_Heli_Light_01_F_A",	
        "WY_Snow_B_Heli_Light_01_F_B",	         
        "WY_Snow_B_Heli_Light_01_F_C",	 

        "WY_Snow_B_Heli_Transport_01_F_A",
        "WY_Snow_B_Heli_Transport_01_F_B",
        "WY_Snow_B_Heli_Transport_01_F_C",
        
        "WY_Snow_B_Heli_Transport_03_F_A",
        "WY_Snow_B_Heli_Transport_03_F_B",
        "WY_Snow_B_Heli_Transport_03_F_C",

        "WY_Snow_I_Heli_light_03_unarmed_F_a",
        "WY_Snow_I_Heli_light_03_F_b",			
        "WY_Snow_I_Heli_light_03_F_c",	      

        "WY_Snow_O_Heli_Light_02_unarmed_F_a",
        "WY_Snow_O_Heli_Light_02_unarmed_F_b",
        "WY_Snow_O_Heli_Light_02_F_c"
	};
};

class SnowNVGoggles
{
	name = "Зимнии Ночники";
	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
	items[] =
    {
        "WY_Snow_NVGoggles"
	};
};
*/	
class ApexMuzzleAttachments
{
	name = "Apex Muzzle Attachments";
	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemmuzzle_ca.paa";
	items[] =
	{
		"muzzle_snds_58_blk_F",
		"muzzle_snds_58_wdm_F",
		"muzzle_snds_65_TI_blk_F",
		"muzzle_snds_65_TI_ghex_F",
		"muzzle_snds_65_TI_hex_F",
		"muzzle_snds_B_khk_F",
		"muzzle_snds_B_snd_F",
		"muzzle_snds_H_MG_blk_F",
		"muzzle_snds_H_MG_khk_F",
		"muzzle_snds_H_khk_F",
		"muzzle_snds_H_snd_F",
		"muzzle_snds_m_khk_F",
		"muzzle_snds_m_snd_F"
	};
};

class ApexAmmunition
{
	name = "Apex Ammunition";
	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
	items[] =
	{
		"100Rnd_580x42_Mag_F",
		"100Rnd_580x42_Mag_Tracer_F",
		"10Rnd_50BW_Mag_F",
		"10Rnd_9x21_Mag",
		"150Rnd_556x45_Drum_Mag_F",
		"150Rnd_556x45_Drum_Mag_Tracer_F",
		"200Rnd_556x45_Box_F",
		"200Rnd_556x45_Box_Red_F",
		"200Rnd_556x45_Box_Tracer_F",
		"200Rnd_556x45_Box_Tracer_Red_F",
		"20Rnd_650x39_Cased_Mag_F",
		"30Rnd_545x39_Mag_F",
		"30Rnd_545x39_Mag_Green_F",
		"30Rnd_545x39_Mag_Tracer_F",
		"30Rnd_545x39_Mag_Tracer_Green_F",
		"30Rnd_580x42_Mag_F",
		"30Rnd_580x42_Mag_Tracer_F",
		"30Rnd_762x39_Mag_F",
		"30Rnd_762x39_Mag_Green_F",
		"30Rnd_762x39_Mag_Tracer_F",
		"30Rnd_762x39_Mag_Tracer_Green_F",
		"30Rnd_9x21_Mag_SMG_02",
		"30Rnd_9x21_Mag_SMG_02_Tracer_Green",
		"30Rnd_9x21_Mag_SMG_02_Tracer_Red",
		"30Rnd_9x21_Mag_SMG_02_Tracer_Yellow"
	};
};

class APEXBipodAttachments
{
	name = "Apex Bipod Attachments";
	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
	items[] =
	{
		"bipod_01_F_khk"
	};
};

class ApexOpticAttachments
{
	name = "Apex Optic Attachments";
	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemoptic_ca.paa";
	items[] =
	{
		"optic_Arco_blk_F",
		"optic_Arco_ghex_F",
		"optic_DMS_ghex_F",
		"optic_ERCO_blk_F",
		"optic_ERCO_khk_F",
		"optic_ERCO_snd_F",
		"optic_Hamr_khk_F",
		"optic_Holosight_blk_F",
		"optic_Holosight_khk_F",
		"optic_Holosight_smg_blk_F",
		"optic_LRPS_ghex_F",
		"optic_LRPS_tna_F",
		"optic_SOS_khk_F"
	};
};

class ApexPistols
{
	name = "Apex Pistols";
	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\handgun_ca.paa";
	items[] =
	{
		"hgun_P07_khk_F",
		"hgun_Pistol_01_F"
	};
};

class ApexSubMachineGuns
{
	name = "Apex Sub Machine Guns";
	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
	items[] =
	{
		"SMG_05_F"
	};
};

class ApexLightMachineGuns
{
	name = "Apex Light Machine Guns";
	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
	items[] =
	{
		"LMG_03_F"
	};
};

    class ApexAssaultRifles
    {
	    name = "Apex Assault Rifles";
	    icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
	    items[] =
	    {
	    	"arifle_AK12_F",
	    	"arifle_AK12_GL_F",
	    	"arifle_AKM_F",
	    	"arifle_AKM_FL_F",
	    	"arifle_AKS_F",
	    	"arifle_ARX_blk_F",
	    	"arifle_ARX_ghex_F",
	    	"arifle_ARX_hex_F",
	    	"arifle_CTARS_blk_F",
	    	"arifle_CTARS_ghex_F",
	    	"arifle_CTARS_hex_F",
	    	"arifle_CTAR_GL_blk_F",
	    	"arifle_CTAR_blk_F",
	    	"arifle_CTAR_ghex_F",
	    	"arifle_CTAR_hex_F",
	    	"arifle_MXC_khk_F",
	    	"arifle_MXM_khk_F",
	    	"arifle_MX_GL_khk_F",
	    	"arifle_MX_khk_F",
	    	"arifle_SPAR_01_GL_blk_F",
	    	"arifle_SPAR_01_GL_khk_F",
	    	"arifle_SPAR_01_GL_snd_F",
	    	"arifle_SPAR_01_blk_F",
	    	"arifle_SPAR_01_khk_F",
	    	"arifle_SPAR_01_snd_F",
	    	"arifle_SPAR_03_blk_F",
	    	"arifle_SPAR_03_khk_F",
	    	"arifle_SPAR_03_snd_F"
	    	/*
	    	"arifle_SPAR_02_blk_F",		//Exile dupe warning
	    	"arifle_SPAR_02_khk_F",		//Exile dupe warning
	    	"arifle_SPAR_02_snd_F",		//Exile dupe warning
	    	*/
	    };
    };

    class ApexSniperRifles
    {
   	   name = "Apex Sniper Rifles";
   	   icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
   	   items[] =
   	    {
   	   	    "srifle_DMR_07_blk_F",
   	   	    "srifle_DMR_07_ghex_F",
   	   	    "srifle_DMR_07_hex_F",
   	   	    "srifle_GM6_ghex_F",
   	   	    "srifle_LRR_tna_F"
   	    };
    };

////////////////////////////////////////////////////////////////////////////////////////////////

	class CUPMuzzleAttachments
	{
		name = "CUP Muzzle Attachments";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemmuzzle_ca.paa";
		items[] =
		{
            "CUP_muzzle_PBS4",
            "CUP_muzzle_PB6P9",
            "CUP_muzzle_Bizon",
            "CUP_muzzle_snds_M110",
            "CUP_muzzle_snds_M14",
            "CUP_muzzle_snds_M9",
            "CUP_muzzle_snds_MicroUzi",
            "CUP_muzzle_snds_AWM",
            "CUP_muzzle_snds_G36_black",
            "CUP_muzzle_snds_G36_desert",
            "CUP_muzzle_snds_L85",
            "CUP_muzzle_snds_M16_camo",
            "CUP_muzzle_snds_M16",
            "CUP_muzzle_snds_SCAR_L",
            "CUP_muzzle_mfsup_SCAR_L",
            "CUP_muzzle_snds_SCAR_H",
            "CUP_muzzle_mfsup_SCAR_H",
            "CUP_muzzle_snds_XM8",
			"CUP_muzzle_mfsup_Suppressor_M107_Grey",
			"CUP_muzzle_mfsup_Suppressor_M107_Black",
			"CUP_muzzle_mfsup_Suppressor_M107_Woodland"
		};
	};

	class CUPOpticAttachments
	{
		name = "Optic Attachments";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemoptic_ca.paa";
		items[] =
		{
            "CUP_optic_PSO_1",
            "CUP_optic_PSO_3",
            "CUP_optic_Kobra",
            "CUP_optic_GOSHAWK",
            "CUP_optic_NSPU",
            "CUP_optic_PechenegScope",
            "CUP_optic_MAAWS_Scope",
            "CUP_optic_SMAW_Scope",
            "CUP_optic_AN_PAS_13c2",
            "CUP_optic_LeupoldMk4",
            "CUP_optic_HoloBlack",
            "CUP_optic_HoloWdl",
            "CUP_optic_HoloDesert",
            "CUP_optic_Eotech533",
            "CUP_optic_CompM4",
            "CUP_optic_SUSAT",
            "CUP_optic_ACOG",
            "CUP_optic_CWS",
            "CUP_optic_Leupold_VX3",
            "CUP_optic_AN_PVS_10",
            "CUP_optic_CompM2_Black",
            "CUP_optic_CompM2_Woodland",
            "CUP_optic_CompM2_Woodland2",
            "CUP_optic_CompM2_Desert",
            "CUP_optic_RCO",
            "CUP_optic_RCO_desert",
            "CUP_optic_LeupoldM3LR",
            "CUP_optic_LeupoldMk4_10x40_LRT_Desert",
            "CUP_optic_LeupoldMk4_10x40_LRT_Woodland",
            "CUP_optic_ElcanM145",
            "CUP_optic_AN_PAS_13c1",
            "CUP_optic_LeupoldMk4_CQ_T",
            "CUP_optic_ELCAN_SpecterDR",
            "CUP_optic_LeupoldMk4_MRT_tan",
            "CUP_optic_SB_11_4x20_PM",
            "CUP_optic_ZDDot",
            "CUP_optic_MRad",
            "CUP_optic_TrijiconRx01_desert",
            "CUP_optic_TrijiconRx01_black",
            "CUP_optic_AN_PVS_4"
		};
	};

	class CUPAmmunition
	{
		name = "CUP Ammunition";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"CUP_20Rnd_B_AA12_Pellets",
            "CUP_20Rnd_B_AA12_74Slug",
            "CUP_20Rnd_B_AA12_HE",
            "CUP_8Rnd_B_Beneli_74Slug",
            "CUP_8Rnd_B_Saiga12_74Slug_M",
            "CUP_8Rnd_9x18_Makarov_M",
            "CUP_8Rnd_9x18_MakarovSD_M",
            "CUP_15Rnd_9x19_M9",
            "CUP_18Rnd_9x19_Phantom",
            "CUP_6Rnd_45ACP_M",
            "CUP_17Rnd_9x19_glock17",
            "CUP_7Rnd_45ACP_1911",
            "CUP_10Rnd_9x19_Compact",
            "CUP_100Rnd_TE4_LRT4_White_Tracer_762x51_Belt_M",
            "CUP_200Rnd_TE4_Red_Tracer_556x45_M249",
            "CUP_200Rnd_TE4_Yellow_Tracer_556x45_M249",
            "CUP_200Rnd_TE1_Red_Tracer_556x45_M249",
            "CUP_100Rnd_TE4_Green_Tracer_556x45_M249",
            "CUP_100Rnd_TE4_Red_Tracer_556x45_M249",
            "CUP_100Rnd_TE4_Yellow_Tracer_556x45_M249",
            "CUP_200Rnd_TE4_Green_Tracer_556x45_L110A1",
            "CUP_200Rnd_TE4_Red_Tracer_556x45_L110A1",
            "CUP_200Rnd_TE4_Yellow_Tracer_556x45_L110A1",
            "CUP_50Rnd_UK59_762x54R_Tracer",
            "CUP_64Rnd_9x19_Bizon_M",
            "CUP_64Rnd_Green_Tracer_9x19_Bizon_M",
            "CUP_64Rnd_Red_Tracer_9x19_Bizon_M",
            "CUP_64Rnd_White_Tracer_9x19_Bizon_M",
            "CUP_64Rnd_Yellow_Tracer_9x19_Bizon_M",
            "CUP_30Rnd_9x19_EVO",
            "CUP_30Rnd_9x19_UZI",
            "CUP_30Rnd_9x19_MP5",
            "CUP_20Rnd_B_765x17_Ball_M",
            "CUP_5Rnd_127x99_as50_M",
            "CUP_5Rnd_86x70_L115A1",
            "CUP_10Rnd_762x51_CZ750_Tracer",
            "CUP_10Rnd_762x51_CZ750",
            "CUP_10x_303_M",
            "CUP_5Rnd_762x51_M24",
            "CUP_10Rnd_127x99_m107",
            "CUP_20Rnd_762x51_B_M110",
            "CUP_20Rnd_TE1_Yellow_Tracer_762x51_M110",
            "CUP_20Rnd_TE1_Red_Tracer_762x51_M110",
            "CUP_20Rnd_TE1_Green_Tracer_762x51_M110",
            "CUP_20Rnd_TE1_White_Tracer_762x51_M110",
            "CUP_10Rnd_762x54_SVD_M",
            "CUP_10Rnd_9x39_SP5_VSS_M",
            "CUP_20Rnd_9x39_SP5_VSS_M",
            "CUP_5x_22_LR_17_HMR_M",
            //"CUP_5Rnd_127x108_KSVK_M",
            "CUP_30Rnd_545x39_AK_M",
            "CUP_30Rnd_TE1_Green_Tracer_545x39_AK_M",
            "CUP_30Rnd_TE1_Red_Tracer_545x39_AK_M",
            "CUP_30Rnd_TE1_White_Tracer_545x39_AK_M",
            "CUP_30Rnd_TE1_Yellow_Tracer_545x39_AK_M",
            "CUP_75Rnd_TE4_LRT4_Green_Tracer_545x39_RPK_M",
            "CUP_30Rnd_762x39_AK47_M",
            "CUP_30Rnd_556x45_Stanag",
            "CUP_30Rnd_556x45_G36",
            "CUP_30Rnd_TE1_Red_Tracer_556x45_G36",
            "CUP_30Rnd_TE1_Green_Tracer_556x45_G36",
            "CUP_30Rnd_TE1_Yellow_Tracer_556x45_G36",
            "CUP_100Rnd_556x45_BetaCMag",
            "CUP_100Rnd_TE1_Red_Tracer_556x45_BetaCMag",
            "CUP_100Rnd_TE1_Green_Tracer_556x45_BetaCMag",
            "CUP_100Rnd_TE1_Yellow_Tracer_556x45_BetaCMag",
            "CUP_20Rnd_556x45_Stanag",
            "CUP_20Rnd_762x51_CZ805B",
            "CUP_20Rnd_TE1_Yellow_Tracer_762x51_CZ805B",
            "CUP_20Rnd_TE1_Red_Tracer_762x51_CZ805B",
            "CUP_20Rnd_TE1_Green_Tracer_762x51_CZ805B",
            "CUP_20Rnd_TE1_White_Tracer_762x51_CZ805B",
            "CUP_20Rnd_762x51_DMR",
            "CUP_20Rnd_TE1_Yellow_Tracer_762x51_DMR",
            "CUP_20Rnd_TE1_Red_Tracer_762x51_DMR",
            "CUP_20Rnd_TE1_Green_Tracer_762x51_DMR",
            "CUP_20Rnd_TE1_White_Tracer_762x51_DMR",
            "CUP_20Rnd_762x51_FNFAL_M",
            "CUP_30Rnd_Sa58_M_TracerG",
            "CUP_30Rnd_Sa58_M_TracerR",
            "CUP_30Rnd_Sa58_M_TracerY",
            "CUP_30Rnd_Sa58_M",
            "CUP_20Rnd_762x51_B_SCAR",
            "CUP_20Rnd_TE1_Yellow_Tracer_762x51_SCAR",
            "CUP_20Rnd_TE1_Red_Tracer_762x51_SCAR",
            "CUP_20Rnd_TE1_Green_Tracer_762x51_SCAR",
            "CUP_20Rnd_TE1_White_Tracer_762x51_SCAR"
		};
	};

	class CUPPistols
	{
		name = "CUP Pistols";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\handgun_ca.paa";
		items[] =
		{
            "CUP_hgun_Colt1911",
//         	"CUP_hgun_Colt1911_snds",
            "CUP_hgun_Compact",
//        	"CUP_hgun_Duty_M3X",
            "CUP_hgun_Glock17",
//      	"CUP_hgun_glock17_flashlight_snds",
//        	"CUP_hgun_glock17_snds",
//         	"CUP_hgun_glock17_flashlight",
            "CUP_hgun_M9",
//         	"CUP_hgun_M9_snds",
            "CUP_hgun_Makarov",
            "CUP_hgun_PB6P9",
//        	"CUP_hgun_PB6P9_snds",
            "CUP_hgun_MicroUzi",
//         	"CUP_hgun_MicroUzi_snds",
//       	"CUP_hgun_Phantom_Flashlight",
//        	"CUP_hgun_Phantom_Flashlight_snds",
            "CUP_hgun_TaurusTracker455",
            "CUP_hgun_TaurusTracker455_gold",
            "CUP_hgun_SA61",
            "CUP_hgun_Duty",
            "CUP_hgun_Phantom"
		};
	};

	class CUPSubMachineGuns
	{
		name = "CUP Sub Machine Guns";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
            "CUP_smg_bizon",
//       	"CUP_smg_bizon_snds",
            "CUP_smg_EVO",
//        	"CUP_smg_EVO_MRad_Flashlight",
//        	"CUP_smg_EVO_MRad_Flashlight_Snds",
            "CUP_smg_MP5SD6",
            "CUP_smg_MP5A5"
		};
	};

	class CUPLightMachineGuns
	{
		name = "CUP Light Machine Guns";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
            "CUP_lmg_L7A2",
            "CUP_lmg_L110A1",
//        	"CUP_lmg_L110A1_Aim_Laser",
//          "CUP_lmg_M60A4",
            "CUP_lmg_M240",
//      	"CUP_lmg_M240_ElcanM143",
            "CUP_lmg_M249",
            "CUP_lmg_M249_para",
//     		"CUP_lmg_M249_ElcanM145_Laser",
//          "CUP_lmg_M249_Laser",
//        	"CUP_lmg_M249_ANPAS13c2_Laser",
//        	"CUP_lmg_Mk48_des_Aim_Laser",
//      	"CUP_lmg_Mk48_wdl_Aim_Laser",
            "CUP_lmg_Mk48_des",
            "CUP_lmg_Mk48_wdl",
            "CUP_lmg_PKM",
//          "CUP_lmg_Pecheneg_PScope",
            "CUP_lmg_UK59",
            "CUP_lmg_Pecheneg"
		};
	};

	class CUPAssaultRifles
	{
		name = "CUP Assault Rifles";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
            "CUP_arifle_AK74",
            "CUP_arifle_AK107",
            "CUP_arifle_AK107_GL",
            "CUP_arifle_AKS74",
            "CUP_arifle_AKS74U",
            "CUP_arifle_AK74_GL",
            "CUP_arifle_AKM",
            "CUP_arifle_AKS",
            "CUP_arifle_AKS_Gold",
            "CUP_arifle_RPK74",
//          "CUP_arifle_AK107_GL_kobra",
//       	"CUP_arifle_AK107_kobra",
//      	"CUP_arifle_AK107_GL_pso",
//        	"CUP_arifle_AK107_pso",
//        	"CUP_arifle_AKS74UN_kobra_snds",
//       	"CUP_arifle_AKS74_Goshawk",
//       	"CUP_arifle_AKS74_NSPU",
//       	"CUP_arifle_AK74_GL_kobra",
//        	"CUP_arifle_CZ805_A1_ZDDot_Laser",
//        	"CUP_arifle_CZ805_GL_ZDDot_Laser",
            "CUP_arifle_CZ805_A2",
//    		"CUP_arifle_CZ805_A2_ZDDot_Flashlight_Snds",
//        	"CUP_arifle_CZ805B_GL_ACOG_Laser",
            "CUP_arifle_FNFAL",
//       	"CUP_arifle_FNFAL_ANPVS4",
            "CUP_arifle_FNFAL_railed",
            "CUP_arifle_G36A",
            "CUP_arifle_G36A_camo",
            "CUP_arifle_G36K",
            "CUP_arifle_G36K_camo",
            "CUP_arifle_G36C",
            "CUP_arifle_G36C_camo",
            "CUP_arifle_MG36",
            "CUP_arifle_MG36_camo",
//         	"CUP_arifle_G36C_holo_snds",
//         	"CUP_arifle_G36C_camo_holo_snds",
//			"CUP_arifle_ksvk_PSO3",
//      	"CUP_arifle_L85A2_Holo_laser",
//         	"CUP_arifle_L85A2_GL_Holo_laser",
//         	"CUP_arifle_L85A2_SUSAT_Laser",
//       	"CUP_arifle_L85A2_GL_SUSAT_Laser",
//      	"CUP_arifle_L85A2_CWS_Laser",
//         	"CUP_arifle_L85A2_ACOG_Laser",
            "CUP_arifle_L85A2",
            "CUP_arifle_L85A2_GL",
//         	"CUP_arifle_L85A2_GL_ACOG_Laser",
//       	"CUP_arifle_L86A2_ACOG",
            "CUP_arifle_L86A2",
            "CUP_arifle_M16A2",
            "CUP_arifle_M16A2_GL",
//        	"CUP_arifle_M16A4_Aim_Laser",
//         	"CUP_arifle_M16A4_ACOG_Laser",
            "CUP_arifle_M16A4_GL",
//       	"CUP_arifle_M16A4_GL_ACOG_Laser",
            "CUP_arifle_M4A1",
            "CUP_arifle_M4A1_camo",
//         	"CUP_arifle_M4A1_camo_Aim",
//         	"CUP_arifle_M4A3_desert_Aim_Flashlight",
//         	"CUP_arifle_M4A3_desert_GL_ACOG_Laser",
//         	"CUP_arifle_M4A1_Aim",
//         	"CUP_arifle_M4A1_camo_AIM_snds",
//        	"CUP_arifle_M4A1_GL_Holo_Flashlight",
//        	"CUP_arifle_M4A1_GL_ACOG_Flashlight",
//         	"CUP_arifle_M4A1_camo_GL_Holo_Flashlight",
//         	"CUP_arifle_M4A1_camo_GL_Holo_Flashlight_Snds",
            "CUP_arifle_M16A4_Base",
//         	"CUP_arifle_M16A4GL",
            "CUP_arifle_M4A1_BUIS_GL",
            "CUP_arifle_M4A1_BUIS_camo_GL",
            "CUP_arifle_M4A1_BUIS_desert_GL",
            "CUP_arifle_M4A1_black",
            "CUP_arifle_M4A1_desert",
            "CUP_arifle_Sa58P",
            "CUP_arifle_Sa58V",
//         	"CUP_arifle_Sa58V_ACOG_Laser",
//      	"CUP_arifle_Sa58V_Aim_Laser",
            "CUP_arifle_Mk16_CQC",
//       	"CUP_arifle_Mk16_CQC_FG_Aim_Laser_snds",
//       	"CUP_arifle_Mk16_CQC_SFG_Holo",
//         	"CUP_arifle_Mk16_STD_EGLM_ACOG_Laser",
//       	"CUP_arifle_Mk16_STD_EGLM_ANPAS13c1_Laser_mfsup",
//        	"CUP_arifle_Mk16_STD_FG_Holo_Laser",
//        	"CUP_arifle_Mk16_STD_FG_LeupoldMk4CQT_Laser",
//        	"CUP_arifle_Mk17_CQC_SFG_Aim_mfsup",
//        	"CUP_arifle_Mk17_STD_FG_Aim_Laser_snds",
//          "CUP_arifle_Mk20_SB11420_snds",
//         	"CUP_arifle_Mk17_STD_EGL_ElcanSpecter_Laser",
//         	"CUP_arifle_Mk17_STD_FG_ANPAS13c1_Laser_Snds",
            "CUP_arifle_XM8_Compact_Rail",
            "CUP_arifle_XM8_Railed",
            "CUP_arifle_XM8_Carbine",
            "CUP_arifle_XM8_Carbine_FG",
            "CUP_arifle_XM8_Carbine_GL",
            "CUP_arifle_XM8_Compact",
//          "CUP_arifle_XM8_Compact_Holo_Flashlight",
//         	"CUP_arifle_XM8_Railed_Holo_Laser_snds",
            "CUP_arifle_xm8_SAW",
            "CUP_arifle_xm8_sharpshooter",
//        	"CUP_arifle_XM8_Railed_ANPAS13c1_Laser",
//        	"CUP_arifle_XM8_Railed_ANPAS13c1_Laser_snds",
            "CUP_arifle_CZ805_A1",
            "CUP_arifle_CZ805_GL",
//         	"CUP_arifle_CZ805_A2_Holo_Laser",
//        	"CUP_arifle_CZ805_A1_Holo_Laser",
//         	"CUP_arifle_CZ805_A2_Aco_Laser",
//         	"CUP_arifle_CZ805_A1_Aco_Laser",
//        	"CUP_arifle_CZ805_A1_MRCO_Laser",
//        	"CUP_arifle_CZ805_A2_MRCO_Laser",
//        	"CUP_arifle_CZ805_GL_Hamr_Laser",
            "CUP_arifle_CZ805_B_GL",
            "CUP_arifle_CZ805_B",
            "CUP_arifle_Sa58P_des",
            "CUP_arifle_Sa58V_camo",
            "CUP_arifle_Sa58RIS1",
//       	"CUP_arifle_Sa58RIS1_des",	//may be broken
            "CUP_arifle_Sa58RIS2",
            "CUP_arifle_Sa58RIS2_camo",
//      	"CUP_arifle_Sa58RIS1_Aco_Laser",
//        	"CUP_arifle_Sa58RIS2_Arco_Laser",
//        	"CUP_arifle_Sa58RIS1_camo_Aco_Laser",
//        	"CUP_arifle_Sa58RIS2_camo_Arco_Laser",
            "CUP_arifle_Mk16_CQC_FG",
            "CUP_arifle_Mk16_CQC_SFG",
            "CUP_arifle_Mk16_CQC_EGLM",
            "CUP_arifle_Mk16_STD",
            "CUP_arifle_Mk16_STD_FG",
            "CUP_arifle_Mk16_STD_SFG",
            "CUP_arifle_Mk16_STD_EGLM",
            "CUP_arifle_Mk16_SV",
//          "CUP_arifle_Mk16_CQC_EGLM_Holo_Laser_mfsup",
            "CUP_arifle_Mk17_CQC",
            "CUP_arifle_Mk17_CQC_FG",
            "CUP_arifle_Mk17_CQC_SFG",
            "CUP_arifle_Mk17_CQC_EGLM",
            "CUP_arifle_Mk17_STD",
            "CUP_arifle_Mk17_STD_FG",
            "CUP_arifle_Mk17_STD_SFG",
            "CUP_arifle_Mk17_STD_EGLM",
            "CUP_arifle_Mk20",
//      	"CUP_arifle_Mk20_LeupoldMk4MRT",
            "CUP_sgun_AA12",
            "CUP_sgun_M1014",
            "CUP_sgun_Saiga12K"
		};
	};

	class CUPSniperRifles
	{
		name = "CUP Sniper Rifles";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
//       	"CUP_srifle_AS50_SBPMII",
//        	"CUP_srifle_AS50_AMPAS13c2",
            "CUP_srifle_AWM_des",
            "CUP_srifle_AWM_wdl",
//      	"CUP_srifle_AWM_des_SBPMII",
//         	"CUP_srifle_AWM_wdl_SBPMII",
            "CUP_srifle_CZ750",
//        	"CUP_srifle_CZ750_SOS_bipod",
            "CUP_srifle_DMR",
//         	"CUP_srifle_DMR_LeupoldMk4",
            "CUP_srifle_CZ550",
            "CUP_srifle_LeeEnfield",
            "CUP_srifle_M14",
//			"CUP_srifle_M15_Aim",
            "CUP_srifle_Mk12SPR",
//         	"CUP_srifle_Mk12SPR_LeupoldM3LR",
            "CUP_srifle_M24_des",
            "CUP_srifle_M24_wdl",
//        	"CUP_srifle_M24_ghillie",
//        	"CUP_srifle_M24_wdl_LeupoldMk4LRT",
//       	"CUP_srifle_M24_des_LeupoldMk4LRT",
            "CUP_srifle_M40A3",
            "CUP_srifle_M107_Base",
//          "CUP_srifle_M107_LeupoldVX3",
//         	"CUP_srifle_M107_ANPAS13c2",
            "CUP_srifle_M110",
//      	"CUP_srifle_M110_ANPAS13c2",
//        	"CUP_srifle_M110_ANPVS10",
            "CUP_srifle_SVD",
            "CUP_srifle_SVD_des",
//         	"CUP_srifle_SVD_Des_pso",
//       	"CUP_srifle_SVD_pso",
//        	"CUP_srifle_SVD_wdl_ghillie",
//        	"CUP_srifle_SVD_des_ghillie_pso",
//        	"CUP_srifle_SVD_NSPU",
//          "CUP_srifle_ksvk",
            "CUP_srifle_VSSVintorez",
//        	"CUP_srifle_VSSVintorez_pso",
            "CUP_srifle_AS50"
		};
	};

	class CUPExplosive
	{
		name = "CUP Explosive";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
            "CUP_glaunch_M32",
            "CUP_glaunch_M79",
            "CUP_glaunch_Mk13"
		};
	};
//////////////////////////////////////////////////////////////////////////////////////////////////////////////

	class PointerAttachments
	{
		name = "Pointer Attachments";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"acc_flashlight",
			"acc_pointer_IR"
		};
	};

	class BipodAttachments
	{
		name = "Bipod Attachments";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itembipod_ca.paa";
		items[] =
		{
			"bipod_01_F_blk",
			"bipod_01_F_mtp",
			"bipod_01_F_snd",
			"bipod_02_F_blk",
			"bipod_02_F_hex",
			"bipod_02_F_tan",
			"bipod_03_F_blk",
			"bipod_03_F_oli"
		};
	};

	class MuzzleAttachments
	{
		name = "Muzzle Attachments";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemmuzzle_ca.paa";
		items[] =
		{
			"muzzle_snds_338_black",
			"muzzle_snds_338_green",
			"muzzle_snds_338_sand",
			"muzzle_snds_93mmg",
			"muzzle_snds_93mmg_tan",
			"muzzle_snds_B",
			"muzzle_snds_H",
			"muzzle_snds_H_MG",
			"muzzle_snds_H_SW",
			"muzzle_snds_L",
			"muzzle_snds_M",
			"muzzle_snds_acp"
		};
	};

	class OpticAttachments
	{
		name = "Optic Attachments";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemoptic_ca.paa";
		items[] =
		{
			"optic_ACO_grn",
			"optic_ACO_grn_smg",
			"optic_AMS",
			"optic_AMS_khk",
			"optic_AMS_snd",
			"optic_Aco",
			"optic_Aco_smg",
			"optic_Arco",
			"optic_DMS",
			"optic_Hamr",
			"optic_Holosight",
			"optic_Holosight_smg",
			"optic_KHS_blk",
			"optic_KHS_hex",
			"optic_KHS_old",
			"optic_KHS_tan",
			"optic_LRPS",
			"optic_MRCO",
			"optic_MRD",
			"optic_NVS",
			"optic_Nightstalker",
			"optic_SOS",
			"optic_Yorris",
			"optic_tws",
			"optic_tws_mg"
		};
	};

	class Ammunition
	{
		name = "Ammunition";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\CargoMag_ca.paa";
		items[] =
		{
			"100Rnd_65x39_caseless_mag",
			"10Rnd_762x51_Mag",
			"100Rnd_65x39_caseless_mag_Tracer",
			"10Rnd_127x54_Mag",
			"10Rnd_338_Mag",
			"10Rnd_762x54_Mag",
			"10Rnd_93x64_DMR_05_Mag",
			"11Rnd_45ACP_Mag",
			"150Rnd_762x54_Box",
			"150Rnd_762x54_Box_Tracer",
			"16Rnd_9x21_Mag",
			"200Rnd_65x39_cased_Box",
			"200Rnd_65x39_cased_Box_Tracer",
			"20Rnd_556x45_UW_mag",
			"20Rnd_762x51_Mag",
			"30Rnd_45ACP_Mag_SMG_01",
			"30Rnd_45ACP_Mag_SMG_01_Tracer_Red",
			"30Rnd_45ACP_Mag_SMG_01_Tracer_Yellow",
			"30Rnd_45ACP_Mag_SMG_01_tracer_green",
			"30Rnd_556x45_Stanag",
			"30Rnd_556x45_Stanag_Tracer_Green",
			"30Rnd_556x45_Stanag_Tracer_Red",
			"30Rnd_556x45_Stanag_Tracer_Yellow",
			"30Rnd_65x39_caseless_green",
			"30Rnd_65x39_caseless_green_mag_Tracer",
			"30Rnd_65x39_caseless_mag",
			"30Rnd_65x39_caseless_mag_Tracer",
			"30Rnd_9x21_Green_Mag",
			"30Rnd_9x21_Mag",
			"30Rnd_9x21_Red_Mag",
			"30Rnd_9x21_Yellow_Mag",
			"5Rnd_127x108_APDS_Mag",
			"5Rnd_127x108_Mag",
			"6Rnd_45ACP_Cylinder",
			"6Rnd_GreenSignal_F",
			"6Rnd_RedSignal_F",
			"7Rnd_408_Mag",
			"9Rnd_45ACP_Mag",
			"Exile_Magazine_100Rnd_762x54_PK_Green",
			"Exile_Magazine_10Rnd_303",
			"Exile_Magazine_10Rnd_762x54",
			"Exile_Magazine_10Rnd_9x39",
			"Exile_Magazine_20Rnd_762x51_DMR",
			"Exile_Magazine_20Rnd_762x51_DMR_Green",
			"Exile_Magazine_20Rnd_762x51_DMR_Red",
			"Exile_Magazine_20Rnd_762x51_DMR_Yellow",
			"Exile_Magazine_20Rnd_9x39",
			"Exile_Magazine_30Rnd_545x39_AK",
			"Exile_Magazine_30Rnd_545x39_AK_Green",
			"Exile_Magazine_30Rnd_545x39_AK_Red",
			"Exile_Magazine_30Rnd_545x39_AK_White",
			"Exile_Magazine_30Rnd_545x39_AK_Yellow",
			"Exile_Magazine_30Rnd_762x39_AK",
			"Exile_Magazine_45Rnd_545x39_RPK_Green",
			"Exile_Magazine_5Rnd_22LR",
			"Exile_Magazine_6Rnd_45ACP",
			"Exile_Magazine_75Rnd_545x39_RPK_Green",
			"Exile_Magazine_7Rnd_45ACP",
			"Exile_Magazine_8Rnd_74Slug",
			"Exile_Magazine_8Rnd_9x18",
			"130Rnd_338_Mag", // SPMG
			"150Rnd_93x64_Mag", // NAVID
			"Exile_Magazine_8Rnd_74Pellets"
		};
	};

	class Pistols
	{
		name = "Pistols";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\handgun_ca.paa";
		items[] =
		{
			"Exile_Weapon_Colt1911",
			"Exile_Weapon_Makarov",
			"Exile_Weapon_Taurus",
			"Exile_Weapon_TaurusGold",
			"hgun_ACPC2_F",
			"hgun_P07_F",
			"hgun_Pistol_Signal_F",
			"hgun_Pistol_heavy_01_F",
			"hgun_Pistol_heavy_02_F",
			"hgun_Rook40_F"
		};
	};

	class SubMachineGuns
	{
		name = "Sub Machine Guns";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"hgun_PDW2000_F",
			"SMG_01_F",
			"SMG_02_F"
		};
	};

	class LightMachineGuns
	{
		name = "Light Machine Guns";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"Exile_Weapon_PK",
			"Exile_Weapon_PKP",
			"Exile_Weapon_RPK",
			"LMG_Mk200_F",
			"LMG_Zafir_F",
			"arifle_MX_SW_Black_F",
			"arifle_MX_SW_F",

			"MMG_01_hex_F",
			"MMG_01_tan_F",
			"MMG_02_black_F",
			"MMG_02_camo_F",
			"MMG_02_sand_F"
		};
	};

	class AssaultRifles
	{
		name = "Assault Rifles";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"Exile_Weapon_AK107",
			"Exile_Weapon_AK107_GL",
			"Exile_Weapon_AK47",
			"Exile_Weapon_AK74",
			"Exile_Weapon_AK74_GL",
			"Exile_Weapon_AKS_Gold",
			"arifle_Katiba_C_F",
			"arifle_Katiba_F",
			"arifle_Katiba_GL_F",
			"arifle_MXC_Black_F",
			"arifle_MXC_F",
			"arifle_MX_Black_F",
			"arifle_MX_F",
			"arifle_MX_GL_Black_F",
			"arifle_MX_GL_F",
			"arifle_Mk20C_F",
			"arifle_Mk20C_plain_F",
			"arifle_Mk20_F",
			"arifle_Mk20_GL_F",
			"arifle_Mk20_GL_plain_F",
			"arifle_Mk20_plain_F",
			"arifle_SDAR_F",
			"arifle_TRG20_F",
			"arifle_TRG21_F",
			"arifle_TRG21_GL_F"
		};
	};

	class Shotguns
	{
		name = "Shotguns";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"Exile_Weapon_M1014"
		};
	};

	class SniperRifles
	{
		name = "Sniper Rifles";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"Exile_Weapon_CZ550",
			"Exile_Weapon_DMR",
			"Exile_Weapon_LeeEnfield",
			"Exile_Weapon_SVD",
			"Exile_Weapon_SVDCamo",
			"Exile_Weapon_VSSVintorez",
			"arifle_MXM_Black_F",
			"arifle_MXM_F",
			"srifle_DMR_01_F",
			"srifle_DMR_02_F",
			"srifle_DMR_02_camo_F",
			"srifle_DMR_02_sniper_F",
			"srifle_DMR_03_F",
			"srifle_DMR_03_khaki_F",
			"srifle_DMR_03_multicam_F",
			"srifle_DMR_03_tan_F",
			"srifle_DMR_03_woodland_F",
			"srifle_DMR_04_F",
			"srifle_DMR_04_Tan_F",
			"srifle_DMR_05_blk_F",
			"srifle_DMR_05_hex_F",
			"srifle_DMR_05_tan_f",
			"srifle_DMR_06_camo_F",
			"srifle_DMR_06_olive_F",
			"srifle_EBR_F",
			"srifle_GM6_F",
			"srifle_GM6_camo_F",
			"srifle_LRR_F",
			"srifle_LRR_camo_F",
			"Exile_Weapon_ksvk"
		};
	};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	class RHSPointerAttachments
	{
		name = "RHS Pointer Attachments";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"rhsusf_acc_anpeq15side",
			"rhsusf_acc_anpeq15",
			"rhsusf_acc_anpeq15A",
			"rhsusf_acc_anpeq15_light",
			// Added by ElShotte - 11 Items
			"rhsusf_acc_M952V",
			"rhs_acc_perst3",
			"rhs_acc_perst3_top",
			"rhs_acc_perst3_2dp_h",
			"rhs_acc_perst3_2dp_light_h",
			"rhs_acc_2dpZenit",
			"rhs_acc_2dpZenit_ris",
			"rhs_acc_perst1ik",
			"rhs_acc_perst1ik_ris",
			"rhsusf_acc_anpeq15_bk",
			"rhsusf_acc_anpeq15_bk_light",
			"rhsusf_acc_grip1",
			"rhsusf_acc_grip2",
			"rhsusf_acc_grip2_tan",
			"rhsusf_acc_grip3",
			"rhsusf_acc_grip3_tan",
			"rhs_acc_grip_rk2",
			"rhs_acc_grip_rk6",
			"rhs_acc_grip_ffg2"
		};
	};

	class RHSBipodAttachments
	{
		name = "RHS Bipod Attachments";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itembipod_ca.paa";
		items[] =
		{
			"rhsusf_acc_harris_bipod",
			"rhsusf_acc_harris_swivel",
			"rhs_acc_harris_swivel"
		};
	};

	class RHSMuzzleAttachments
	{
		name = "RHS Muzzle Attachments";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemmuzzle_ca.paa";
		items[] =
		{
			"rhsusf_acc_rotex5_grey",
			"rhsusf_acc_rotex5_tan",
			"rhsusf_acc_nt4_black",
			"rhsusf_acc_nt4_tan",
			"rhsusf_acc_SF3P556",
			"rhsusf_acc_SFMB556",
			"rhsusf_acc_SR25S",
			"rhsusf_acc_M2010S",
			"rhs_acc_dtk4short",
			"rhs_acc_dtk4long",
			"rhs_acc_dtk4screws",
			"rhs_acc_tgpa",
			"rhs_acc_pbs1",
			"rhs_acc_dtk3",
			"rhs_acc_dtk1",
			"rhs_acc_dtk",
			"rhs_acc_dtk1l",
			"rhs_acc_ak5",
			// Added by ElShotte - 6 Items
			"rhsusf_acc_omega9k",
			"rhs_acc_uuk",
			"rhsusf_acc_rotex_mp7",
			"rhsusf_acc_rotex_mp7_desert",
			"rhsusf_acc_rotex_mp7_winter",
			"rhsusf_acc_rotex_mp7_aor1"
		};
	};

	class RHSOpticAttachments
	{
		name = "RHS Optic Attachments";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemoptic_ca.paa";
		items[] =
		{
			"rhs_acc_1p29",
			"rhs_acc_1p63",
			"rhs_acc_1p78",
			"rhs_acc_1pn93_1",
			"rhs_acc_1pn93_2",
			"rhs_acc_dh520x56",
			"rhs_acc_ekp1",
			"rhs_acc_pgo7v",
			"rhs_acc_pkas",
			"rhs_acc_pso1m2",
			"rhs_acc_rakursPM",
			"rhs_weap_optic_smaw",
			"rhsusf_acc_ACOG",
			"rhsusf_acc_ACOG2",
			"rhsusf_acc_ACOG2_USMC",
			"rhsusf_acc_ACOG3",
			"rhsusf_acc_ACOG3_USMC",
			"rhsusf_acc_ACOG_MDO",
			"rhsusf_acc_ACOG_RMR",
			"rhsusf_acc_ACOG_USMC",
			"rhsusf_acc_ACOG_d",
			"rhsusf_acc_ACOG_pip",
			"rhsusf_acc_ACOG_wd",
			"rhsusf_acc_ELCAN",
			"rhsusf_acc_ELCAN_pip",
			"rhsusf_acc_EOTECH",
			"rhsusf_acc_LEUPOLDMK4",
			"rhsusf_acc_LEUPOLDMK4_2",
			"rhsusf_acc_M8541",
			"rhsusf_acc_M8541_low",
			"rhsusf_acc_M8541_low_d",
			"rhsusf_acc_M8541_low_wd",
			"rhsusf_acc_SpecterDR",
			"rhsusf_acc_SpecterDR_A_3d",
			"rhsusf_acc_SpecterDR_D",
			"rhsusf_acc_SpecterDR_OD",
			"rhsusf_acc_anpas13gv1",
			"rhsusf_acc_eotech_552",
			"rhsusf_acc_premier",
			"rhsusf_acc_premier_anpvs27",
			"rhsusf_acc_premier_low"
		};
	};

	class RHSPistols
	{
		name = "RHS Pistols";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[]=
		{
			"rhs_weap_pya",
			"rhs_weap_makarov_pm",
			// Added by ElShotte - 4 Items
			"rhs_weap_pp2000_folded",
			"rhsusf_weap_glock17g4",
			"rhsusf_weap_m9",
			"rhsusf_weap_m1911a1"
		};
	};

	class RHSLightMachineGuns
	{
		name = "RHS Light MachineGuns";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[]=
		{
			"rhs_weap_m249_pip_L",
			"rhs_weap_m249_pip_L_para",
			"rhs_weap_m249_pip_L_vfg",
			"rhs_weap_m249_pip_S",
			"rhs_weap_m249_pip_S_para",
			"rhs_weap_m249_pip_S_vfg",
			"rhs_weap_m240B",
			"rhs_weap_m240B_CAP",
			"rhs_weap_m240G",
			"rhs_weap_pkm",
			"rhs_weap_pkp",
			// Added by ElShotte - 1 Item
			"rhs_weap_m27iar"
		};
	};

	// Added by ElShotte - 4 Items
	class RHSSubMachineGuns
	{
		name = "RHS Sub Machine Guns";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"rhsusf_weap_MP7A2",
			"rhsusf_weap_MP7A2_desert",
			"rhsusf_weap_MP7A2_aor1",
			"rhsusf_weap_MP7A2_winter"
		};
	};

	class RHSAssaultRifles
	{
		name = "RHS Assault Rifles";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[]=
		{
			"rhs_weap_hk416d10",
			"rhs_weap_hk416d10_LMT",
			"rhs_weap_hk416d10_m320",
			"rhs_weap_hk416d145",
			"rhs_weap_hk416d145_m320",
			"rhs_weap_m16a4",
			"rhs_weap_m16a4_carryhandle",
			"rhs_weap_m16a4_carryhandle_M203",
			"rhs_weap_m16a4_carryhandle_pmag",
			"rhs_weap_m4_carryhandle",
			"rhs_weap_m4_carryhandle_pmag",
			"rhs_weap_m4_m203",
			"rhs_weap_m4_m320",
			"rhs_weap_m4a1",
			"rhs_weap_m4a1_blockII",
			"rhs_weap_m4a1_blockII_KAC",
			"rhs_weap_m4a1_blockII_KAC_bk",
			"rhs_weap_m4a1_blockII_KAC_d",
			"rhs_weap_m4a1_blockII_KAC_wd",
			"rhs_weap_m4a1_blockII_M203",
			"rhs_weap_m4a1_blockII_M203_bk",
			"rhs_weap_m4a1_blockII_M203_d",
			"rhs_weap_m4a1_blockII_M203_wd",
			"rhs_weap_m4a1_blockII_bk",
			"rhs_weap_m4a1_blockII_d",
			"rhs_weap_m4a1_blockII_wd",
			"rhs_weap_m4a1_carryhandle",
			"rhs_weap_m4a1_carryhandle_m203",
			"rhs_weap_m4a1_carryhandle_pmag",
			"rhs_weap_m4a1_m203",
			"rhs_weap_m4a1_m320",
			"rhs_weap_mk18",
			"rhs_weap_mk18",
			"rhs_weap_mk18_KAC",
			"rhs_weap_mk18_KAC_bk",
			"rhs_weap_mk18_KAC_d",
			"rhs_weap_mk18_KAC_wd",
			"rhs_weap_mk18_bk",
			"rhs_weap_mk18_d",
			"rhs_weap_mk18_m320",
			"rhs_weap_mk18_wd",
			"rhs_weap_ak103_zenitco01",
			"rhs_weap_ak103_zenitco01_b33",
			"rhs_weap_ak104_zenitco01",
			"rhs_weap_ak104_zenitco01_b33",
			"rhs_weap_ak105_zenitco01",
			"rhs_weap_ak105_zenitco01_b33",
			"rhs_weap_ak74m_zenitco01",
			"rhs_weap_ak74m_zenitco01_b33",	
			"rhs_weap_akm_zenitco01_b33"			
		/*	// Exile Dupe issue items un comment at your own risk
			"rhs_weap_ak103",
			"rhs_weap_ak103_1",
			"rhs_weap_ak103_npz",			
			"rhs_weap_ak74m",
			"rhs_weap_ak74m_2mag",
			"rhs_weap_ak74m_2mag_camo",
			"rhs_weap_ak74m_2mag_npz",
			"rhs_weap_ak74m_camo",
			"rhs_weap_ak74m_camo_folded",
			"rhs_weap_ak74m_desert",
			"rhs_weap_ak74m_desert_folded",
			"rhs_weap_ak74m_desert_npz",
			"rhs_weap_ak74m_folded",
			"rhs_weap_ak74m_gp25",
			"rhs_weap_ak74m_gp25_npz",
			"rhs_weap_ak74m_npz",
			"rhs_weap_ak74m_plummag",
			"rhs_weap_ak74m_plummag_folded",
			"rhs_weap_ak74m_plummag_npz",
			"rhs_weap_ak74mr",
			"rhs_weap_ak74mr_gp25",
			"rhs_weap_akm",
			"rhs_weap_akm_gp25",
			"rhs_weap_akms",
			"rhs_weap_akms_gp25",
			"rhs_weap_aks74",
			"rhs_weap_aks74_gp25",
			"rhs_weap_aks74n",
			"rhs_weap_aks74n_gp25",
			"rhs_weap_m16a4_carryhandle_grip",
			"rhs_weap_m16a4_carryhandle_grip_pmag",
			"rhs_weap_m16a4_grip",
			"rhs_weap_m4",
			"rhs_weap_m4_grip",
			"rhs_weap_m4_grip2",
			"rhs_weap_m4a1_blockII_grip2",
			"rhs_weap_m4a1_blockII_grip2_KAC",
			"rhs_weap_m4a1_carryhandle_grip2",
			"rhs_weap_m4a1_grip",
			"rhs_weap_m4a1_grip2",
			"rhs_weap_mk18_grip2",
			"rhs_weap_mk18_grip2_KAC"
		*/
		};
	};

	class RHSSniperRifles
	{
		name = "RHS Sniper Rifles";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[]=
		{
			"rhs_weap_sr25",
			"rhs_weap_sr25_ec",
			"rhs_weap_m14ebrri",
			"rhs_weap_XM2010",
			"rhs_weap_XM2010_wd",
			"rhs_weap_XM2010_d",
			"rhs_weap_XM2010_sa",
			"rhs_weap_svd",
			"rhs_weap_svdp_wd",
			"rhs_weap_svdp_wd_npz",
			"rhs_weap_svdp_npz",
			"rhs_weap_svds",
			"rhs_weap_svds_npz",
			// Addd by ElShotte - 14 Items
			"rhs_weap_M107",
			"rhs_weap_M107_d",
			"rhs_weap_M107_w",
			"rhs_weap_t5000",
			"rhs_weap_m24sws",
			"rhs_weap_m24sws_blk",
			"rhs_weap_m24sws_ghillie",
			"rhs_weap_m40a5",
			"rhs_weap_m40a5_d",
			"rhs_weap_sr25_d",
			"rhs_weap_sr25_wd",
			"rhs_weap_sr25_ec_d",
			"rhs_weap_sr25_ec_wd"
		};
	};

	class RHSAmmunition
	{
		name = "RHS Ammunition";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[]=
		{
			"rhsusf_mag_7x45acp_MHP",
			"rhs_mag_9x18_12_57N181S",
			"rhs_mag_9x19_17",
			"rhs_mag_30Rnd_556x45_Mk318_Stanag",
			"rhs_mag_30Rnd_556x45_Mk262_Stanag",
			"rhs_mag_30Rnd_556x45_M855A1_Stanag",
			"rhs_mag_30Rnd_556x45_M855A1_Stanag_No_Tracer",
			"rhs_mag_30Rnd_556x45_M855A1_Stanag_Tracer_Red",
			"rhs_mag_30Rnd_556x45_M855A1_Stanag_Tracer_Green",
			"rhs_mag_30Rnd_556x45_M855A1_Stanag_Tracer_Yellow",
			"rhs_200rnd_556x45_M_SAW",
			"rhs_200rnd_556x45_B_SAW",
			"rhs_200rnd_556x45_T_SAW",
			"rhsusf_50Rnd_762x51",
			"rhsusf_50Rnd_762x51_m993",
			"rhsusf_50Rnd_762x51_m80a1epr",
			"rhsusf_100Rnd_762x51",
			"rhsusf_100Rnd_762x51_m993",
			"rhsusf_100Rnd_762x51_m80a1epr",
			"rhsusf_8Rnd_00Buck",
			"rhsusf_8Rnd_Slug",
			"rhsusf_20Rnd_762x51_m993_Mag",
			"rhsusf_5Rnd_300winmag_xm2010",
			"rhs_30Rnd_762x39mm",
			"rhs_30Rnd_762x39mm_tracer",
			"rhs_30Rnd_762x39mm_89",
			"rhs_30Rnd_545x39_AK",
			"rhs_30Rnd_545x39_AK_no_tracers",
			"rhs_30Rnd_545x39_7N10_AK",
			"rhs_30Rnd_545x39_7N22_AK",
			"rhs_30Rnd_545x39_AK_green",
			"rhs_45Rnd_545X39_AK",
			"rhs_45Rnd_545X39_7N10_AK",
			"rhs_45Rnd_545X39_7N22_AK",
			"rhs_45Rnd_545X39_AK_Green",
			"rhs_100Rnd_762x54mmR",
			"rhs_100Rnd_762x54mmR_green",
			"rhs_10Rnd_762x54mmR_7N1",
			"rhsusf_20Rnd_762x51_SR25_m118_special_Mag",
	        "rhsusf_20Rnd_762x51_SR25_mk316_special_Mag",
	        "rhsusf_20Rnd_762x51_SR25_m993_Mag",
	        "rhsusf_20Rnd_762x51_SR25_m62_Mag",

			// Added by ElShotte - 26 Items
			//M-107 and M82A1
			"rhsusf_mag_10Rnd_STD_50BMG_M33",
			"rhsusf_mag_10Rnd_STD_50BMG_mk211", // <- Exploding 50 Cal rounds (WAY too powerful)
			
			//HK MP7A2
			"rhsusf_mag_40Rnd_46x30_AP",
			"rhsusf_mag_40Rnd_46x30_FMJ",
			"rhsusf_mag_40Rnd_46x30_JHP",

			// Orsis T-5000
			"rhs_5Rnd_338lapua_t5000",

			// M590
			"rhsusf_5Rnd_00Buck",
			"rhsusf_5Rnd_FRAG",
			"rhsusf_5Rnd_HE",
			"rhsusf_5Rnd_Slug",
			"rhsusf_8Rnd_doomsday_Buck",

			// M24 SWS
			"rhsusf_5Rnd_762x51_m118_special_Mag",
			"rhsusf_5Rnd_762x51_m993_Mag",
			"rhsusf_5Rnd_762x51_m62_Mag",

			// M40A5
			"rhsusf_10Rnd_762x51_m62_Mag",
			"rhsusf_10Rnd_762x51_m993_Mag",
			"rhsusf_10Rnd_762x51_m118_special_Mag",

			// Pistols
			"rhsusf_mag_15Rnd_9x19_FMJ",
			"rhsusf_mag_15Rnd_9x19_JHP",
			"rhsusf_mag_17Rnd_9x19_JHP",
			"rhsusf_mag_17Rnd_9x19_FMJ",
			"rhs_mag_9x18_8_57N181S",
			"rhs_mag_9x19mm_7n31_44",
			"rhs_mag_9x19mm_7n21_44",
			"rhs_mag_9x19mm_7n31_20",
			"rhs_mag_9x19mm_7n21_20"
		};
	};

	class Uniforms
	{
		name = "Uniforms";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\uniform_ca.paa";
		items[] =
		{
			"U_C_Journalist",
			"U_C_Poloshirt_blue",
			"U_C_Poloshirt_burgundy",
			"U_C_Poloshirt_salmon",
			"U_C_Poloshirt_stripped",
			"U_C_Poloshirt_tricolour",
			"U_C_Poor_1",
			"U_C_Poor_2",
			"U_C_Poor_shorts_1",
			"U_C_Scientist",
			"U_OrestesBody",
			"U_Rangemaster",
			"U_NikosAgedBody",
			"U_NikosBody",
			"U_Competitor",
			"U_B_CombatUniform_mcam",
			"U_B_CombatUniform_mcam_tshirt",
			"U_B_CombatUniform_mcam_vest",
			"U_B_CombatUniform_mcam_worn",
			"U_B_CTRG_1",
			"U_B_CTRG_2",
			"U_B_CTRG_3",
			"U_I_CombatUniform",
			"U_I_CombatUniform_shortsleeve",
			"U_I_CombatUniform_tshirt",
			"U_I_OfficerUniform",
			"U_O_CombatUniform_ocamo",
			"U_O_CombatUniform_oucamo",
			"U_O_OfficerUniform_ocamo",
			"U_B_SpecopsUniform_sgg",
			"U_O_SpecopsUniform_blk",
			"U_O_SpecopsUniform_ocamo",
			"U_I_G_Story_Protagonist_F",
			"Exile_Uniform_Woodland",
			"U_C_HunterBody_grn",
			"U_IG_Guerilla1_1",
			"U_IG_Guerilla2_1",
			"U_IG_Guerilla2_2",
			"U_IG_Guerilla2_3",
			"U_IG_Guerilla3_1",
			"U_BG_Guerilla2_1",
			"U_IG_Guerilla3_2",
			"U_BG_Guerrilla_6_1",
			"U_BG_Guerilla1_1",
			"U_BG_Guerilla2_2",
			"U_BG_Guerilla2_3",
			"U_BG_Guerilla3_1",
			"U_BG_leader",
			"U_IG_leader",
			"U_I_G_resistanceLeader_F",
			"U_B_FullGhillie_ard",
			"U_B_FullGhillie_lsh",
			"U_B_FullGhillie_sard",
			"U_B_GhillieSuit",
			"U_I_FullGhillie_ard",
			"U_I_FullGhillie_lsh",
			"U_I_FullGhillie_sard",
			"U_I_GhillieSuit",
			"U_O_FullGhillie_ard",
			"U_O_FullGhillie_lsh",
			"U_O_FullGhillie_sard",
			"U_O_GhillieSuit",
			"U_B_survival_uniform",
			"U_B_HeliPilotCoveralls",
			"U_I_HeliPilotCoveralls",
			"U_B_PilotCoveralls",
			"U_I_pilotCoveralls",
			"U_O_PilotCoveralls"
			
		};
	};
	
    class ApexUniforms
	{
		name = "Apex Uniforms";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\uniform_ca.paa";
		items[] = 
		{
			"U_B_T_Soldier_F",
			"U_B_T_Soldier_AR_F",
			"U_B_T_Soldier_SL_F",
			"U_B_T_Sniper_F",
			"U_B_T_FullGhillie_tna_F",
			"U_B_CTRG_Soldier_F",
			"U_B_CTRG_Soldier_2_F",
			"U_B_CTRG_Soldier_3_F",
			"U_B_GEN_Soldier_F",
			"U_B_GEN_Commander_F",
			"U_O_T_Soldier_F",
			"U_O_T_Officer_F",
			"U_O_T_Sniper_F",
			"U_I_Protagonist_VR",
		    "U_O_Protagonist_VR",
		    "U_B_Protagonist_VR",
			"U_O_T_FullGhillie_tna_F",
			"U_O_V_Soldier_Viper_F",
			"U_O_V_Soldier_Viper_hex_F",
			"U_I_C_Soldier_Para_1_F",
			"U_I_C_Soldier_Para_2_F",
			"U_I_C_Soldier_Para_3_F",
			"U_I_C_Soldier_Para_4_F",
			"U_I_C_Soldier_Para_5_F",
			"U_I_C_Soldier_Bandit_1_F",
			"U_I_C_Soldier_Bandit_2_F",
			"U_I_C_Soldier_Bandit_3_F",
			"U_I_C_Soldier_Bandit_4_F",
			"U_I_C_Soldier_Bandit_5_F",
			"U_I_C_Soldier_Camo_F",
			"U_C_man_sport_1_F",
			"U_C_man_sport_2_F",
			"U_C_man_sport_3_F",
			"U_C_Man_casual_1_F",
			"U_C_Man_casual_2_F",
			"U_C_Man_casual_3_F",
			"U_C_Man_casual_4_F",
			"U_C_Man_casual_5_F",
			"U_C_Man_casual_6_F",
			"U_B_CTRG_Soldier_urb_1_F",
			"U_B_CTRG_Soldier_urb_2_F",
			"U_B_CTRG_Soldier_urb_3_F"
		};
	};
	class Vests
	{
		name = "Vests";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\vest_ca.paa";
		items[] =
		{
			"V_Press_F",
			"V_Rangemaster_belt",
			"V_TacVest_blk",
			"V_TacVest_blk_POLICE",
			"V_TacVest_brn",
			"V_TacVest_camo",
			"V_TacVest_khk",
			"V_TacVest_oli",
			"V_TacVestCamo_khk",
			"V_TacVestIR_blk",
			"V_I_G_resistanceLeader_F",
			"V_BandollierB_blk",
			"V_BandollierB_cbr",
			"V_BandollierB_khk",
			"V_BandollierB_oli",
			"V_BandollierB_rgr",
			"V_Chestrig_blk",
			"V_Chestrig_khk",
			"V_Chestrig_oli",
			"V_Chestrig_rgr",
			"V_HarnessO_brn",
			"V_HarnessO_gry",
			"V_HarnessOGL_brn",
			"V_HarnessOGL_gry",
			"V_HarnessOSpec_brn",
			"V_HarnessOSpec_gry",
			"V_PlateCarrier1_blk",
			"V_PlateCarrier1_rgr",
			"V_PlateCarrier2_rgr",
			"V_PlateCarrier3_rgr",
			"V_PlateCarrierGL_blk",
			"V_PlateCarrierGL_mtp",
			"V_PlateCarrierGL_rgr",
			"V_PlateCarrierH_CTRG",
			"V_PlateCarrierIA1_dgtl",
			"V_PlateCarrierIA2_dgtl",
			"V_PlateCarrierIAGL_dgtl",
			"V_PlateCarrierIAGL_oli",
			"V_PlateCarrierL_CTRG",
			"V_PlateCarrierSpec_blk",
			"V_PlateCarrierSpec_mtp",
			"V_PlateCarrierSpec_rgr"
		};
	};
class ApexVests
	{
		name = "Apex Vests";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\vest_ca.paa";
		items[] = 
		{
			
			"V_TacChestrig_grn_F",
			"V_TacChestrig_oli_F",
			"V_TacChestrig_cbr_F",
			"V_PlateCarrier1_tna_F",
			"V_PlateCarrier2_tna_F",
			"V_PlateCarrierSpec_tna_F",
			"V_PlateCarrierGL_tna_F",
			"V_HarnessO_ghex_F",
			"V_HarnessOGL_ghex_F",
			"V_BandollierB_ghex_F",
			"V_TacVest_gen_F",
			"V_PlateCarrier1_rgr_noflag_F",
			"V_PlateCarrier2_rgr_noflag_F"
		};
	};
	class JetsVests
	{
		name = "Jets Vests";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\vest_ca.paa";
		items[] = 
		{
			"V_DeckCrew_yellow_F",
			"V_DeckCrew_blue_F",
			"V_DeckCrew_green_F",
			"V_DeckCrew_red_F",
			"V_DeckCrew_white_F",
			"V_DeckCrew_brown_F",
			"V_DeckCrew_violet_F"
		};
	};
	class Headgear
	{
		name = "Headgear";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\headgear_ca.paa";
		items[] =
		{
			"Exile_Headgear_SantaHat",
			"Exile_Headgear_SafetyHelmet",
			"H_Cap_blk",
			"H_Cap_blk_Raven",
			"H_Cap_blu",
			"H_Cap_brn_SPECOPS",
			"H_Cap_grn",
			"H_Cap_headphones",
			"H_Cap_khaki_specops_UK",
			"H_Cap_oli",
			"H_Cap_press",
			"H_Cap_red",
			"H_Cap_tan",
			"H_Cap_tan_specops_US",
			"H_Watchcap_blk",
			"H_Watchcap_camo",
			"H_Watchcap_khk",
			"H_Watchcap_sgg",
			"H_MilCap_blue",
			"H_MilCap_dgtl",
			"H_MilCap_mcamo",
			"H_MilCap_ocamo",
			"H_MilCap_oucamo",
			"H_MilCap_rucamo",
			"H_Bandanna_camo",
			"H_Bandanna_cbr",
			"H_Bandanna_gry",
			"H_Bandanna_khk",
			"H_Bandanna_khk_hs",
			"H_Bandanna_mcamo",
			"H_Bandanna_sgg",
			"H_Bandanna_surfer",
			"H_Booniehat_dgtl",
			"H_Booniehat_dirty",
			"H_Booniehat_grn",
			"H_Booniehat_indp",
			"H_Booniehat_khk",
			"H_Booniehat_khk_hs",
			"H_Booniehat_mcamo",
			"H_Booniehat_tan",
			"H_Hat_blue",
			"H_Hat_brown",
			"H_Hat_camo",
			"H_Hat_checker",
			"H_Hat_grey",
			"H_Hat_tan",
			"H_StrawHat",
			"H_StrawHat_dark",
			"H_Beret_02",
			"H_Beret_blk",
			"H_Beret_blk_POLICE",
			"H_Beret_brn_SF",
			"H_Beret_Colonel",
			"H_Beret_grn",
			"H_Beret_grn_SF",
			"H_Beret_ocamo",
			"H_Beret_red",
			"H_Shemag_khk",
			"H_Shemag_olive",
			"H_Shemag_olive_hs",
			"H_Shemag_tan",
			"H_ShemagOpen_khk",
			"H_ShemagOpen_tan",
			"H_TurbanO_blk",
			"H_HelmetB",
			"H_HelmetB_black",
			"H_HelmetB_camo",
			"H_HelmetB_desert",
			"H_HelmetB_grass",
			"H_HelmetB_light",
			"H_HelmetB_light_black",
			"H_HelmetB_light_desert",
			"H_HelmetB_light_grass",
			"H_HelmetB_light_sand",
			"H_HelmetB_light_snakeskin",
			"H_HelmetB_paint",
			"H_HelmetB_plain_blk",
			"H_HelmetB_sand",
			"H_HelmetB_snakeskin",
			"H_HelmetCrew_B",
			"H_HelmetCrew_I",
			"H_HelmetCrew_O",
			"H_HelmetIA",
			"H_HelmetIA_camo",
			"H_HelmetIA_net",
			"H_HelmetLeaderO_ocamo",
			"H_HelmetLeaderO_oucamo",
			"H_HelmetO_ocamo",
			"H_HelmetO_oucamo",
			"H_HelmetSpecB",
			"H_HelmetSpecB_blk",
			"H_HelmetSpecB_paint1",
			"H_HelmetSpecB_paint2",
			"H_HelmetSpecO_blk",
			"H_HelmetSpecO_ocamo",
			"H_CrewHelmetHeli_B",
			"H_CrewHelmetHeli_I",
			"H_CrewHelmetHeli_O",
			"H_HelmetCrew_I",
			"H_HelmetCrew_B",
			"H_HelmetCrew_O",
			"H_PilotHelmetHeli_B",
			"H_PilotHelmetHeli_I",
			"H_PilotHelmetHeli_O"
		};
	};
	class ApexHeadgear 
	{
		name = "Apex Headgear";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\headgear_ca.paa";
		items[] =
		{
			
			
			"H_Helmet_Skate",
			"H_HelmetB_TI_tna_F",
			"H_HelmetB_tna_F",
			"H_HelmetB_Enh_tna_F",
			"H_HelmetB_Light_tna_F",
			"H_HelmetSpecO_ghex_F",
			"H_HelmetLeaderO_ghex_F",
			"H_HelmetO_ghex_F",
			"H_HelmetCrew_O_ghex_F",
			"H_MilCap_tna_F",
			"H_MilCap_ghex_F",
			"H_Booniehat_tna_F",
			"H_Beret_gen_F",
			"H_MilCap_gen_F",
			"H_Cap_oli_Syndikat_F",
			"H_Cap_tan_Syndikat_F",
			"H_Cap_blk_Syndikat_F",
			"H_Cap_grn_Syndikat_F"
		};
	};

	class Glasses
	{
		name = "Glasses";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\Goggles_ca.paa";
		items[] =
		{
			"G_Spectacles",
			"G_Spectacles_Tinted",
			"G_Combat",
			"G_Lowprofile",
			"G_Shades_Black",
			"G_Shades_Green",
			"G_Shades_Red",
			"G_Squares",
			"G_Squares_Tinted",
			"G_Sport_BlackWhite",
			"G_Sport_Blackyellow",
			"G_Sport_Greenblack",
			"G_Sport_Checkered",
			"G_Sport_Red",
			"G_Tactical_Black",
			"G_Aviator",
			"G_Lady_Mirror",
			"G_Lady_Dark",
			"G_Lady_Red",
			"G_Lady_Blue",
			"G_Goggles_VR",
			"G_Balaclava_blk",
			"G_Balaclava_oli",
			"G_Balaclava_combat",
			"G_Balaclava_lowprofile",
			"G_Bandanna_blk",
			"G_Bandanna_oli",
			"G_Bandanna_khk",
			"G_Bandanna_tan",
			"G_Bandanna_beast",
			"G_Bandanna_shades",
			"G_Bandanna_sport",
			"G_Bandanna_aviator",
			"G_Shades_Blue",
			"G_Sport_Blackred",
			"G_Tactical_Clear",
			"G_Balaclava_TI_blk_F",
			"G_Balaclava_TI_tna_F",
			"G_Balaclava_TI_G_blk_F",
			"G_Balaclava_TI_G_tna_F",
			"G_Combat_Goggles_tna_F"
		};
	};

	class Food
	{
		name = "Food";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"Exile_Item_EMRE",
			"Exile_Item_GloriousKnakworst",
			"Exile_Item_Surstromming",
			"Exile_Item_SausageGravy",
			"Exile_Item_Catfood",
			"Exile_Item_ChristmasTinner",
			"Exile_Item_BBQSandwich",
			"Exile_Item_MacasCheese",
			"Exile_Item_Dogfood",
			"Exile_Item_BeefParts",
			"Exile_Item_Cheathas",
			"Exile_Item_Noodles",
			"Exile_Item_SeedAstics",
			"Exile_Item_Raisins",
			"Exile_Item_Moobar",
			"Exile_Item_InstantCoffee",
			"Exile_Item_CanOpener",
			"Exile_Item_BurlapSack"
			// Hunted Animals
			// Note: Adding these to the trader will defeat the purpose of hunting!

		};
	};
	
 

	class Drinks
	{
		name = "Drinks";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"Exile_Item_PlasticBottleCoffee",
			"Exile_Item_PowerDrink",
			"Exile_Item_PlasticBottleFreshWater",
			"Exile_Item_Beer",
			"Exile_Item_EnergyDrink",
			"Exile_Item_ChocolateMilk",
			"Exile_Item_MountainDupe",
			"Exile_Item_PlasticBottleEmpty"
		};
	};

	class Gadgets
	{
		name = "Gadgets";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			//"Exile_Item_SleepingMat",	
			//"Exile_Item_ToiletPaper",			
			//"Exile_Item_ZipTie",
			"MineDetector",
			"Binocular",
			"Laserdesignator",
			"Laserdesignator_02",
			"Laserdesignator_03",
			"ItemGPS",
			"ItemMap",
			"ItemCompass",
			"ItemRadio",
			"ItemWatch",
			"Exile_Item_XM8",
			"O_NVGoggles_hex_F",
			"O_NVGoggles_urb_F",
			"O_NVGoggles_ghex_F",
			"NVGoggles_tna_F",
			"Rangefinder",
			"NVGoggles",
			"NVGoggles_INDEP",
			"NVGogglesB_blk_F",
			"NVGogglesB_grn_F",
			"NVGogglesB_gry_F",
			"NVGoggles_OPFOR",
			"Laserbatteries",
			"rhs_LaserMag",
			"rhs_LaserFCSMag",
			"rhs_LaserMag_ai"
		};
	};
	
	/* class ApexTools
	{
		name = "Apex Tools";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
		};
	}; */


    class FirstAid
	{
		name = "First Aid";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"Exile_Item_InstaDoc",
			"Exile_Item_Bandage",
			"Exile_Item_Vishpirin",
			"Exile_Item_Heatpack",
			"Exile_Item_Defibrillator"
		};
	};

	class Backpacks
	{
		name = "Backpacks";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\backpack_ca.paa";
		items[] =
		{
			"B_AssaultPack_blk",
			"B_AssaultPack_cbr",
			"B_AssaultPack_dgtl",
			"B_AssaultPack_khk",
			"B_AssaultPack_mcamo",
			"B_AssaultPack_rgr",
			"B_AssaultPack_sgg",
			"B_Bergen_blk",
			"B_Bergen_mcamo",
			"B_Bergen_rgr",
			"B_Bergen_sgg",
			"B_Carryall_cbr",
			"B_Carryall_khk",
			"B_Carryall_mcamo",
			"B_Carryall_ocamo",
			"B_Carryall_oli",
			"B_Carryall_oucamo",
			"B_FieldPack_blk",
			"B_FieldPack_cbr",
			"B_FieldPack_ocamo",
			"B_FieldPack_oucamo",
			"B_HuntingBackpack",
			"B_Kitbag_cbr",
			"B_Kitbag_mcamo",
			"B_Kitbag_sgg",
			"B_OutdoorPack_blk",
			"B_OutdoorPack_blu",
			"B_OutdoorPack_tan",
			"B_TacticalPack_blk",
			"B_TacticalPack_mcamo",
			"B_TacticalPack_ocamo",
			"B_TacticalPack_oli",
			"B_TacticalPack_rgr",
			"EBM_Backpack_dev"
			
		};
	};
	class ApexBackpacks
	{
		name = "Apex Backpacks";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\backpack_ca.paa";
		items[] = 
		{
			"B_Bergen_mcamo_F",
			"B_Bergen_dgtl_F",
			"B_Bergen_hex_F",
			"B_Bergen_tna_F",
			"B_AssaultPack_tna_F",
			"B_Carryall_ghex_F",
			"B_FieldPack_ghex_F",
			"B_ViperHarness_blk_F",
			"B_ViperHarness_ghex_F",
			"B_ViperHarness_hex_F",
			"B_ViperHarness_khk_F",
			"B_ViperHarness_oli_F",
			"B_ViperLightHarness_blk_F",
			"B_ViperLightHarness_ghex_F",
			"B_ViperLightHarness_hex_F",
			"B_ViperLightHarness_khk_F",
			"B_ViperLightHarness_oli_F"
		};
	};

	class Flares
	{
		name = "Flares";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"Chemlight_blue",
			"Chemlight_green",
			"Chemlight_red",
			"FlareGreen_F",
			"FlareRed_F",
			"FlareWhite_F",
			"FlareYellow_F",
			"UGL_FlareGreen_F",
			"UGL_FlareRed_F",
			"UGL_FlareWhite_F",
			"UGL_FlareYellow_F",
			"3Rnd_UGL_FlareGreen_F",
			"3Rnd_UGL_FlareRed_F",
			"3Rnd_UGL_FlareWhite_F",
			"3Rnd_UGL_FlareYellow_F"
		};
	};

	class Smokes
	{
		name = "Smokes";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"SmokeShell",
			"SmokeShellBlue",
			"SmokeShellGreen",
			"SmokeShellOrange",
			"SmokeShellPurple",
			"SmokeShellRed",
			"SmokeShellYellow",
			"1Rnd_Smoke_Grenade_shell",
			"1Rnd_SmokeBlue_Grenade_shell",
			"1Rnd_SmokeGreen_Grenade_shell",
			"1Rnd_SmokeOrange_Grenade_shell",
			"1Rnd_SmokePurple_Grenade_shell",
			"1Rnd_SmokeRed_Grenade_shell",
			"1Rnd_SmokeYellow_Grenade_shell",
			"3Rnd_Smoke_Grenade_shell",
			"3Rnd_SmokeBlue_Grenade_shell",
			"3Rnd_SmokeGreen_Grenade_shell",
			"3Rnd_SmokeOrange_Grenade_shell",
			"3Rnd_SmokePurple_Grenade_shell",
			"3Rnd_SmokeRed_Grenade_shell",
			"3Rnd_SmokeYellow_Grenade_shell"
		};
	};

	class Explosives
	{
		name = "Explosives";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\cargothrow_ca.paa";
		items[] =
		{
			"HandGrenade",
			"MiniGrenade",
			"B_IR_Grenade",
			"O_IR_Grenade",
			"I_IR_Grenade",
			"1Rnd_HE_Grenade_shell",
			"3Rnd_HE_Grenade_shell",
			"APERSBoundingMine_Range_Mag",
			"APERSMine_Range_Mag",
			"APERSTripMine_Wire_Mag",
			"ClaymoreDirectionalMine_Remote_Mag",
			"DemoCharge_Remote_Mag",
			"IEDLandBig_Remote_Mag",
			"IEDLandSmall_Remote_Mag",
			"IEDUrbanBig_Remote_Mag",
			"IEDUrbanSmall_Remote_Mag",
			"SatchelCharge_Remote_Mag",
			"SLAMDirectionalMine_Wire_Mag"
		};
	};

	class Cars_Trucks
	{
		name = "Cars & Trucks";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"B_G_Offroad_01_F",
			"O_G_Offroad_01_F",
			"C_Offroad_01_F",
			"Exile_Car_Ikarus_Blue",
			"Ikarus_Govnodav_01",
			"Ikarus_Govnodav_02",
			"SUV_civ_01",
			"B_G_Offroad_01_repair_F",
			"O_G_Offroad_01_repair_F",
			"I_G_Offroad_01_repair_F",
			"B_G_Offroad_01_armed_F",
			"O_G_Offroad_01_armed_F",
			"I_G_Offroad_01_AT_F",
			"I_G_Offroad_01_armed_F",
			"O_G_Offroad_01_AT_F",
			"B_G_Offroad_01_AT_F",
			"Exile_Car_HMMWV_M2_Desert",
			"Exile_Car_HMMWV_M2_Green",
			"HMMWV_M2_GPK_Base",
			"HMMWV_M2_GPK_1",
			"HMMWV_M2_des",
			"Exile_Car_SUV_Armed_Black",
			"SUV_armored_Base",
			"UAZ_AGS30_Base",
			"UAZ_MG_Base",
			"B_G_Van_01_fuel_F",
			"O_G_Van_01_transport_F",
			"O_G_Van_01_fuel_F",
			"B_G_Van_01_transport_F",
			"I_G_Van_01_transport_F",
			"I_G_Van_01_fuel_F",
			"C_Van_01_transport_F",
			"C_Van_01_box_F",
			"C_Van_01_fuel_F",
			"Exile_Car_V3S_Covered",
			"Exile_Car_V3S_Open",
			"V3S_base",
			"V3S_Base_EP1",
			"Exile_Car_Van_White",
			"Exile_Car_Van_Box_Guerilla03",
			"Exile_Car_Van_Fuel_Red",
			"Exile_Car_Ural_Covered_Military",
			"Exile_Car_Ural_Covered_Yellow",
			"Exile_Car_Ural_Open_Military",
			"Ural_Civ_03",
			"Ural_Open_Civ_03",
			"Ural_Open_Civ_02",
			"O_Truck_02_transport_F",
			"O_Truck_02_covered_F",
			"I_Truck_02_transport_F",
			"I_Truck_02_covered_F",
			"O_Truck_02_medical_F",
			"O_Truck_02_box_F",
			"O_Truck_02_Ammo_F",
			"O_Truck_02_fuel_F",
			"I_Truck_02_medical_F",
			"I_Truck_02_box_F",
			"I_Truck_02_ammo_F",
			"I_Truck_02_fuel_F",
			"C_Truck_02_fuel_F",
			"C_Truck_02_box_F",
			"O_Truck_03_repair_F",
			"O_Truck_03_medical_F",
			"O_Truck_03_fuel_F",
			"O_Truck_03_transport_F",
			"O_Truck_03_covered_F",
			"O_Truck_03_ammo_F",
			"O_Truck_03_device_F",
			"B_MRAP_01_gmg_F",
			"B_MRAP_01_hmg_F",
			"O_MRAP_02_gmg_F",
			"O_MRAP_02_hmg_F",
			"I_MRAP_03_gmg_F",
			"I_MRAP_03_hmg_F"
		};
	};
	
	class apc_tanks
	{
		name = "APC & Tanks";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"O_APC_Wheeled_02_rcws_v2_F",
			"B_APC_Wheeled_01_cannon_F",
			"I_APC_Wheeled_03_cannon_F",
			"I_APC_tracked_03_cannon_F",
			"B_APC_Tracked_01_CRV_F",
			"B_APC_Tracked_01_rcws_F",
			"O_APC_Tracked_02_cannon_F",
			"O_APC_Tracked_02_AA_F",
			"B_APC_Tracked_01_AA_F",
			"B_MBT_01_cannon_F",
			"B_MBT_01_TUSK_F",
			"O_MBT_02_cannon_F",
			"I_MBT_03_cannon_F"
		};
	};
	
	class DLC_cars_trucks
	{
		name = "DLC Cars & Trucks";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"C_Tractor_01_F",
			"B_GEN_Offroad_01_gen_F",
			"B_GEN_Offroad_01_covered_F",
			"B_GEN_Offroad_01_comms_F",
			"I_E_Offroad_01_F",
			"I_E_Offroad_01_covered_F",
			"I_E_Offroad_01_comms_F",
			"I_G_Offroad_01_F",
			"C_Offroad_01_covered_F",
			"C_Offroad_01_comms_F",
			"C_IDAP_Offroad_01_F",
			"B_LSV_01_armed_F",
			"B_LSV_01_AT_F",
			"B_T_LSV_01_armed_F",
			"B_T_LSV_01_AT_F",
			"O_LSV_02_armed_F",
			"O_LSV_02_AT_F",
			"O_T_LSV_02_armed_F",
			"O_T_LSV_02_AT_F",
			"I_C_Offroad_02_AT_F",
			"I_C_Offroad_02_LMG_F",
			"I_E_Van_02_transport_F",
			"I_E_Van_02_transport_MP_F",
			"I_E_Van_02_vehicle_F",
			"B_GEN_Van_02_transport_F",
			"B_GEN_Van_02_vehicle_F",
			"B_G_Van_02_transport_F",
			"O_G_Van_02_transport_F",
			"O_G_Van_02_vehicle_F",
			"I_C_Van_02_transport_F",
			"I_C_Van_02_vehicle_F",
			"C_Van_02_vehicle_F",
			"C_Van_02_transport_F",
			"C_IDAP_Van_02_transport_F",
			"C_IDAP_Van_02_vehicle_F",
			"I_E_Van_02_medevac_F",
			"C_Van_02_medevac_F",
			"C_Van_02_service_F",
			"C_IDAP_Van_02_medevac_F",
			"I_C_Van_01_transport_F",
			"O_T_Truck_02_Medical_F",
			"O_T_Truck_02_transport_F",
			"O_T_Truck_02_F",
			"I_E_Truck_02_Medical_F",
			"I_E_Truck_02_transport_F",
			"I_E_Truck_02_F",
			"C_IDAP_Truck_02_transport_F",
			"C_IDAP_Truck_02_F",
			"O_T_Truck_03_medical_ghex_F",
			"O_T_Truck_03_transport_ghex_F",
			"O_T_Truck_03_covered_ghex_F",
			"B_Truck_01_transport_F",
			"B_Truck_01_covered_F",
			"B_Truck_01_box_F",
			"B_Truck_01_medical_F",
			"B_T_Truck_01_transport_F",
			"B_T_Truck_01_covered_F",
			"B_T_Truck_01_box_F",
			"B_T_Truck_01_medical_F",
			"B_Truck_01_cargo_F",
			"B_Truck_01_flatbed_F",
			"B_T_Truck_01_cargo_F",
			"B_T_Truck_01_flatbed_F",
			"O_T_Truck_02_Box_F",
			"O_T_Truck_02_Ammo_F",
			"O_T_Truck_02_fuel_F",
			"I_E_Truck_02_Box_F",
			"I_E_Truck_02_Ammo_F",
			"I_E_Truck_02_fuel_F",
			"C_IDAP_Truck_02_water_F",
			"B_Truck_01_Repair_F",
			"B_Truck_01_fuel_F",
			"B_Truck_01_ammo_F",
			"B_T_Truck_01_Repair_F",
			"B_T_Truck_01_fuel_F",
			"B_T_Truck_01_ammo_F",
			"O_T_Truck_03_repair_ghex_F",
			"O_T_Truck_03_fuel_ghex_F",
			"O_T_Truck_03_ammo_ghex_F",
			"O_T_Truck_03_device_ghex_F",
			"B_T_MRAP_01_gmg_F",
			"B_T_MRAP_01_hmg_F",
			"O_T_MRAP_02_gmg_ghex_F",
			"O_T_MRAP_02_hmg_ghex_F"
		};
	};

	class DLC_apc_tanks
	{
		name = "DLC APC & Tanks";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			"I_LT_01_AA_F",
			"I_LT_01_AT_F",
			"I_LT_01_cannon_F",
			"O_T_APC_Wheeled_02_rcws_v2_ghex_F",
			"B_T_APC_Wheeled_01_cannon_F",
			"I_E_APC_tracked_03_cannon_F",
			"B_T_APC_Tracked_01_CRV_F",
			"B_T_APC_Tracked_01_rcws_F",
			"O_T_APC_Tracked_02_cannon_ghex_F",
			"B_T_APC_Tracked_01_AA_F",
			"O_T_APC_Tracked_02_AA_ghex_F",
			"B_AFV_Wheeled_01_cannon_F",
			"B_T_AFV_Wheeled_01_cannon_F",
			"B_AFV_Wheeled_01_up_cannon_F",
			"B_T_AFV_Wheeled_01_up_cannon_F",
			"O_T_MBT_02_cannon_ghex_F",
			"B_T_MBT_01_cannon_F",
			"B_T_MBT_01_TUSK_F",
			"O_MBT_04_cannon_F",
			"O_T_MBT_04_cannon_F",
			"O_MBT_04_command_F",
			"O_T_MBT_04_command_F"
		};
	};

	class CUP_cars_trucks
	{
		name = "CUP Cars & Trucks";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			//"CUP_B_Boxer_HMG_GER_WDL",
			"CUP_B_TowingTractor_USMC",
			"CUP_O_UAZ_AGS30_SLA",
			"CUP_O_UAZ_MG_SLA",
			"CUP_O_UAZ_METIS_SLA",
			"CUP_O_UAZ_SPG9_SLA",
			"CUP_O_UAZ_AGS30_RU",
			"CUP_O_UAZ_MG_RU",
			"CUP_O_UAZ_METIS_RU",
			"CUP_O_UAZ_SPG9_RU",
			"CUP_O_UAZ_AGS30_CSAT",
			"CUP_O_UAZ_MG_CSAT",
			"CUP_O_UAZ_METIS_CSAT",
			"CUP_O_UAZ_SPG9_CSAT",
			"CUP_B_LR_Special_Des_CZ_D",
			"CUP_B_LR_Special_GMG_GB_D",
			"CUP_B_LR_Special_GMG_GB_W",
			"CUP_B_LR_Special_M2_GB_D",
			"CUP_B_LR_Special_M2_GB_W",
			"CUP_B_LR_MG_GB_D",
			"CUP_B_LR_MG_GB_W",
			"CUP_I_LR_MG_AAF",
			"CUP_I_LR_SF_GMG_AAF",
			"CUP_I_LR_SF_HMG_AAF",
			"CUP_B_HMMWV_SOV_M2_USA",
			"CUP_B_HMMWV_SOV_USA",
			"CUP_B_HMMWV_SOV_M2_NATO_T",
			"CUP_B_HMMWV_SOV_NATO_T",
			"CUP_B_BAF_Coyote_GMG_D",
			"CUP_B_BAF_Coyote_GMG_W",
			"CUP_B_BAF_Coyote_L2A1_D",
			"CUP_B_BAF_Coyote_L2A1_W",
			"CUP_B_Jackal2_GMG_GB_D",
			"CUP_B_Jackal2_GMG_GB_W",
			"CUP_B_Jackal2_L2A1_GB_D",
			"CUP_B_Jackal2_L2A1_GB_W",
			"CUP_B_HMMWV_AGS_GPK_ACR",
			"CUP_B_HMMWV_DSHKM_GPK_ACR",
			"CUP_B_HMMWV_M2_GPK_ACR",
			"CUP_B_HMMWV_M2_GPK_USA",
			"CUP_B_M1151_M2_USA",
			"CUP_B_M1151_Mk19_USA",
			"CUP_B_M1165_GMV_USA",
			"CUP_B_M1167_USA",
			"CUP_B_HMMWV_M2_USMC",
			"CUP_B_HMMWV_M1114_USMC",
			"CUP_B_HMMWV_MK19_USMC",
			"CUP_B_M1165_GMV_USMC",
			"CUP_B_M1167_USMC",
			"CUP_B_M1151_M2_NATO_T",
			"CUP_B_M1151_Mk19_NATO_T",
			"CUP_B_M1165_GMV_NATO_T",
			"CUP_B_M1167_NATO_T",
			"CUP_B_Dingo_GL_CZ_Des",
			"CUP_B_Dingo_GL_CZ_Wdl",
			"CUP_B_Dingo_CZ_Des",
			"CUP_B_Dingo_CZ_Wdl",
			"CUP_B_Dingo_GL_GER_Des",
			"CUP_B_Dingo_GL_GER_Wdl",
			"CUP_B_Dingo_GER_Des",
			"CUP_B_Dingo_GER_Wdl",
			"CUP_O_GAZ_Vodnik_PK_RU",
			"CUP_O_GAZ_Vodnik_AGS_RU",
			"CUP_O_GAZ_Vodnik_BPPU_RU",
			"CUP_B_RG31E_M2_USA",
			"CUP_B_RG31E_M2_OD_USMC",
			"CUP_B_Ridgback_GMG_GB_D",
			"CUP_B_Ridgback_GMG_GB_W",
			"CUP_B_Ridgback_HMG_GB_D",
			"CUP_B_Ridgback_HMG_GB_W",
			"CUP_B_Ridgback_LMG_GB_D",
			"CUP_B_Ridgback_LMG_GB_W",
			"CUP_B_Wolfhound_GMG_GB_D",
			"CUP_B_Wolfhound_GMG_GB_W",
			"CUP_B_Wolfhound_HMG_GB_D",
			"CUP_B_Wolfhound_HMG_GB_W",
			"CUP_B_Wolfhound_LMG_GB_D",
			"CUP_B_Wolfhound_LMG_GB_W",
			"CUP_B_Mastiff_GMG_GB_W",
			"CUP_B_Mastiff_HMG_GB_D",
			"CUP_B_Mastiff_HMG_GB_W",
			"CUP_B_Mastiff_LMG_GB_D",
			"CUP_B_Mastiff_LMG_GB_W",
			"CUP_B_Mastiff_GMG_GB_D",
			"CUP_B_T810_Armed_CZ_DES",
			"CUP_B_T810_Armed_CZ_WDL",
			"CUP_B_MTVR_USA",
			"CUP_B_MTVR_USMC",
			"CUP_O_Ural_Open_RU",
			"CUP_O_Ural_SLA",
			"CUP_O_Ural_RU",
			"CUP_I_Ural_UN",
			"CUP_O_Kamaz_Open_RU",
			"CUP_O_Kamaz_RU",
			"CUP_B_T810_Reammo_CZ_WDL",
			"CUP_B_T810_Reammo_CZ_DES",
			"CUP_B_T810_Refuel_CZ_DES",
			"CUP_B_T810_Refuel_CZ_WDL",
			"CUP_B_T810_Repair_CZ_DES",
			"CUP_B_T810_Repair_CZ_WDL",
			"CUP_B_MTVR_Ammo_USA",
			"CUP_B_MTVR_Refuel_USA",
			"CUP_B_MTVR_Repair_USA",
			"CUP_B_MTVR_Ammo_USMC",
			"CUP_B_MTVR_Refuel_USMC",
			"CUP_B_MTVR_Repair_USMC",
			"CUP_O_Ural_Reammo_SLA",
			"CUP_O_Ural_Refuel_SLA",
			"CUP_O_Ural_Repair_SLA",
			"CUP_O_Kamaz_Reammo_RU",
			"CUP_O_Kamaz_Refuel_RU",
			"CUP_O_Kamaz_Repair_RU",
			"CUP_O_Ural_Reammo_RU",
			"CUP_O_Ural_Refuel_RU",
			"CUP_O_Ural_Repair_RU",
			"CUP_I_Ural_Repair_UN",
			"CUP_I_Ural_Reammo_UN"
		};
	};

	class CUP_NATO_apc
	{
		name = "CUP NATO APC";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			//"CUP_I_FENNEK_GMG_ION",
			//"CUP_I_FENNEK_HMG_ION",
			//"CUP_I_Hilux_armored_podnos_TK",
			"CUP_B_M113_USA",
			"CUP_B_M113_desert_USA",
			"CUP_I_M113_UN",
			"CUP_I_M113_AAF",
			"CUP_B_M163_USA",
			"CUP_I_M163_AAF",
			"CUP_B_FV432_Bulldog_GB_D",
			"CUP_B_FV432_Bulldog_GB_W",
			"CUP_B_FV432_Bulldog_GB_D_RWS",
			"CUP_B_FV432_Bulldog_GB_W_RWS",
			"CUP_B_M1126_ICV_MK19_Desert",
			"CUP_B_M1126_ICV_MK19_Woodland",
			"CUP_B_M1130_CV_M2_Desert",
			"CUP_B_M1130_CV_M2_Woodland",
			"CUP_B_M1126_ICV_MK19_Desert_Slat",
			"CUP_B_M1126_ICV_MK19_Woodland_Slat",
			"CUP_B_M1130_CV_M2_Desert_Slat",
			"CUP_B_M1130_CV_M2_Woodland_Slat",
			"CUP_B_AAV_USMC",
			"CUP_B_LAV25M240_USMC",
			"CUP_B_LAV25M240_desert_USMC",
			"CUP_B_LAV25M240_green",
			"CUP_B_FV510_GB_D",
			"CUP_B_FV510_GB_W",
			"CUP_B_MCV80_GB_D",
			"CUP_B_MCV80_GB_W",
			"CUP_B_FV510_GB_D_SLAT",
			"CUP_B_FV510_GB_W_SLAT",
			"CUP_B_MCV80_GB_D_SLAT",
			"CUP_B_MCV80_GB_W_SLAT",
			"CUP_B_M7Bradley_USA_D",
			"CUP_B_M7Bradley_USA_W",
			"CUP_B_M2Bradley_NATO_T",
			"CUP_B_M2Bradley_USA_D",
			"CUP_B_M2Bradley_USA_W",
			"CUP_B_M2A3Bradley_NATO_T",
			"CUP_B_M2A3Bradley_USA_D",
			"CUP_B_M2A3Bradley_USA_W",
			"CUP_B_M6LineBacker_USA_D",
			"CUP_B_M6LineBacker_USA_W",
			"CUP_B_M6LineBacker_NATO_T",
			"CUP_B_M1128_MGS_Desert",
			"CUP_B_M1128_MGS_Woodland",
			"CUP_B_M1128_MGS_Desert_Slat",
			"CUP_B_M1128_MGS_Woodland_Slat"
		};
	};

	class CUP_RUS_apc
	{
		name = "CUP Russian APC";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"CUP_B_MTLB_pk_FIA",
			"CUP_O_MTLB_pk_SLA",
			"CUP_O_MTLB_pk_WDL_RU",
			"CUP_O_MTLB_pk_Green_RU",
			"CUP_O_MTLB_pk_Winter_RU",
			"CUP_I_MTLB_pk_NAPA",
			"CUP_I_MTLB_pk_UN",
			"CUP_O_BRDM2_SLA",
			"CUP_O_BRDM2_RUS",
			"CUP_O_BRDM2_CSAT",
			"CUP_O_BRDM2_CSAT_T",
			"CUP_I_BRDM2_TK_Gue",
			"CUP_I_BRDM2_UN",
			"CUP_O_BRDM2_ATGM_SLA",
			"CUP_O_BRDM2_ATGM_RUS",
			"CUP_O_BRDM2_ATGM_CSAT",
			"CUP_O_BRDM2_ATGM_CSAT_T",
			"CUP_I_BRDM2_ATGM_TK_Gue",
			"CUP_B_BTR60_FIA",
			"CUP_O_BTR60_SLA",
			"CUP_O_BTR60_RU",
			"CUP_O_BTR60_Green_RU",
			"CUP_O_BTR60_Winter_RU",
			"CUP_O_BTR60_CSAT",
			"CUP_I_BTR60_UN",
			"CUP_O_BMP2_ZU_CSAT",
			"CUP_O_BMP2_ZU_CSAT_T",
			"CUP_O_ZSU23_SLA",
			"CUP_O_ZSU23_CSAT",
			"CUP_I_ZSU23_AAF",
			"CUP_O_BMP1_CSAT",
			"CUP_O_BMP1P_CSAT",
			"CUP_O_BMP1_CSAT_T",
			"CUP_O_BMP1P_CSAT_T",
			"CUP_I_BMP1_TK_GUE",
			"CUP_O_BMP2_SLA",
			"CUP_O_BMP2_RU",
			"CUP_O_BMP2_CSAT",
			"CUP_O_BMP2_CSAT_T",
			"CUP_I_BMP2_NAPA",
			"CUP_I_BMP2_UN",
			"CUP_O_BTR90_RU",
			"CUP_O_2S6_RU",
			"CUP_O_2S6M_RU",
			"CUP_O_BMP3_RU",
			"CUP_O_BMP3_CSAT_T"
		};
	};

	class CUP_tanks
	{
		name = "CUP Tanks";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"CUP_I_T34_TK_GUE",
			"CUP_O_T55_SLA",
			"CUP_O_T55_CSAT",
			"CUP_O_T55_CSAT_T",
			"CUP_I_T55_TK_GUE",
			"CUP_I_T55_NAPA",
			"CUP_O_T72_SLA",
			"CUP_O_T72_RU",
			"CUP_O_T72_CSAT",
			"CUP_O_T72_CSAT_T",
			"CUP_O_T90_RU",
			"CUP_B_Challenger2_Desert_BAF",
			"CUP_B_Challenger2_Snow_BAF",
			"CUP_B_Challenger2_2CW_BAF",
			"CUP_B_Challenger2_Woodland_BAF",
			"CUP_B_Challenger2_NATO",
			"CUP_B_Challenger2_Sand_CTRG",
			"CUP_B_Challenger2_Green_CTRG",
			"CUP_B_Leopard2A6_GER",
			"CUP_B_M1A1_DES_US_Army",
			"CUP_B_M1A1_Woodland_US_Army",
			"CUP_B_M1A1_NATO_T",
			"CUP_B_M1A2_TUSK_MG_US_Army",
			"CUP_B_M1A2_TUSK_MG_DES_US_Army",
			"CUP_B_M1A2_TUSK_MG_USMC",
			"CUP_B_M1A2_TUSK_MG_DES_USMC"
		};
	};

	class RHS_NATO_cars_trucks
	{
		name = "RHS NATO Cars & Trucks";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"rhsusf_M1078A1R_SOV_M2_D_fmtv_socom",
			"rhsusf_M1084A1R_SOV_M2_D_fmtv_socom",
			"rhsusf_M1078A1P2_B_WD_CP_fmtv_usarmy",
			"rhsusf_M1078A1P2_B_D_CP_fmtv_usarmy",
			"rhsusf_M1078A1P2_B_M2_WD_fmtv_usarmy",
			"rhsusf_M1083A1P2_B_M2_WD_fmtv_usarmy",
			"rhsusf_M1078A1P2_B_M2_D_fmtv_usarmy",
			"rhsusf_M1083A1P2_B_M2_D_fmtv_usarmy",
			"rhsusf_M1078A1P2_B_M2_WD_flatbed_fmtv_usarmy",
			"rhsusf_M1083A1P2_B_M2_WD_flatbed_fmtv_usarmy",
			"rhsusf_M1078A1P2_B_M2_D_flatbed_fmtv_usarmy",
			"rhsusf_M1083A1P2_B_M2_D_flatbed_fmtv_usarmy",
			"rhsusf_M977A4_BKIT_M2_usarmy_wd",
			"rhsusf_M977A4_BKIT_M2_usarmy_d",
			"rhsusf_M1084A1P2_B_M2_D_fmtv_usarmy",
			"rhsusf_M1084A1P2_B_M2_WD_fmtv_usarmy",
			"rhsusf_m1043_w_m2",
			"rhsusf_m1043_w_mk19",
			"rhsusf_m1045_w",
			"rhsusf_m1043_d_m2",
			"rhsusf_m1043_d_mk19",
			"rhsusf_m966_d",
			"rhsusf_M1085A1P2_B_WD_Medical_fmtv_usarmy",
			"rhsusf_M977A4_AMMO_BKIT_M2_usarmy_wd",
			"rhsusf_M977A4_REPAIR_BKIT_M2_usarmy_wd",
			"rhsusf_M978A4_usarmy_wd",
			"rhsusf_M1085A1P2_B_D_Medical_fmtv_usarmy",
			"rhsusf_M977A4_AMMO_BKIT_M2_usarmy_d",
			"rhsusf_M977A4_REPAIR_BKIT_M2_usarmy_d",
			"rhsusf_M978A4_BKIT_usarmy_d",
			"rhsusf_CGRCAT1A2_M2_usmc_wd",
			"rhsusf_CGRCAT1A2_Mk19_usmc_wd",
			"rhsusf_CGRCAT1A2_M2_usmc_d",
			"rhsusf_CGRCAT1A2_Mk19_usmc_d",
			"rhsusf_M1220_M153_M2_usarmy_wd",
			"rhsusf_M1220_M2_usarmy_wd",
			"rhsusf_M1220_M153_MK19_usarmy_wd",
			"rhsusf_M1220_MK19_usarmy_wd",
			"rhsusf_M1220_M153_M2_usarmy_d",
			"rhsusf_M1220_M2_usarmy_d",
			"rhsusf_M1220_MK19_usarmy_d",
			"rhsusf_M1230_M2_usarmy_wd",
			"rhsusf_M1230_MK19_usarmy_wd",
			"rhsusf_M1230_M2_usarmy_d",
			"rhsusf_M1230_MK19_usarmy_d",
			"rhsusf_M1232_M2_usarmy_wd",
			"rhsusf_M1232_MK19_usarmy_wd",
			"rhsusf_M1232_M2_usarmy_d",
			"rhsusf_M1232_MK19_usarmy_d",
			"rhsusf_M1232_MC_M2_usmc_wd",
			"rhsusf_M1232_MC_MK19_usmc_wd",
			"rhsusf_M1232_MC_M2_usmc_d",
			"rhsusf_M1232_MC_MK19_usmc_d",
			"rhsusf_M1237_M2_usarmy_wd",
			"rhsusf_M1237_MK19_usarmy_wd",
			"rhsusf_M1237_M2_usarmy_d",
			"rhsusf_M1237_MK19_usarmy_d",
			"rhsusf_M1238A1_M2_socom_d",
			"rhsusf_M1238A1_Mk19_socom_d",
			"rhsusf_M1239_M2_socom_d",
			"rhsusf_M1239_MK19_socom_d",
			"rhsusf_M1239_M2_Deploy_socom_d",
			"rhsusf_M1239_MK19_Deploy_socom_d"
		};
	};

	class RHS_RUS_cars_trucks
	{
		name = "RHS RUS Cars & Trucks";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"rhs_gaz66_vdv",
			"rhs_gaz66_flat_vdv",
			"rhs_gaz66o_vdv",
			"rhs_gaz66o_flat_vdv",
			"RHS_Ural_VDV_01",
			"RHS_Ural_Open_VDV_01",
			"rhs_kamaz5350_vdv",
			"rhs_kamaz5350_open_vdv",
			"rhs_zil131_vdv",
			"rhs_zil131_open_vdv",
			//"rhs_gaz66_zu23_vdv",	//ошибка
			"rhs_gaz66_r142_vdv",
			"rhs_gaz66_ammo_vdv",
			"rhs_gaz66_ap2_vdv",
			"rhs_gaz66_repair_vdv",
			"RHS_Ural_Fuel_VDV_01",
			"RHS_Ural_Zu23_VDV_01",
			"RHS_Ural_Repair_VDV_01",
			"rhs_typhoon_vdv",
			"rhs_tigr_m_vdv",
			"rhs_tigr_m_3camo_vdv",
			"rhs_tigr_ffv_3camo_vdv",
			"rhs_tigr_3camo_vdv",
			"rhs_tigr_ffv_vdv",
			"rhs_tigr_vdv",
			"rhs_tigr_sts_3camo_vdv",
			"rhs_tigr_sts_vdv"
		};
	};

	class RHS_APC
	{
		name = "RHS APC";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"rhsusf_m113_usarmy_MK19",
			"rhsusf_m113_usarmy",
			"rhsusf_m113_usarmy_M240",
			"rhsusf_m113_usarmy_supply",
			"rhsusf_m113_usarmy_M2_90",
			"rhsusf_m113_usarmy_MK19_90",
			"rhsusf_m113d_usarmy_MK19",
			"rhsusf_m113d_usarmy",
			"rhsusf_m113d_usarmy_M240",
			"rhsusf_m113d_usarmy_supply",
			"rhs_btr60_vmf",
			"rhs_btr60_vdv",
			"rhs_btr60_vv",
			"rhs_btr60_msv",
			"RHS_BTR70_VDV",
			"RHS_BTR70_MSV",
			"RHS_BTR70_VMF",
			"RHS_BTR70_VV",
			"RHS_BTR80_MSV",
			"RHS_BTR80_VV",
			"RHS_BTR80_VDV",
			"RHS_BTR80_VMF",
			"RHS_BTR80A_MSV",
			"RHS_BTR80A_VDV",
			"RHS_BTR80A_VMF",
			"RHS_BTR80A_VV",
			"rhsusf_stryker_m1126_m2_wd",
			"rhs_bmd1r",
			"rhs_bmd1p",
			"rhs_bmd1pk",
			"rhs_bmd1k",
			"rhs_bmd1",
			"rhs_bmd2k",
			"rhs_bmd2m",
			"rhs_bmd2",
			"rhs_bmd4m_vdv",
			"rhs_bmd4ma_vdv",
			"rhs_bmd4_vdv",
			"rhs_bmp1d_vdv",
			"rhs_bmp1k_vdv",
			"rhs_bmp1p_vdv",
			"rhs_bmp1_vdv",
			"rhs_brm1k_vdv",
			"rhs_Ob_681_2",
			"rhs_bmp2d_vdv",
			"rhs_bmp2k_vdv",
			"rhs_bmp2e_vdv",
			"rhs_bmp2_vdv",
			"rhs_zsu234_aa",
			"RHS_M2A2_wd",
			"RHS_M2A2",
			"RHS_M2A3_wd",
			"RHS_M2A3",
			"RHS_M2A2_BUSKI_WD",
			"RHS_M2A2_BUSKI",
			"RHS_M2A3_BUSKI_wd",
			"RHS_M2A3_BUSKI",
			"RHS_M2A3_BUSKIII_wd",
			"RHS_M2A3_BUSKIII",
			"RHS_M6_wd",
			"RHS_M6",
			"rhs_bmp3_msv",
			"rhs_bmp3_late_msv",
			"rhs_bmp3m_msv",
			"rhs_bmp3mera_msv"
		};
	};

	class RHS_tanks
	{
		name = "RHS Tanks";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"rhs_sprut_vdv",
			"rhs_t72ba_tv",
			"rhs_t72bb_tv",
			"rhs_t72bc_tv",
			"rhs_t72bd_tv",
			"rhs_t72be_tv",
			"rhs_t80",
			"rhs_t80b",
			"rhs_t80bk",
			"rhs_t80a",
			"rhs_t80bv",
			"rhs_t80bvk",
			"rhs_t80ue1",
			"rhs_t80um",
			"rhs_t80u",
			"rhs_t80u45m",
			"rhs_t80uk",
			"rhs_t90_tv",
			"rhs_t90a_tv",
			"rhs_t90saa_tv",
			"rhs_t90sab_tv",
			"rhsusf_m1a1fep_wd",
			"rhsusf_m1a1fep_od",
			"rhsusf_m1a1fep_d",
			"rhsusf_m1a1hc_wd",
			"rhsusf_m1a1aimwd_usarmy",
			"rhsusf_m1a1aimd_usarmy",
			"rhsusf_m1a1aim_tuski_wd",
			"rhsusf_m1a1aim_tuski_d",
			"rhsusf_m1a2sep1wd_usarmy",
			"rhsusf_m1a2sep1d_usarmy",
			"rhsusf_m1a2sep1tuskiwd_usarmy",
			"rhsusf_m1a2sep1tuskid_usarmy",
			"rhsusf_m1a2sep1tuskiiwd_usarmy",
			"rhsusf_m1a2sep1tuskiid_usarmy",
			"rhs_t90am_tv",
			//"rhs_t14_tv",
			"rhs_t90sm_tv"
		};
	};
	
		class Mammoth
	{
		name = "Mamoth";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
	        "HTNK",                                     
            "HTNK_Ghex",                                
	        "HTNK_Green",                               
	        "HTNK_SLA",                                
	        "HTNK_Grey",                             
	        "HTNK_Desert",                              
	        "HTNK_Snow",                                
	        "HTNK_Nato",                                
	        "HTNK_Nato_Pacific",                        
	        "HTNK_Gdi",                        
	        "HTNK_us_woodland",                        
	        "HTNK_us_desert",                           
	        "HTNK_us_snow"                            
		};
	};

	class UGV
	{
		name = "UGVs";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"B_UGV_01_rcws_F",
			"O_UGV_01_rcws_F",
			"I_UGV_01_rcws_F"
		};
	};

	class DLC_UGV
	{
		name = "DLC UGVs";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"B_T_UGV_01_rcws_olive_F",
			"O_T_UGV_01_rcws_ghex_F",
			"I_E_UGV_01_rcws_F"
		};
	};


	class Helis_Jets
	{
		name = "Helis & Jets";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"Exile_Chopper_Hummingbird_Green",
			"B_Heli_Light_01_F",
			"B_Heli_Light_01_dynamicLoadout_F",
			"Exile_Chopper_Mohawk_FIA",
			"Exile_Chopper_Huron_Green",
			"Exile_Chopper_Huron_Black",
			"Exile_Chopper_Taru_Black",
			"Exile_Chopper_Taru_CSAT",
			"Exile_Chopper_Taru_Covered_CSAT",
			"Exile_Chopper_Taru_Covered_Black",
			"Exile_Chopper_Taru_Transport_Black",
			"Exile_Chopper_Taru_Transport_CSAT",
			"I_Heli_Transport_02_F",
			"B_Heli_Transport_01_F",
			"O_Heli_Light_02_dynamicLoadout_F",
			"I_Heli_light_03_dynamicLoadout_F",
			"O_Heli_Attack_02_dynamicLoadout_F",
			"B_Heli_Attack_01_dynamicLoadout_F",
			"O_Heli_Attack_02_F",
			"O_Heli_Attack_02_black_F",
			"Exile_Plane_BlackfishVehicle",
			//JETS
			"I_Plane_Fighter_03_dynamicLoadout_F",
			"O_Plane_CAS_02_dynamicLoadout_F",
			"B_Plane_CAS_01_dynamicLoadout_F",
			"B_Plane_CAS_01_F"
		};
	};

	class UAV
	{
		name = "UAVs";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"B_UAV_02_dynamicLoadout_F",
			"O_UAV_02_dynamicLoadout_F",
			"I_UAV_02_dynamicLoadout_F"
		};
	};

	class DLC_Helis_Jets
	{
		name = "DLC Helis & Jets";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"O_Heli_Transport_04_F",
			"O_Heli_Transport_04_ammo_F",
			"O_Heli_Transport_04_box_F",
			"O_Heli_Transport_04_medevac_F",
			"O_Heli_Transport_04_repair_F",
			"O_Heli_Transport_04_bench_F",
			"O_Heli_Transport_04_fuel_F",
			"O_Heli_Transport_04_covered_F",
			"B_CTRG_Heli_Transport_01_sand_F",
			"B_CTRG_Heli_Transport_01_tropic_F",
			"B_Heli_Transport_03_F",
			"I_E_Heli_light_03_unarmed_F",
			"I_E_Heli_light_03_dynamicLoadout_F",
			"B_T_VTOL_01_vehicle_F",
			"B_T_VTOL_01_infantry_F",
			"B_T_VTOL_01_armed_olive_F",
			"B_T_VTOL_01_armed_blue_F",
			"B_T_VTOL_01_armed_F",	
			"O_T_VTOL_02_vehicle_dynamicLoadout_F",
			"O_T_VTOL_02_infantry_dynamicLoadout_F",
			//JETS
			"I_Plane_Fighter_04_F",
			"O_Plane_Fighter_02_F",
			"O_Plane_Fighter_02_Stealth_F",
			"B_Plane_Fighter_01_F",
			"B_Plane_Fighter_01_Stealth_F"
		};
	};

	class DLC_UAVs
	{
		name = "DLC UAVs";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"B_T_UAV_03_dynamicLoadout_F",
			"O_T_UAV_04_CAS_F",
			"B_UAV_05_F",
			"CUP_B_USMC_MQ9"
		};
	};

	class CUP_helis
	{
		name = "CUP Helis";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"CUP_B_AH1Z_NoWeapons",
			"CUP_B_MH6J_USA",
			"CUP_B_AH6M_USA",
			"CUP_B_Merlin_HC3_VIV_GB",
			"CUP_B_CH47F_VIV_USA",
			"CUP_I_CH47F_VIV_RACS",
			"CUP_O_MI6A_RU",
			"CUP_C_MI6A_RU",
			"CUP_O_MI6A_CSAT_T",
			"CUP_I_MI6A_UN",
			"CUP_B_CH53E_VIV_GER",
			"CUP_B_CH53E_VIV_USMC",
			"CUP_B_UH60M_US",
			"CUP_B_UH60S_USN",
			"CUP_B_UH1D_armed_GER_KSK",
			"CUP_B_UH1D_armed_GER_KSK_Des",
			"CUP_B_UH1Y_Gunship_Dynamic_USMC",
			"CUP_B_UH1D_gunship_GER_KSK_Des",
			"CUP_B_UH1D_gunship_GER_KSK",
			"CUP_O_Ka60_Grey_RU",
			"CUP_O_Ka60_Hex_CSAT",
			"CUP_O_Ka60_Whale_CSAT",
			"CUP_I_Ka60_Digi_AAF",
			"CUP_I_Ka60_GL_Digi_AAF",
			"CUP_O_Mi8_RU",
			"CUP_B_MH60L_DAP_2x_US",
			"CUP_B_MH60L_DAP_2x_USN",
			"CUP_B_MH60L_DAP_4x_US",
			"CUP_B_MH60L_DAP_4x_USN",
			"CUP_B_AW159_GB",
			"CUP_I_Wildcat_Green_AAF",
			"CUP_I_Wildcat_Digital_AAF",
			"CUP_O_Mi24_V_Dynamic_RU",
			"CUP_O_Mi24_P_Dynamic_RU",
			"CUP_O_Mi24_V_Dynamic_CSAT_T",
			"CUP_O_Mi24_D_Dynamic_CSAT_T",
			"CUP_O_Mi24_P_Dynamic_CSAT_T",
			"CUP_I_Mi24_D_Dynamic_UN",
			"CUP_I_Mi24_D_Dynamic_AAF",
			"CUP_O_Mi24_Mk3_CSAT_T",
			"CUP_I_Mi24_Mk3_UN",
			"CUP_I_Mi24_Mk3_AAF",
			"CUP_I_Mi24_Mk3_FAB_AAF",
			"CUP_I_Mi24_Mk3_AT_AAF",
			"CUP_I_Mi24_Mk3_S8_GSh_AAF",
			"CUP_O_Mi24_Mk3_S8_GSh_CSAT_T",
			"CUP_O_Mi24_Mk3_AT_CSAT_T",
			"CUP_O_Mi24_Mk3_FAB_CSAT_T",
			"CUP_I_Mi24_Mk3_AT_UN",
			"CUP_I_Mi24_Mk3_S8_GSh_UN",
			"CUP_I_Mi24_Mk3_FAB_UN",
			"CUP_O_Mi24_Mk4_CSAT_T",
			"CUP_I_Mi24_Mk4_UN",
			"CUP_I_Mi24_Mk4_AAF",
			"CUP_I_Mi24_Mk4_AT_AAF",
			"CUP_I_Mi24_Mk4_FAB_AAF",
			"CUP_I_Mi24_Mk4_S8_GSh_AAF",
			"CUP_O_Mi24_Mk4_AT_CSAT_T",
			"CUP_O_Mi24_Mk4_FAB_CSAT_T",
			"CUP_O_Mi24_Mk4_S8_GSh_CSAT_T",
			"CUP_I_Mi24_Mk4_AT_UN",
			"CUP_I_Mi24_Mk4_FAB_UN",
			"CUP_I_Mi24_Mk4_S8_GSh_UN",
			"CUP_B_Mi171Sh_ACR",
			"CUP_B_AH1Z_Dynamic_USMC",
			"CUP_I_AH1Z_Dynamic_AAF",
			"CUP_O_Ka50_DL_RU",
			"CUP_O_Ka50_DL_SLA",
			"CUP_O_Ka50_SLA",
			"CUP_O_Ka52_RU",
			"CUP_O_Ka52_Grey_RU",
			"CUP_O_Ka52_GreyCamo_RU",
			"CUP_B_AH64_DL_USA",
			"CUP_B_AH64D_ES_USA",
			"CUP_B_AH64D_DL_USA"
		};
	};

	class CUP_Jets
	{
		name = "CUP Jets";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"CUP_B_C130J_USMC",
			"CUP_B_C130J_Cargo_USMC",
			"CUP_I_L39_AAF",
			"CUP_O_Su25_Dyn_RU",
			"CUP_B_Su25_CDF",
			"CUP_O_Su25_TKA",
			"CUP_O_Su25_SLA",
			"CUP_O_Su25_RU_1",
			"CUP_O_Su25_RU_2",
			"CUP_O_Su25_RU_3",
			"CUP_B_A10_DYN_USA",
			"CUP_B_A10_CAS_USA",
			"CUP_B_A10_AT_USA",
			"CUP_B_GR9_DYN_GB",
			"CUP_B_GR9_CAP_GB",
			"CUP_B_GR9_Mk82_GB",
			"CUP_B_GR9_GBU12_GB",
			"CUP_B_GR9_AGM_GB",
			"CUP_B_AV8B_DYN_USMC",
			"CUP_I_AV8B_DYN_AAF",
			"CUP_B_AV8B_CAP_USMC",
			"CUP_I_AV8B_CAP_AAF",
			"CUP_B_AV8B_MK82_USMC",
			"CUP_I_AV8B_MK82_AAF",
			"CUP_B_AV8B_GBU12_USMC",
			"CUP_I_AV8B_GBU12_AAF",
			"CUP_B_AV8B_AGM_USMC",
			"CUP_I_AV8B_AGM_AAF",
			"CUP_B_SU34_CDF",
			"CUP_O_SU34_RU",
			"CUP_I_SU34_AAF",
			"CUP_O_SU34_LGB_RU",
			"CUP_O_SU34_AGM_RU",
			"CUP_O_SU34_LGB_SLA",
			"CUP_O_SU34_AGM_SLA",
			"CUP_I_SU34_LGB_AAF",
			"CUP_I_SU34_AGM_AAF",
			"CUP_B_SU34_LGB_CDF",
			"CUP_B_SU34_AGM_CDF",
			"CUP_B_F35B_BAF",
			"CUP_B_F35B_Stealth_BAF",
			"CUP_B_F35B_AA_USMC",
			"CUP_B_F35B_CAS_USMC",
			"CUP_B_F35B_LGB_USMC",
			"CUP_B_F35B_AA_BAF",
			"CUP_B_F35B_CAS_BAF",
			"JS_JC_SU35",
			"CUP_B_F35B_LGB_BAF"
		};
	};
	
	class CUP_UAV
	{
		name = "CUP UAV";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"CUP_B_AH6X_USA",
			"CUP_B_USMC_DYN_MQ9",
			"CUP_B_USMC_MQ9",
			"CUP_B_Pchela1T_CDF",
			"CUP_O_Pchela1T_RU"
		};
	};


	class RHS_Helis
	{
		name = "RHS Helis";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"RHS_MELB_H6M",
			"RHS_MELB_MH6M",
			"rhs_ka60_c",
			"rhs_ka60_grey",
			"RHS_CH_47F",
			"RHS_CH_47F_light",
			"rhsusf_CH53E_USMC_GAU21",
			"RHS_Mi8mt_vvsc",
			"RHS_Mi8mt_vvs",
			"RHS_Mi8mt_vdv",
			"RHS_MELB_AH6M",
			"RHS_UH1Y",
			"RHS_Mi8MTV3_vvsc",
			"RHS_Mi8MTV3_vvs",
			"RHS_Mi8mtv3_Cargo_vvs",
			"RHS_Mi8MTV3_vdv",
			"RHS_Mi8mtv3_Cargo_vdv",
			"RHS_Mi8AMTSh_vvsc",
			"RHS_Mi8MTV3_heavy_vvsc",
			"RHS_Mi8AMTSh_vvs",
			"RHS_Mi8MTV3_heavy_vvs",
			"RHS_Mi8MTV3_heavy_vdv",
			"RHS_Mi24Vt_vvs",
			"RHS_Mi24P_vvs",
			"RHS_Mi24P_vvsc",
			"RHS_Mi24P_CAS_vvs",
			"RHS_Mi24P_CAS_vvsc",
			"RHS_Mi24P_CAS_vdv",
			"RHS_Mi24P_AT_vvs",
			"RHS_Mi24P_AT_vvsc",
			"RHS_Mi24P_AT_vdv",
			"RHS_Mi24P_vdv",
			"RHS_Mi24V_vvs",
			"RHS_Mi24V_vvsc",
			"RHS_Mi24V_FAB_vvs",
			"RHS_Mi24V_FAB_vvsc",
			"RHS_Mi24V_FAB_vdv",
			"RHS_Mi24V_UPK23_vvs",
			"RHS_Mi24V_UPK23_vvsc",
			"RHS_Mi24V_UPK23_vdv",
			"RHS_Mi24V_AT_vvs",
			"RHS_Mi24V_AT_vvsc",
			"RHS_Mi24V_AT_vdv",
			"RHS_Mi24V_vdv",
			"rhs_mi28n_vvs",
			"rhs_mi28n_vvsc",
			"rhs_mi28n_s13_vvs",
			"rhs_mi28n_s13_vvsc",
			"RHS_AH1Z",
			"RHS_AH1Z_wd",
			"RHS_AH1Z_CS",
			"RHS_AH1Z_wd_GS",
			"RHS_AH1Z_wd_CS",
			"RHS_Ka52_vvsc",
			"RHS_Ka52_vvs",
			"RHS_Ka52_UPK23_vvs",
			"RHS_Ka52_UPK23_vvsc",
			"RHS_AH64D",
			"RHS_AH64D_CS",
			"RHS_AH64D_wd_GS",
			"RHS_AH64D_AA",
			"RHS_AH64DGrey"
		};
	};

	class RHS_Jets
	{
		name = "RHS Jets";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"RHS_Su25SM_vvsc",
			"RHS_Su25SM_vvs",
			"RHS_Su25SM_CAS_vvsc",
			"RHS_A10",
			//"RHS_A10_AT",
			"rhs_mig29s_vvsc",
			"rhs_mig29s_vvs",
			"rhs_mig29s_vmf",
			"rhs_mig29sm_vvsc",
			"rhs_mig29sm_vvs",
			"rhs_mig29sm_vmf",
			"RHS_T50_vvs_051",
			"RHS_T50_vvs_052",
			"RHS_T50_vvs_053",
			"RHS_T50_vvs_054",
			"RHS_T50_vvs_blueonblue",
			"RHS_T50_vvs_generic_ext",
			"rhsusf_f22"
		};
	};


	class Boats
	{
		name = "Boats";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"Exile_Boat_WaterScooter",
			"B_Boat_Transport_01_F",
			"O_Boat_Transport_01_F",
			"I_Boat_Transport_01_F",
			"Exile_Boat_RHIB",
			"C_Boat_Civil_01_F",
			"C_Boat_Civil_01_police_F",
			"C_Boat_Civil_01_rescue_F",
			"Exile_Boat_MotorBoat_Orange",
			"Exile_Boat_SDV_CSAT",
			"B_Boat_Armed_01_minigun_F",
			"O_Boat_Armed_01_hmg_F",
			"I_Boat_Armed_01_minigun_F"
		};
	};

	
	class UAVs
	{
		name = "UAVs";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\gps_ca.paa";
		items[] = 
		{
			"I_UavTerminal",
			"I_UAV_01_backpack_F",
			"I_UAV_06_medical_backpack_F",
			"I_UAV_06_backpack_F"
		};
	};

	class Trubi
	{
		name = "Launchers";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			
			"Titan_AA",
			"launch_RPG32_F",
			"RPG32_HE_F",
			"RPG32_F",
			"launch_O_Titan_F",								
			"launch_B_Titan_F",							
			"launch_I_Titan_F",
			"launch_O_Titan_short_F",
			"launch_I_Titan_short_F",
			"launch_B_Titan_short_F",
			"Titan_AP",
			"Titan_AT",
			"launch_NLAW_F",
			"NLAW_F"
		
		};
	};
	
	class Minometi
	{
		name = "Mortars";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			
			"I_Mortar_01_support_F",
			"I_Mortar_01_weapon_F"
		};
	};
	
	class Pulimeti
	{
		name = "HMGs";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
			
			"B_HMG_01_A_weapon_F",
			"B_HMG_01_support_high_F"
		};
	};

	class Blackmarket6
	{
		name = "8G Ammo";

		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemoptic_ca.paa";
		items[] = 
		{
			
		    "Exile_Magazine_5Rnd_127x108_Bullet_Cam_Mag",
			"Exile_Magazine_5Rnd_127x108_APDS_Bullet_Cam_Mag",
			"Exile_Magazine_10Rnd_93x64_DMR_05_Bullet_Cam_Mag",
			"Exile_Magazine_7Rnd_408_Bullet_Cam_Mag",
			"Exile_Magazine_10Rnd_338_Bullet_Cam_Mag",
			"Exile_Magazine_10Rnd_127x99_m107_Bullet_Cam_Mag",
			"Exile_Magazine_5Rnd_127x108_KSVK_Bullet_Cam_Mag",
			"Exile_Magazine_5Rnd_127x108_APDS_KSVK_Bullet_Cam_Mag",
			"Exile_Magazine_5Rnd_127x108_APDS_KSVK",
			"Exile_Magazine_5Rnd_127x108_KSVK"
			
		};
	};
	
	class Hardware 
	{
		name = "Hardware";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{
		    "Exile_Melee_SledgeHammer",
		    "Exile_Item_DuctTape",
		    "Exile_Item_Rope",
		    "Exile_Item_FuelCanisterEmpty",
			"Exile_Item_WaterCanisterEmpty",
		    "Exile_Item_CarWheel",
		    "Exile_Item_ExtensionCord",
		    "Exile_Item_Pliers",
		    "Exile_Item_Foolbox",
		    "Exile_Item_Shovel",
		    "Exile_Item_CookingPot",
		    "Exile_Item_CordlessScrewdriver",
		    "Exile_Item_FireExtinguisher",
		    "Exile_Item_Hammer",
		    "Exile_Item_OilCanister",
		    "Exile_Item_Screwdriver",
		    "Exile_Item_Wrench",
		    "Exile_Item_Handsaw",
		    "Exile_Item_Matches",
		    "Exile_Melee_Axe",
		    "Exile_Magazine_Swing",
		    //"Exile_Melee_SledgeHammmer",
		    "Exile_Item_Grinder",
			//"Exile_Item_MobilePhone",
		    "Exile_Item_Knife"
		};
	};

	class WoodBuild
	{
		name = "Wood Build";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemoptic_ca.paa";
		items[] = 
		{
		    "Exile_Item_WoodDrawBridgeKit",
		    "Exile_Item_WoodFloorPortSmallKit",
		    "Exile_Item_WoodLadderKit",
		    "Exile_Item_WoodWallHalfKit",
		    "Exile_Item_WoodDoorKit",
		    "Exile_Item_WoodDoorwayKit",
		    "Exile_Item_WoodFloorKit",
		    "Exile_Item_WoodFloorPortKit",
		    "Exile_Item_WoodGateKit",
		    "Exile_Item_WoodStairsKit",
		    "Exile_Item_WoodSupportKit",
		    "Exile_Item_WoodWallKit",
		    "Exile_Item_WoodWindowKit",
		    "Exile_Item_WorkBenchKit",
		    "Exile_Item_WoodLadderHatchKit"

  
   
		};
	};
	class ConcreteBuild
	{
		name = "Concrete Build";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemoptic_ca.paa";
		items[] = 
		{
		    "Exile_Item_ConcreteDoorKit",
		    "Exile_Item_ConcreteDoorwayKit",
		    "Exile_Item_ConcreteFloorKit",
		    "Exile_Item_ConcreteFloorPortKit",
		    "Exile_Item_ConcreteGateKit",
		    "Exile_Item_ConcreteWindowKit",
		    "Exile_Item_ConcreteStairsKit",
		    "Exile_Item_ConcreteSupportKit",
		    "Exile_Item_ConcreteWallKit",
		    "Exile_Item_ConcreteDrawBridgeKit",
		    "Exile_Item_ConcreteFloorPortSmallKit",
		    "Exile_Item_ConcreteLadderHatchKit",
		    "Exile_Item_MetalLadderKit",
		    "Exile_Item_MetalLadderDoubleKit"
		
		
	    };
	};

	class OtherBuild
	{
		name = "Other Build";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemoptic_ca.paa";
		items[] = 
		{
		    "Exile_Item_FortificationUpgrade",
		    "Exile_Item_SandBagsKit_Long",
		    "Exile_Item_SandBagsKit_Corner",
		    "Exile_Item_HBarrier5Kit",
		    "Exile_Item_WireFenceKit",
		    "Exile_Item_RepairKitConcrete",
		    "Exile_Item_MetalHedgehogKit",
		    "Exile_Item_CampFireKit",
		    "Exile_Item_SafeKit",
		    "Exile_Item_SafeSmallKit",
		    "Exile_Item_OldChestKit",
		    "Exile_Item_JunkMetal",
		    "Exile_Item_MetalWire",
		    "Exile_Item_MetalScrews",
		    "Exile_Item_MetalBoard",
		    "Exile_Item_MetalPole",
		    "Exile_Item_CodeLock",
		    "Exile_Item_Laptop",
		    "Exile_Item_BaseCameraKit",
		    "Exile_Item_FloodLightKit",
		    "Exile_Item_PortableGeneratorKit",
		    "Exile_Item_Cement",
		    "Exile_Item_Sand",
		    "Exile_Item_CamoTentKit"
		};
	};
	
	/* class Blackmarket7
	{
		name = "Special Equipment";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemoptic_ca.paa";
		items[] = 
		{
		     //"G_B_Diving",
		    //"G_O_Diving",
		    //"G_I_Diving",
		    //"V_RebreatherB",
		    //"V_RebreatherIA",
		    //"V_RebreatherIR",
		    //"U_I_Wetsuit",
		    //"U_O_Wetsuit",
		    //"U_B_Wetsuit",
		    //"EBM_Backpack_dev"
		};
	}; */
	
    class CUPLauncherAmmo 
	{
		name = "CUP Launcher Ammo";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] = 
		{	
 
			"CUP_Igla_M",
            "CUP_M136_M",
            "CUP_MAAWS_HEAT_M",
            "CUP_MAAWS_HEDP_M",
            "CUP_AT13_M",
            "CUP_NLAW_M",
            "CUP_PG7V_M",
            "CUP_PG7VL_M",
            "CUP_PG7VR_M",
            "CUP_OG7_M",
            "CUP_RPG18_M",
            "CUP_SMAW_HEAA_M",
            "CUP_SMAW_HEDP_M",
            "CUP_Stinger_M",
            "CUP_Strela_2_M",
            "CUP_Dragon_EP1_M",
            "CUP_Javelin_M",
            "CUP_6Rnd_HE_M203",
            "CUP_6Rnd_FlareWhite_M203",
            "CUP_6Rnd_FlareGreen_M203",
            "CUP_6Rnd_FlareRed_M203",
            "CUP_6Rnd_FlareYellow_M203",
            "CUP_6Rnd_Smoke_M203",
            "CUP_6Rnd_SmokeRed_M203",
            "CUP_6Rnd_SmokeGreen_M203",
            "CUP_6Rnd_SmokeYellow_M203",
            "CUP_1Rnd_HE_M203",
            "CUP_1Rnd_HEDP_M203",
            "CUP_FlareWhite_M203",
            "CUP_FlareGreen_M203",
            "CUP_FlareRed_M203",
            "CUP_FlareYellow_M203",
            "CUP_1Rnd_Smoke_M203",
            "CUP_1Rnd_SmokeRed_M203",
            "CUP_1Rnd_SmokeGreen_M203",
            "CUP_1Rnd_SmokeYellow_M203" 				
		};
	};				
	class CUPUniforms
	{
		name = "CUP Uniforms";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
		   "CUP_U_O_RUS_Ratnik_Summer",
		   "CUP_O_TKI_Khet_Partug_01",
           "CUP_O_TKI_Khet_Partug_02",
           "CUP_O_TKI_Khet_Partug_03",
           "CUP_O_TKI_Khet_Partug_04",
           "CUP_O_TKI_Khet_Partug_05",
           "CUP_O_TKI_Khet_Partug_06",
           "CUP_O_TKI_Khet_Partug_07",
           "CUP_O_TKI_Khet_Partug_08",
           "CUP_O_TKI_Khet_Jeans_01",
           "CUP_O_TKI_Khet_Jeans_02",
           "CUP_O_TKI_Khet_Jeans_03",
           "CUP_O_TKI_Khet_Jeans_04",
           "CUP_U_C_Pilot_01",
           "CUP_U_C_Citizen_01",
           "CUP_U_C_Citizen_02",
           "CUP_U_C_Citizen_03",
           "CUP_U_C_Citizen_04",
           "CUP_U_C_Worker_01",
           "CUP_U_C_Worker_02",
           "CUP_U_C_Worker_03",
           "CUP_U_C_Worker_04",
           "CUP_U_C_Profiteer_01",
           "CUP_U_C_Profiteer_02",
           "CUP_U_C_Profiteer_03",
           "CUP_U_C_Profiteer_04",
           "CUP_U_C_Woodlander_01",
           "CUP_U_C_Woodlander_02",
           "CUP_U_C_Woodlander_03",
           "CUP_U_C_Woodlander_04",
           "CUP_U_C_Villager_01",
           "CUP_U_C_Villager_02",
           "CUP_U_C_Villager_03",
           "CUP_U_C_Villager_04",
           "CUP_U_B_CZ_WDL_TShirt",
           "CUP_U_B_GER_Tropentarn_1",
           "CUP_U_B_GER_Tropentarn_2",
           "CUP_U_B_GER_Ghillie",
           "CUP_U_B_GER_Flecktarn_1",
           "CUP_U_B_GER_Flecktarn_2",
           "CUP_U_B_GER_Fleck_Ghillie",
           "CUP_U_B_USMC_Officer",
           "CUP_U_B_USMC_PilotOverall",
           "CUP_U_B_USMC_Ghillie_WDL",
           "CUP_U_B_USMC_MARPAT_WDL_Sleeves",
           "CUP_U_B_USMC_MARPAT_WDL_RolledUp",
           "CUP_U_B_USMC_MARPAT_WDL_Kneepad",
           "CUP_U_B_USMC_MARPAT_WDL_TwoKneepads",
           "CUP_U_B_USMC_MARPAT_WDL_RollUpKneepad",
           "CUP_U_B_FR_SpecOps",
           "CUP_U_B_FR_Scout",
           "CUP_U_B_FR_Scout1",
           "CUP_U_B_FR_Scout2",
           "CUP_U_B_FR_Scout3",
           "CUP_U_B_FR_Officer",
           "CUP_U_B_FR_Corpsman",
           "CUP_U_B_FR_DirAction",
           "CUP_U_B_FR_DirAction2",
           "CUP_U_B_FR_Light",
           "CUP_U_I_GUE_Flecktarn",
           "CUP_U_I_GUE_Flecktarn2",
           "CUP_U_I_GUE_Flecktarn3",
           "CUP_U_I_GUE_Woodland1",
           "CUP_U_I_Ghillie_Top",
           "CUP_U_I_RACS_PilotOverall",
           "CUP_U_I_RACS_Desert_1",
           "CUP_U_I_RACS_Desert_2",
           "CUP_U_I_RACS_Urban_1",
           "CUP_U_I_RACS_Urban_2",
           "CUP_U_O_SLA_Officer",
           "CUP_U_O_SLA_Officer_Suit",
           "CUP_U_O_SLA_MixedCamo",
           "CUP_U_O_SLA_Green",
           "CUP_U_O_SLA_Urban",
           "CUP_U_O_SLA_Desert",
           "CUP_U_O_SLA_Overalls_Pilot",
           "CUP_U_O_SLA_Overalls_Tank",
           "CUP_U_O_Partisan_TTsKO",
           "CUP_U_O_Partisan_TTsKO_Mixed",
           "CUP_U_O_Partisan_VSR_Mixed1",
           "CUP_U_O_Partisan_VSR_Mixed2",
           "CUP_U_O_TK_Officer",
           "CUP_U_O_TK_MixedCamo",
           "CUP_U_O_TK_Green",
           "CUP_U_O_TK_Ghillie",
           "CUP_U_O_TK_Ghillie_Top",
	       "CUP_U_B_BAF_DDPM_S1_RolledUp",
	       "CUP_U_B_BAF_DDPM_Tshirt",
	       "CUP_U_B_BAF_DPM_S1_RolledUp",
	       "CUP_U_B_BAF_DPM_S2_UnRolled",
	       "CUP_U_B_BAF_DPM_Tshirt",
	       "CUP_U_B_BAF_MTP_S1_RolledUp",
	       "CUP_U_B_BAF_MTP_S2_UnRolled",
	       "CUP_U_B_BAF_MTP_Tshirt",
	       "CUP_U_B_BAF_MTP_S3_RolledUp",
	       "CUP_U_B_BAF_MTP_S4_UnRolled",
	       "CUP_U_B_BAF_MTP_S5_UnRolled",
	       "CUP_U_B_BAF_MTP_S6_UnRolled"
	 
		};
	};
	class CUPHeadgear
	{
		name = "CUP Headgear";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"CUP_H_RUS_Balaclava_Ratnik_Headphones",
	        "CUP_H_C_Ushanka_01",
            "CUP_H_PMC_EP_Headset",
            "CUP_H_PMC_Cap_Tan",
            "CUP_H_PMC_Cap_Grey",
            "CUP_H_PMC_Cap_PRR_Tan",
            "CUP_H_PMC_Cap_PRR_Grey",
            "CUP_H_RACS_Beret_Blue",
            "CUP_H_RACS_Helmet_Des",
            "CUP_H_RACS_Helmet_Goggles_Des",
            "CUP_H_RACS_Helmet_Headset_Des",
            "CUP_H_RACS_Helmet_DPAT",
            "CUP_H_RACS_Helmet_Goggles_DPAT",
            "CUP_H_RACS_Helmet_Headset_DPAT",
            "CUP_H_SLA_TankerHelmet",
            "CUP_H_SLA_Helmet",
            "CUP_H_SLA_Pilot_Helmet",
            "CUP_H_SLA_OfficerCap",
            "CUP_H_SLA_SLCap",
            "CUP_H_SLA_Boonie",
            "CUP_H_SLA_Beret",
            "CUP_H_SLA_BeretRed",
            "CUP_H_TK_TankerHelmet",
            "CUP_H_TK_PilotHelmet",
            "CUP_H_TK_Helmet",
            "CUP_H_TK_Lungee",
            "CUP_H_TK_Beret",
            "CUP_H_TKI_SkullCap_01",
            "CUP_H_TKI_SkullCap_02",
            "CUP_H_TKI_SkullCap_03",
            "CUP_H_TKI_SkullCap_04",
            "CUP_H_TKI_SkullCap_05",
            "CUP_H_TKI_SkullCap_06",
            "CUP_H_TKI_Lungee_01",
            "CUP_H_TKI_Lungee_02",
            "CUP_H_TKI_Lungee_03",
            "CUP_H_TKI_Lungee_04",
            "CUP_H_TKI_Lungee_05",
            "CUP_H_TKI_Lungee_06",
            "CUP_H_TKI_Lungee_Open_01",
            "CUP_H_TKI_Lungee_Open_02",
            "CUP_H_TKI_Lungee_Open_03",
            "CUP_H_TKI_Lungee_Open_04",
            "CUP_H_TKI_Lungee_Open_05",
            "CUP_H_TKI_Lungee_Open_06",
            "CUP_H_TKI_Pakol_1_01",
            "CUP_H_TKI_Pakol_1_02",
            "CUP_H_TKI_Pakol_1_03",
            "CUP_H_TKI_Pakol_1_04",
            "CUP_H_TKI_Pakol_1_05",
            "CUP_H_TKI_Pakol_1_06",
            "CUP_H_TKI_Pakol_2_01",
            "CUP_H_TKI_Pakol_2_02",
            "CUP_H_TKI_Pakol_2_03",
            "CUP_H_TKI_Pakol_2_04",
            "CUP_H_TKI_Pakol_2_05",
            "CUP_H_TKI_Pakol_2_06",
            "CUP_H_USMC_Officer_Cap",
            "CUP_H_USMC_HelmetWDL",
            "CUP_H_USMC_HeadSet_HelmetWDL",
            "CUP_H_USMC_HeadSet_GoggleW_HelmetWDL",
            "CUP_H_USMC_Crew_Helmet",
            "CUP_H_USMC_Goggles_HelmetWDL",
            "CUP_H_USMC_Helmet_Pilot",
            "CUP_H_FR_Headset",
            "CUP_H_FR_Cap_Headset_Green",
            "CUP_H_FR_Cap_Officer_Headset",
            "CUP_H_FR_BandanaGreen",
            "CUP_H_FR_BandanaWdl",
            "CUP_H_FR_Bandana_Headset",
            "CUP_H_FR_Headband_Headset",
            "CUP_H_FR_ECH",
            "CUP_H_FR_BoonieMARPAT",
            "CUP_H_FR_BoonieWDL",
            "CUP_H_FR_BeanieGreen",
            "CUP_H_FR_PRR_BoonieWDL",
            "CUP_H_Navy_CrewHelmet_Blue",
            "CUP_H_Navy_CrewHelmet_Brown",
            "CUP_H_Navy_CrewHelmet_Green",
            "CUP_H_Navy_CrewHelmet_Red",
            "CUP_H_Navy_CrewHelmet_Violet",
            "CUP_H_Navy_CrewHelmet_White",
            "CUP_H_Navy_CrewHelmet_Yellow",
	        "CUP_H_BAF_Officer_Beret_PRR_O",
	        "CUP_H_BAF_Helmet_1_DDPM",
	        "CUP_H_BAF_Helmet_2_DDPM",
	        "CUP_H_BAF_Helmet_3_DDPM",
	        "CUP_H_BAF_Helmet_4_DDPM",
	        "CUP_H_BAF_Helmet_1_DPM",
	        "CUP_H_BAF_Helmet_2_DPM",
	        "CUP_H_BAF_Helmet_3_DPM",
	        "CUP_H_BAF_Helmet_4_DPM",
	        "CUP_H_BAF_Helmet_1_MTP",
	        "CUP_H_BAF_Helmet_2_MTP",
	        "CUP_H_BAF_Helmet_3_MTP",
	        "CUP_H_BAF_Helmet_4_MTP"
		};
	};
	
	class CUPBackpacks
	{
		name = "CUP Backpacks";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\backpack_ca.paa";
		items[] = 
		{
			"CUP_O_RUS_Patrol_bag_Green",
			"CUP_B_Bergen_BAF",
			"CUP_B_GER_Pack_Tropentarn",
			"CUP_B_GER_Pack_Flecktarn",
			"CUP_B_HikingPack_Civ",
			"CUP_B_RUS_Backpack",
			"CUP_B_CivPack_WDL",
			"CUP_B_USPack_Coyote",
			"CUP_B_AssaultPack_ACU",
			"CUP_B_AssaultPack_Coyote",
			"CUP_B_USMC_AssaultPack",
			"CUP_B_USMC_MOLLE",
			//"CUP_B_MOLLE_WDL",
			"CUP_B_USPack_Black",
			"CUP_B_ACRPara_m95",
			"CUP_B_AssaultPack_Black"
		};
	};


	class CUPVests
	{
		name = "CUP Vests";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"CUP_V_B_GER_Carrier_Rig",
            "CUP_V_B_GER_Carrier_Rig_2",
            "CUP_V_B_GER_Carrier_Vest",
            "CUP_V_B_GER_Carrier_Vest_2",
            "CUP_V_B_GER_Carrier_Vest_3",
            "CUP_V_B_GER_Vest_1",
            "CUP_V_B_GER_Vest_2",
            "CUP_V_B_MTV",
            "CUP_V_B_MTV_Patrol",
            "CUP_V_B_MTV_Pouches",
            "CUP_V_B_MTV_noCB",
            "CUP_V_B_MTV_Marksman",
            "CUP_V_B_MTV_PistolBlack",
            "CUP_V_B_MTV_LegPouch",
            "CUP_V_B_MTV_MG",
            "CUP_V_B_MTV_Mine",
            "CUP_V_B_MTV_TL",
            "CUP_V_B_PilotVest",
            "CUP_V_B_RRV_TL",
            "CUP_V_B_RRV_Officer",
            "CUP_V_B_RRV_Medic",
            "CUP_V_B_RRV_DA1",
            "CUP_V_B_RRV_DA2",
            "CUP_V_B_RRV_MG",
            "CUP_V_B_RRV_Light",
            "CUP_V_B_RRV_Scout",
            "CUP_V_B_RRV_Scout2",
            "CUP_V_B_RRV_Scout3",
            "CUP_V_B_LHDVest_Blue",
            "CUP_V_B_LHDVest_Brown",
            "CUP_V_B_LHDVest_Green",
            "CUP_V_B_LHDVest_Red",
            "CUP_V_B_LHDVest_Violet",
            "CUP_V_B_LHDVest_White",
            "CUP_V_B_LHDVest_Yellow",
            "CUP_V_I_Carrier_Belt",
            "CUP_V_I_Guerilla_Jacket",
            "CUP_V_I_RACS_Carrier_Vest",
            "CUP_V_I_RACS_Carrier_Vest_2",
            "CUP_V_I_RACS_Carrier_Vest_3",
            "CUP_V_O_SLA_Carrier_Belt",
            "CUP_V_O_SLA_Carrier_Belt02",
            "CUP_V_O_SLA_Carrier_Belt03",
            "CUP_V_O_SLA_Flak_Vest01",
            "CUP_V_O_SLA_Flak_Vest02",
            "CUP_V_O_SLA_Flak_Vest03",
            "CUP_V_O_TK_CrewBelt",
            "CUP_V_O_TK_OfficerBelt",
            "CUP_V_O_TK_OfficerBelt2",
            "CUP_V_O_TK_Vest_1",
            "CUP_V_O_TK_Vest_2",
            "CUP_V_OI_TKI_Jacket1_01",
            "CUP_V_OI_TKI_Jacket1_02",
            "CUP_V_OI_TKI_Jacket1_03",
            "CUP_V_OI_TKI_Jacket1_04",
            "CUP_V_OI_TKI_Jacket1_05",
            "CUP_V_OI_TKI_Jacket1_06",
            "CUP_V_OI_TKI_Jacket2_01",
            "CUP_V_OI_TKI_Jacket2_02",
            "CUP_V_OI_TKI_Jacket2_03",
            "CUP_V_OI_TKI_Jacket2_04",
            "CUP_V_OI_TKI_Jacket2_05",
            "CUP_V_OI_TKI_Jacket2_06",
            "CUP_V_OI_TKI_Jacket3_01",
            "CUP_V_OI_TKI_Jacket3_02",
            "CUP_V_OI_TKI_Jacket3_03",
            "CUP_V_OI_TKI_Jacket3_04",
            "CUP_V_OI_TKI_Jacket3_05",
            "CUP_V_OI_TKI_Jacket3_06",
            "CUP_V_OI_TKI_Jacket4_01",
            "CUP_V_OI_TKI_Jacket4_02",
            "CUP_V_OI_TKI_Jacket4_03",
            "CUP_V_OI_TKI_Jacket4_04",
            "CUP_V_OI_TKI_Jacket4_05",
            "CUP_V_OI_TKI_Jacket4_06",
	        "CUP_V_BAF_Osprey_Mk2_DDPM_Scout",
	        "CUP_V_BAF_Osprey_Mk2_DDPM_Soldier1",
	        "CUP_V_BAF_Osprey_Mk2_DDPM_Soldier2",
	        "CUP_V_BAF_Osprey_Mk2_DDPM_Grenadier",
	        "CUP_V_BAF_Osprey_Mk2_DDPM_Sapper",
	        "CUP_V_BAF_Osprey_Mk2_DDPM_Medic",
	        "CUP_V_BAF_Osprey_Mk2_DDPM_Officer",
	        "CUP_V_BAF_Osprey_Mk2_DPM_Scout",
	        "CUP_V_BAF_Osprey_Mk2_DPM_Soldier1",
	        "CUP_V_BAF_Osprey_Mk2_DPM_Soldier2",
	        "CUP_V_BAF_Osprey_Mk2_DPM_Grenadier",
	        "CUP_V_BAF_Osprey_Mk2_DPM_Sapper",
	        "CUP_V_BAF_Osprey_Mk2_DPM_Medic",
	        "CUP_V_BAF_Osprey_Mk2_DPM_Officer",
	        "CUP_V_BAF_Osprey_Mk4_MTP_Grenadier",
	        "CUP_V_BAF_Osprey_Mk4_MTP_MachineGunner",
	        "CUP_V_BAF_Osprey_Mk4_MTP_Rifleman",
	        "CUP_V_BAF_Osprey_Mk4_MTP_SquadLeader"
	
		};
	};

	class CUPBoats
	{
		name = "CUP & RHS Boats";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"CUP_O_PBX_SLA",
		    "CUP_B_Zodiac_USMC",
		    "CUP_C_Fishing_Boat_Chernarus",
		    "CUP_B_RHIB2Turret_USMC",
		    "CUP_I_RHIB2Turret_RACS",
			"CUP_O_LCVP_SLA",
			"CUP_O_LCVP_VIV_SLA",
			"CUP_I_LCVP_RACS", 
			"CUP_I_LCVP_VIV_RACS",
            "rhsusf_mkvsoc"	      		
		};
	};

	/*
	class RHSGuns
	{
		name = "Артилерия";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[]=
		{
			//"rhs_D30_msv"
			//"CUP_B_D30_CDF"
        };
	};
	*/

	class RHSUniforms
	{
		name = "RHS Uniforms";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\uniform_ca.paa";
		items[] =
		{
			"rhs_uniform_cu_ocp",
			"rhs_uniform_cu_ucp",
			"rhs_uniform_cu_ocp_101st",
			"rhs_uniform_df15",
			"rhs_uniform_m88_patchless",
			"rhs_uniform_emr_patchless",
			"rhs_uniform_flora_patchless",
			"rhs_uniform_flora_patchless_alt",
			"rhs_uniform_FROG01_m81",
			"rhs_uniform_FROG01_d",
			"rhs_uniform_FROG01_wd",
			"rhs_uniform_m88_patchless",
			"rhs_uniform_mflora_patchless",
			"rhs_uniform_vdv_mflora",
			"rhs_uniform_vdv_emr_des",
			"rhs_uniform_msv_emr",
			"rhs_uniform_flora",
			"rhs_uniform_vdv_flora",
			"rhs_uniform_gorka_r_g",
			"rhs_uniform_gorka_r_y",
			"rhs_chdkz_uniform_5",
			"rhs_chdkz_uniform_4",
			"rhs_chdkz_uniform_3",
			"rhs_chdkz_uniform_2",
			"rhs_chdkz_uniform_1",
			"rhs_uniform_mvd_izlom",
			"rhs_uniform_cu_ocp_10th",
			"rhs_uniform_cu_ocp_1stcav",
			"rhs_uniform_cu_ocp_82nd",
			"rhs_uniform_cu_ucp_101st",
			"rhs_uniform_cu_ucp_10th",
			"rhs_uniform_cu_ucp_1stcav",
			"rhs_uniform_cu_ucp_82nd",
			// Added by ElShotte - 5 Items
			"rhs_uniform_g3_m81",
			"rhs_uniform_g3_blk",
			"rhs_uniform_g3_mc",
			"rhs_uniform_g3_rgr",
			"rhs_uniform_g3_tan"
		};
	};

	class RHSVests
	{
		name = "RHS Vests";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\vest_ca.paa";
		items[] =
		{
			"rhs_6sh92",
			"rhs_6sh92_radio",
			"rhs_6sh92_vog",
			"rhs_6sh92_vog_headset",
			"rhs_6sh92_headset",
			"rhs_6sh92_digi",
			"rhs_6sh92_digi_radio",
			"rhs_6sh92_digi_vog",
			"rhs_6sh92_digi_vog_headset",
			"rhs_6sh92_digi_headset",
			"rhs_6b23",
			"rhs_6b23_crew",
			"rhs_6b23_crewofficer",
			"rhs_6b23_engineer",
			"rhs_6b23_medic",
			"rhs_6b23_rifleman",
			"rhs_6b23_sniper",
			"rhs_6b23_6sh92",
			"rhs_6b23_6sh92_radio",
			"rhs_6b23_6sh92_vog",
			"rhs_6b23_6sh92_vog_headset",
			"rhs_6b23_6sh92_headset",
			"rhs_6b23_6sh92_headset_mapcase",
			"rhs_6b23_digi",
			"rhs_6b23_digi_crew",
			"rhs_6b23_digi_crewofficer",
			"rhs_6b23_digi_engineer",
			"rhs_6b23_digi_medic",
			"rhs_6b23_digi_rifleman",
			"rhs_6b23_digi_sniper",
			"rhs_6b23_digi_6sh92",
			"rhs_6b23_digi_6sh92_radio",
			"rhs_6b23_digi_6sh92_vog",
			"rhs_6b23_digi_6sh92_vog_headset",
			"rhs_6b23_digi_6sh92_headset",
			"rhs_6b23_digi_6sh92_headset_mapcase",
			"rhs_6b23_ML",
			"rhs_6b23_ML_crew",
			"rhs_6b23_ML_crewofficer",
			"rhs_6b23_ML_engineer",
			"rhs_6b23_ML_medic",
			"rhs_6b23_ML_rifleman",
			"rhs_6b23_ML_sniper",
			"rhs_6b23_ML_6sh92",
			"rhs_6b23_ML_6sh92_radio",
			"rhs_6b23_ML_6sh92_vog",
			"rhs_6b23_ML_6sh92_vog_headset",
			"rhs_6b23_ML_6sh92_headset",
			"rhs_6b23_ML_6sh92_headset_mapcase",
			"rhs_vest_commander",
			"rhs_vydra_3m",
			"rhsusf_iotv_ucp",
			"rhsusf_iotv_ucp_grenadier",
			"rhsusf_iotv_ucp_medic",
			"rhsusf_iotv_ucp_repair",
			"rhsusf_iotv_ucp_rifleman",
			"rhsusf_iotv_ucp_SAW",
			"rhsusf_iotv_ucp_squadleader",
			"rhsusf_iotv_ucp_teamleader",
			"rhsusf_iotv_ocp",
			"rhsusf_iotv_ocp_grenadier",
			"rhsusf_iotv_ocp_medic",
			"rhsusf_iotv_ocp_repair",
			"rhsusf_iotv_ocp_rifleman",
			"rhsusf_iotv_ocp_SAW",
			"rhsusf_iotv_ocp_squadleader",
			"rhsusf_iotv_ocp_teamleader",
			"rhsusf_spc",
			// Added by ElShotte - 12 Items
			"rhsusf_spc_corpsman",
			"rhsusf_spc_patchless",
			"rhsusf_spc_squadleader",
			"rhsusf_spc_teamleader",
			"rhsusf_spc_light",
			"rhsusf_spc_rifleman",
			"rhsusf_spc_iar",
			"rhsusf_spcs_ocp_rifleman",
			"rhsusf_spcs_ocp",
			"rhsusf_spcs_ucp_rifleman",
			"rhsusf_spcs_ucp",
			"rhs_6b43"
		};
	};

	class RHSHeadgear
	{
		name = "RHS Headgear";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\headgear_ca.paa";
		items[] =
		{
            "rhs_6b27m_digi",
	        "rhs_6b27m_digi_ess",
	        "rhs_6b27m_digi_bala",
	        "rhs_6b27m_digi_ess_bala",
	        "rhs_6b27m",
	        "rhs_6b27m_bala",
	        "rhs_6b27m_ess",
	        "rhs_6b27m_ess_bala",
	        "rhs_6b27m_ml",
	        "rhs_6b27m_ml_ess",
	        "rhs_6b27m_ml_bala",
	        "rhs_6b27m_ML_ess_bala",
	        "rhs_6b27m_green",
	        "rhs_6b27m_green_ess",
	        "rhs_6b27m_green_ess_bala",
			"rhs_6b26_green",
			"rhs_6b26_bala_green",
			"rhs_6b26_ess_green",
			"rhs_6b26_ess_bala_green",
			"rhs_6b26",
			"rhs_6b26_bala",
			"rhs_6b26_ess",
			"rhs_6b26_ess_bala",
			"rhs_6b28_green",
			"rhs_6b28_green_bala",
			"rhs_6b28_green_ess",
			"rhs_6b28_green_ess_bala",
			"rhs_6b28",
			"rhs_6b28_bala",
			"rhs_6b28_ess",
			"rhs_6b28_ess_bala",
			"rhs_6b28_flora",
			"rhs_6b28_flora_bala",
			"rhs_6b28_flora_ess",
			"rhs_6b28_flora_ess_bala",
			"rhs_Booniehat_digi",
			"rhs_Booniehat_flora",
			"rhs_ssh68",
			"rhs_Booniehat_m81",
			"rhs_Booniehat_marpatd",
			"rhs_Booniehat_marpatwd",
			"rhs_Booniehat_ocp",
			"rhs_Booniehat_ucp",
			"rhsusf_Bowman",
			"rhsusf_ach_bare",
			"rhsusf_ach_bare_des",
			"rhsusf_ach_bare_des_ess",
			"rhsusf_ach_bare_des_headset",
			"rhsusf_ach_bare_des_headset_ess",
			"rhsusf_ach_bare_ess",
			"rhsusf_ach_bare_headset",
			"rhsusf_ach_bare_headset_ess",
			"rhsusf_ach_bare_semi",
			"rhsusf_ach_bare_semi_ess",
			"rhsusf_ach_bare_semi_headset",
			"rhsusf_ach_bare_semi_headset_ess",
			"rhsusf_ach_bare_tan",
			"rhsusf_ach_bare_tan_ess",
			"rhsusf_ach_bare_tan_headset",
			"rhsusf_ach_bare_tan_headset_ess",
			"rhsusf_ach_bare_wood",
			"rhsusf_ach_bare_wood_ess",
			"rhsusf_ach_bare_wood_headset",
			"rhsusf_ach_bare_wood_headset_ess",
			"rhsusf_ach_helmet_ESS_ocp",
			"rhsusf_ach_helmet_ESS_ucp",
			"rhsusf_ach_helmet_M81",
			"rhsusf_ach_helmet_camo_ocp",
			"rhsusf_ach_helmet_headset_ess_ocp",
			"rhsusf_ach_helmet_headset_ess_ucp",
			"rhsusf_ach_helmet_headset_ocp",
			"rhsusf_ach_helmet_headset_ucp",
			"rhsusf_ach_helmet_ocp",
			"rhsusf_ach_helmet_ocp_norotos",
			"rhsusf_ach_helmet_ucp",
			"rhsusf_ach_helmet_ucp_norotos",
			"rhsusf_bowman_cap",
			"rhsusf_lwh_helmet_M1942",
			"rhsusf_lwh_helmet_marpatd",
			"rhsusf_lwh_helmet_marpatd_ess",
			"rhsusf_lwh_helmet_marpatd_headset",
			"rhsusf_lwh_helmet_marpatwd",
			"rhsusf_lwh_helmet_marpatwd_ess",
			"rhsusf_lwh_helmet_marpatwd_headset",
			"rhsusf_mich_bare",
			"rhsusf_mich_bare_alt",
			"rhsusf_mich_bare_alt_semi",
			"rhsusf_mich_bare_alt_tan",
			"rhsusf_mich_bare_headset",
			"rhsusf_mich_bare_norotos",
			"rhsusf_mich_bare_norotos_alt",
			"rhsusf_mich_bare_norotos_alt_headset",
			"rhsusf_mich_bare_norotos_alt_semi",
			"rhsusf_mich_bare_norotos_alt_semi_headset",
			"rhsusf_mich_bare_norotos_alt_tan",
			"rhsusf_mich_bare_norotos_alt_tan_headset",
			"rhsusf_mich_bare_norotos_arc",
			"rhsusf_mich_bare_norotos_arc_alt",
			"rhsusf_mich_bare_norotos_arc_alt_headset",
			"rhsusf_mich_bare_norotos_arc_alt_semi",
			"rhsusf_mich_bare_norotos_arc_alt_semi_headset",
			"rhsusf_mich_bare_norotos_arc_alt_tan",
			"rhsusf_mich_bare_norotos_arc_alt_tan_headset",
			"rhsusf_mich_bare_norotos_arc_headset",
			"rhsusf_mich_bare_norotos_arc_semi",
			"rhsusf_mich_bare_norotos_arc_semi_headset",
			"rhsusf_mich_bare_norotos_arc_tan",
			"rhsusf_mich_bare_norotos_headset",
			"rhsusf_mich_bare_norotos_semi",
			"rhsusf_mich_bare_norotos_semi_headset",
			"rhsusf_mich_bare_norotos_tan",
			"rhsusf_mich_bare_norotos_tan_headset",
			"rhsusf_mich_bare_semi",
			"rhsusf_mich_bare_semi_headset",
			"rhsusf_mich_bare_tan",
			"rhsusf_mich_bare_tan_headset",
			"rhsusf_mich_helmet_marpatd_alt_headset",
			"rhsusf_mich_helmet_marpatd_headset",
			"rhsusf_mich_helmet_marpatd_norotos",
			"rhsusf_mich_helmet_marpatd_norotos_arc",
			"rhsusf_mich_helmet_marpatd_norotos_arc_headset",
			"rhsusf_mich_helmet_marpatd_norotos_headset",
			"rhsusf_mich_helmet_marpatwd",
			"rhsusf_mich_helmet_marpatwd_alt",
			"rhsusf_mich_helmet_marpatwd_alt_headset",
			"rhsusf_mich_helmet_marpatwd_headset",
			"rhsusf_mich_helmet_marpatwd_norotos",
			"rhsusf_mich_helmet_marpatwd_norotos_arc",
			"rhsusf_mich_helmet_marpatwd_norotos_arc_headset",
			"rhsusf_mich_helmet_marpatwd_norotos_headset",
			// Added by ElShotte - 41 Items
			"rhs_altyn_novisor",
			"rhs_altyn_novisor_bala",
			"rhs_altyn_novisor_ess",
			"rhs_altyn_novisor_ess_bala",
			"rhs_altyn_visordown",
			"rhs_altyn",
			"rhs_altyn_bala",
			"rhsusf_opscore_bk_pelt",
			"rhsusf_opscore_bk",
			"rhsusf_opscore_coy_cover",
			"rhsusf_opscore_coy_cover_pelt",
			"rhsusf_opscore_fg",
			"rhsusf_opscore_fg_pelt",
			"rhsusf_opscore_fg_pelt_cam",
			"rhsusf_opscore_fg_pelt_nsw",
			"rhsusf_opscore_mc",
			"rhsusf_opscore_mc_pelt",
			"rhsusf_opscore_mc_pelt_nsw",
			"rhsusf_opscore_mc_cover",
			"rhsusf_opscore_mc_cover_pelt",
			"rhsusf_opscore_mc_cover_pelt_nsw",
			"rhsusf_opscore_mc_cover_pelt_cam",
			"rhsusf_opscore_paint",
			"rhsusf_opscore_paint_pelt",
			"rhsusf_opscore_paint_pelt_nsw",
			"rhsusf_opscore_paint_pelt_nsw_cam",
			"rhsusf_opscore_rg_cover",
			"rhsusf_opscore_rg_cover_pelt",
			"rhsusf_opscore_ut",
			"rhsusf_opscore_ut_pelt",
			"rhsusf_opscore_ut_pelt_cam",
			"rhsusf_opscore_ut_pelt_nsw",
			"rhsusf_opscore_ut_pelt_nsw_cam",
			"rhsusf_opscore_mar_ut_pelt",
			"rhsusf_opscore_mar_ut",
			"rhsusf_opscore_mar_fg_pelt",
			"rhsusf_opscore_mar_fg",
			"rhsusf_protech_helmet",
			"rhsusf_protech_helmet_ess",
			"rhsusf_protech_helmet_rhino",
			"rhsusf_protech_helmet_rhino_ess"
		};
	};

	// Added by ElShotte - 11 Items
	class RHSBackpacks
	{
		name = "RHS Backpacks";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\backpack_ca.paa";
		items[] =
		{
			"rhsusf_assault_eagleaiii_coy",
			"rhsusf_assault_eagleaiii_ocp",
			"rhsusf_assault_eagleaiii_ucp",
			"rhsusf_falconii_coy",
			"rhsusf_falconii_mc",
			"rhsusf_falconii",
			"rhs_assault_umbts",
			"rhs_assault_umbts_engineer_empty",
			"rhs_medic_bag",
			"rhs_sidor",
			"rhs_rpg_empty"
		};
	};

	// Added by ElShotte - 11 Items
	class RHSAccessories
	{
		name = "RHS Accessories";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"rhs_ess_black",
			"rhs_googles_black",
			"rhs_googles_clear",
			"rhs_googles_yellow",
			"rhs_googles_orange",
			"rhs_scarf",
			"rhs_balaclava",
			"rhs_balaclava1_olive",
			"rhsusf_ANPVS_15",
			"rhsusf_ANPVS_14",
			"rhs_1PN138"
		};
	};

	class RHSLaunchers
	{
		name = "RHS Launchers";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\cargothrow_ca.paa";
		items[] =
		{
			"rhs_weap_rpg26",
			"rhs_weap_rpg7",
			"rhs_weap_rshg2",
			// Added by ElShotte - 9 Items
			"rhs_weap_igla",
			"rhs_weap_fgm148",
			"rhs_weap_fim92",
			"rhs_weap_M136",
			"rhs_weap_M136_hedp",
			"rhs_weap_M136_hp",
			"rhs_weap_m72a7",
			"rhs_weap_smaw",
			"rhs_weap_smaw_green"
		};
	};
	class CUPLaunchers
	{
		name = "CUP Launchers";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\cargothrow_ca.paa";
		items[] =
		{
			"CUP_launch_Igla",									
			"CUP_launch_Javelin",								
			"CUP_launch_M47",							
			"CUP_launch_M136",									
			//"CUP_launch_MAAWS_Scope",	// дюп						
			"CUP_launch_Metis",							
			"CUP_launch_NLAW",								
			"CUP_launch_RPG7V",									
	        "CUP_launch_RPG18",						
	        //"CUP_launch_Mk153Mod0_SMAWOptics", 	// дюп				
	        "CUP_launch_FIM92Stinger",				
	        "CUP_launch_MAAWS",						
	        "CUP_launch_Mk153Mod0",								
	        "CUP_launch_9K32Strela"							
		};
	};

	class RHSLauncherAmmo
	{
		name = "RHS Launcher Ammo";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"rhs_rpg26_mag",
			"rhs_rshg2_mag",
			"rhs_rpg18_mag",
			"rhs_rpg7_PG7VL_mag",
			"rhs_rpg7_PG7VR_mag",
			"rhs_rpg7_TBG7V_mag",
			"rhs_rpg7_OG7V_mag",
			"rhs_mag_9k32_rocket",
			"rhs_mag_9k38_rocket",
			// Added by ElShotte - 11 Items
			"rhs_rpg7_type69_airburst_mag",
			"rhs_mag_9k38_rocket",
			"rhs_fgm148_magazine_AT",
			"rhs_fim92_mag",
			"rhs_m136_mag",
			"rhs_m136_hedp_mag",
			"rhs_M136_hp_mag",
			"rhs_m72a7_mag",
			"rhs_mag_smaw_HEAA",
			"rhs_mag_smaw_HEDP",
			"rhs_mag_smaw_SR"
		};
	};
	// Added by ElShotte - 25 Items
	class RHSUGLAmmo
	{
		name = "RHS UGL Ammo";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\CargoMag_ca.paa";
		items[] =
		{
			"rhs_mag_M433_HEDP",
			"rhs_mag_M397_HET",
			"rhs_mag_m4009",
			"rhs_mag_m576",
			"rhs_mag_M585_white",
			"rhs_mag_m661_green",
			"rhs_mag_m662_red",
			"rhs_mag_m713_Red",
			"rhs_mag_m714_White",
			"rhs_mag_m715_Green",
			"rhs_mag_m716_yellow",
			"rhs_VOG25",
			"rhs_VOG25p",
			"rhs_vg40tb",
			"rhs_vg40sz",
			"rhs_vg40op_white",
			"rhs_vg40op_green",
			"rhs_vg40op_red",
			"rhs_GRD40_white",
			"rhs_GRD40_green",
			"rhs_GRD40_red",
			"rhs_VG40MD_White",
			"rhs_VG40MD_Green",
			"rhs_VG40MD_Red",
			"rhs_GDM40"
		};
	};
	
	class LOWUniforms
	{
		name = "LOW Uniforms";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\uniform_ca.paa";
		items[] =
		{
		    "U_C_IDAP_Man_cargo_F",
		    "U_C_IDAP_Man_Jeans_F",
		    "U_C_IDAP_Man_casual_F",
		    "U_C_IDAP_Man_shorts_F",
		    "U_C_IDAP_Man_Tee_F",
		    "U_C_IDAP_Man_TeeShorts_F",
		    "U_C_ConstructionCoverall_Black_F",
		    "U_C_ConstructionCoverall_Blue_F",
		    "U_C_ConstructionCoverall_Red_F",
		    "U_C_ConstructionCoverall_Vrana_F",
		    "U_BG_Guerilla1_2_F",
		    "U_C_Mechanic_01_F",
		    "U_C_Paramedic_01_F"
			
		};
	};
	class LOWVests
	{
		name = "LOW Vests";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\uniform_ca.paa";
		items[] =
		{
		    "V_EOD_blue_F",
		    "V_EOD_IDAP_blue_F",
		    "V_EOD_coyote_F",
		    "V_EOD_olive_F",
		    "V_Plain_crystal_F",
		    "V_Plain_medical_F",
		    "V_LegStrapBag_black_F",
		    "V_LegStrapBag_coyote_F",
		    "V_Pocketed_black_F",
		    "V_Pocketed_coyote_F",
		    "V_Pocketed_olive_F",
		    "V_Safety_blue_F",
		    "V_Safety_orange_F",
		    "V_Safety_yellow_F"
			
		};
	};
	class LOWHead
	{
		name = "LOW Head";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\uniform_ca.paa";
		items[] =
		{
		    "H_PASGT_basic_blue_F",
		    "H_PASGT_basic_olive_F",
		    "H_PASGT_basic_white_F",
		    "H_Construction_basic_orange_F",
		    "H_Construction_earprot_orange_F",
		    "H_Construction_headset_orange_F",
		    "H_Construction_basic_red_F",
		    "H_Construction_earprot_red_F",
		    "H_Construction_basic_vrana_F",
		    "H_Construction_earprot_vrana_F",
		    "H_Construction_headset_vrana_F",
		    "H_Construction_earprot_white_F",
		    "H_Construction_basic_yellow_F",
		    "H_Construction_earprot_yellow_F",
		    "H_HeadBandage_clean_F",
		    "H_HeadBandage_stained_F",
		    "H_HeadBandage_bloody_F",
		    "H_PASGT_basic_blue_press_F",
		    "H_PASGT_neckprot_blue_press_F",
		    "H_Hat_Safari_sand_F"
			
		};
	};
	class LOWAcess
	{
		name = "LOW Acess";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\uniform_ca.paa";
		items[] =
		{
		    "G_Respirator_blue_F",
		    "G_Respirator_white_F",
		    "G_Respirator_yellow_F",
		    "G_EyeProtectors_F",
		    "G_EyeProtectors_Earpiece_F"
			
		};
	};
	class UnderwaterWeap
	{
		name = "Underwater Weap";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\uniform_ca.paa";
		items[] =
		{
		    "arifle_SDAR_F",
		    "20Rnd_556x45_UW_mag"
			
		};
	};
	

	class TankDLCLaunchers
	{
	    name = "TANK DLC Launchers";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
	    items[] =
	    {
			"launch_MRAWS_olive_F",
			"launch_MRAWS_olive_rail_F",
			"launch_MRAWS_green_F",
			"launch_MRAWS_green_rail_F",
			"launch_MRAWS_sand_F",
			"launch_MRAWS_sand_rail_F",
			"launch_O_Vorona_brown_F",
			"launch_O_Vorona_green_F"
		};
	};

	class TankDLCLauncherAmmo
	{
	    name = "TANK DLC Ammo";
	    icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
	    items[] =
	    {
			"MRAWS_HEAT_F",
			"MRAWS_HE_F",
			"Vorona_HEAT",
			"Vorona_HE"
		};
    };
	class Diving
	{
		name = "Diving";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[] =
		{
			"G_B_Diving",
			"G_I_Diving",
			"G_O_Diving",
			"U_B_Wetsuit",
			"U_I_Wetsuit",
			"U_O_Wetsuit",
			"V_RebreatherB",
			"V_RebreatherIA",
			"V_RebreatherIR",
			"Exile_Headgear_GasMask"
		};
	};

	class Stationary
	{
		name = "Stationary";
		icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
		items[]=
		{
	       "RHS_NSV_Gun_Bag",
           "RHS_NSV_Tripod_Bag",             
           "RHS_DShkM_Gun_Bag",
           "RHS_DShkM_TripodHigh_Bag",
           "RHS_DShkM_TripodLow_Bag",        
           "RHS_Kord_Gun_Bag",
           "RHS_Kord_Tripod_Bag",       
           "RHS_Metis_Gun_Bag",
           "RHS_Metis_Tripod_Bag",   
           "RHS_Kornet_Gun_Bag",
           "RHS_Kornet_Tripod_Bag",         
           "RHS_AGS30_Gun_Bag",
           "RHS_AGS30_Tripod_Bag",      
           "RHS_SPG9_Gun_Bag",
           "RHS_SPG9_Tripod_Bag",       
           "RHS_Podnos_Gun_Bag",
           "RHS_Podnos_Bipod_Bag",           
           "RHS_M2_Gun_Bag",
           "RHS_M2_Tripod_Bag",            
           "RHS_M2_MiniTripod_Bag",
           "RHS_Mk19_Gun_Bag",
           "RHS_Mk19_Tripod_Bag",             
           "rhs_Tow_Gun_Bag",
           "rhs_TOW_Tripod_Bag",           
           "rhs_M252_Gun_Bag",
           "rhs_M252_Bipod_Bag",
           "I_E_HMG_02_high_weapon_F",
           "I_E_HMG_02_support_high_F",
           "B_AA_01_weapon_F",
           "B_HMG_01_support_F"		   
	
	    };
	};
	
    class RussianArmedForcesMachineGuns
    {
    	name = "RussianArmed Machine Guns";
    	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemmuzzle_ca.paa";
    	items[] =
        {
            // Пулемёты                                                   
            "LMG_min_rf_6p69_camo",                             
            "LMG_min_rf_6p69_desert",                          
            "LMG_min_rf_6p69" 
    	};
    };
    
    class RussianArmedForcesSubmachineGun
    {
    	name = "RussianArmed Submachine Guns";
    	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemmuzzle_ca.paa";
    	items[] =
        {
            // Пистолет-Пулемёты                                          
            "SMG_min_rf_pp_2000"  
    	};
    };
    
    class RussianArmedForcesSniperRifles
    {
    	name = "RussianArmed Sniper Rifles";
    	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemmuzzle_ca.paa";
    	items[] =
        {
            // Снайперские винтовки                                       
            "srifle_min_rf_vs_121_winter",                      
            "srifle_min_rf_vs_121_camo",                        
            "srifle_min_rf_vs_121_desert",                      
            "srifle_min_rf_vs_121",                             
            "srifle_min_rf_orsis_t5000_winter",                 
            "srifle_min_rf_orsis_t5000_camo",                   
            "srifle_min_rf_orsis_t5000_desert"    
    	};
    };
    
    class RussianArmedForcesAssaultRifles
    {
    	name = "RussianArmed Assault Rifles";
    	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemmuzzle_ca.paa";
    	items[] =
        {
            // Штурмовые винтовки                                         
            "arifle_min_rf_ash_12_camo",                        
            "arifle_min_rf_ash_12_desert",                      
            "arifle_min_rf_ash_12",                             
            "arifle_min_rf_aek_a545_winter",                    
            "arifle_min_rf_aek_a545_camo",                      
            "arifle_min_rf_aek_a545_desert",                    
            "arifle_min_rf_aek_a545",                           
            "arifle_min_rf_aek_a545_folded_winter",             
            "arifle_min_rf_aek_a545_folded_camo",               
            "arifle_min_rf_aek_a545_folded_desert",             
            "arifle_min_rf_aek_a545_folded",                   
            "arifle_min_rf_ak_12_gp_winter",                    
            "arifle_min_rf_ak_12_gp_camo",                      
            "arifle_min_rf_ak_12_gp_desert",                    
            "arifle_min_rf_ak_12_gp",                           
            "arifle_min_rf_ak_12_winter",                       
            "arifle_min_rf_ak_12_camo",                         
            "arifle_min_rf_ak_12_desert",                      
            "arifle_min_rf_ak_12",                              
            "arifle_min_rf_ak_12_grip_winter",                  
            "arifle_min_rf_ak_12_grip_camo",                    
            "arifle_min_rf_ak_12_grip_desert",                  
            "arifle_min_rf_ak_12_grip"                          
    	};
    };
    
    class RussianArmedForcesMuzzleAttachments
    {
    	name = "RussianArmed Muzzle Attachments";
    	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemmuzzle_ca.paa";
    	items[] =
    	{
            // Глушители                                                  
            "muzzle_min_rf_pbs_1",                                
            "muzzle_min_rf_tgp_a"    
    	};
    };
    
    class RussianArmedOptic
    {
    	name = "RussianArmed Optic";
    	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemoptic_ca.paa";
    	items[] =
    	{
            // Прицелы                                                    
            "optic_min_rf_pkm_a",                                 
            "optic_min_rf_ekp_8_18",                              
            "optic_min_rf_eotech_553",                            
            "optic_min_rf_1p_87",                                 
            "optic_min_rf_po_4x24_p",                             
            "optic_min_rf_1pn_97"    
    	};
    };
    
    class RussianArmedForcesVests
    {
    	name = "RussianArmed Vests";
    	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\vest_ca.paa";
    	items[] =
        {
            // Жилеты                                                     
            "min_rf_combat_belt_vsr",                             
            "min_rf_combat_belt_multicam",                        
            "min_rf_combat_belt_surpat",                          
            "min_rf_combat_belt_flora",                           
            "min_rf_combat_belt_green",                           
            "min_rf_combat_belt_black",                           
            "min_rf_armor_vest_GL_vsr",                           
            "min_rf_armor_vest_GL_multicam",                      
            "min_rf_armor_vest_GL_surpat",                        
            "min_rf_armor_vest_GL_flora",                         
            "min_rf_armor_vest_GL_green",                         
            "min_rf_armor_vest_GL_black",                         
            "min_rf_armor_vest_AR_vsr",                           
            "min_rf_armor_vest_AR_multicam",                      
            "min_rf_armor_vest_AR_surpat",                        
            "min_rf_armor_vest_AR_flora",                         
            "min_rf_armor_vest_AR_green",                         
            "min_rf_armor_vest_AR_black",                         
            "min_rf_armor_vest_M_vsr",                            
            "min_rf_armor_vest_M_multicam",                       
            "min_rf_armor_vest_M_surpat",                         
            "min_rf_armor_vest_M_flora",                          
            "min_rf_armor_vest_M_green",                          
            "min_rf_armor_vest_M_black",                          
            "min_rf_lite_vest_GL_surpat",                         
            "min_rf_lite_vest_GL_flora",                          
            "min_rf_lite_vest_GL_green",                          
            "min_rf_lite_vest_GL_black",                          
            "min_rf_lite_vest_AR_vsr",                            
            "min_rf_lite_vest_AR_multicam",                       
            "min_rf_lite_vest_AR_surpat",                         
            "min_rf_lite_vest_AR_flora",                          
            "min_rf_lite_vest_AR_green",                          
            "min_rf_lite_vest_AR_black",                          
            "min_rf_lite_vest_M_vsr",                             
            "min_rf_lite_vest_M_multicam",                       
            "min_rf_lite_vest_M_surpat",                          
            "min_rf_lite_vest_M_flora",                                                    
            "min_rf_lite_vest_M_green",                           
            "min_rf_lite_vest_M_black",                           
            "min_rf_lite_vest_vsr",                               
            "min_rf_lite_vest_multicam",                          
            "min_rf_lite_vest_surpat",                            
            "min_rf_lite_vest_flora",                             
            "min_rf_lite_vest_green",                             
            "min_rf_lite_vest_black",                             
            "min_rf_tactical_vest_GL_vsr",                        
            "min_rf_tactical_vest_GL_multicam",                  
            "min_rf_tactical_vest_GL_surpat",                     
            "min_rf_tactical_vest_GL_flora",                      
            "min_rf_tactical_vest_GL_green",                      
            "min_rf_tactical_vest_GL_black",                      
            "min_rf_tactical_vest_AR_vsr",                        
            "min_rf_tactical_vest_AR_multicam",                   
            "min_rf_tactical_vest_AR_surpat",                     
            "min_rf_tactical_vest_AR_flora",                      
            "min_rf_tactical_vest_AR_green",                      
            "min_rf_tactical_vest_AR_black",                      
            "min_rf_tactical_vest_M_vsr",                         
            "min_rf_tactical_vest_M_multicam",                    
            "min_rf_tactical_vest_M_surpat",                      
            "min_rf_tactical_vest_M_flora",                       
            "min_rf_tactical_vest_M_green",                       
            "min_rf_tactical_vest_M_black",                       
            "min_rf_tactical_vest_vsr",                           
            "min_rf_tactical_vest_multicam",                      
            "min_rf_tactical_vest_surpat",                        
            "min_rf_tactical_vest_flora",                         
            "min_rf_tactical_vest_green",                         
            "min_rf_tactical_vest_black",                         
            "min_rf_armor_vest_vsr",                              
            "min_rf_armor_vest_multicam",                         
            "min_rf_armor_vest_surpat",                           
            "min_rf_armor_vest_flora",                            
            "min_rf_armor_vest_green",                           
            "min_rf_armor_vest_black",                            
            "min_rf_highcapacity_special_GL_vsr",                 
            "min_rf_highcapacity_special_GL_multicam",            
            "min_rf_highcapacity_special_GL_surpat",              
            "min_rf_highcapacity_special_GL_flora",               
            "min_rf_highcapacity_special_GL_green",               
            "min_rf_highcapacity_special_GL_black",               
            "min_rf_highcapacity_special_vsr",                    
            "min_rf_highcapacity_special_multicam",               
            "min_rf_highcapacity_special_surpat",                 
            "min_rf_highcapacity_special_flora",                  
            "min_rf_highcapacity_special_green",                  
            "min_rf_highcapacity_special_black",                  
            "min_rf_highcapacity_vest_vsr",                       
            "min_rf_highcapacity_vest_multicam",                  
            "min_rf_highcapacity_vest_surpat",                    
            "min_rf_highcapacity_vest_flora",                     
            "min_rf_highcapacity_vest_green",                     
            "min_rf_highcapacity_vest_black",                     
            "min_rf_belt_surpat",                                 
            "min_rf_belt_flora"
    	};
    };
    
    class RussianArmedForcesHeadGears
    {
    	name = "RussianArmed Head Gears";
    	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\headgear_ca.paa";
    	items[] =
        {
            // Головные уборы                                             
            "min_rf_cap_surpat",                              
            "min_rf_cap_flora",                               
            "min_rf_cap_flora_desert",                        
            "min_rf_bandana_white",                           
            "min_rf_bandana_olive",                           
            "min_rf_bandana_black",                           
            "min_rf_beret_green",                             
            "min_rf_beret_red",                               
            "min_rf_cap_headphones",                          
            "min_rf_headset",                                 
            "min_rf_ushanka",                                 
            "min_rf_beanie_white",                            
            "min_rf_beanie_black",                           
            "min_rf_hat_multicam",                            
            "min_rf_hat_skol",                                
            "min_rf_hat_surpat",                             
            "min_rf_hat_flora",                               
            "min_rf_hat_flora_desert",
            // Шлемы                                                      
            "min_rf_helmet_para",                             
            "min_rf_helmet_mich_hex",                         
            "min_rf_helmet_mich_urban",                       
            "min_rf_helmet_mich_green_hex",                   
            "min_rf_helmet_recon",                            
            "min_rf_helmet_recon_desert",                     
            "min_rf_helmet_recon_black",                      
            "min_rf_helmet_crew_surpat",                      
            "min_rf_helmet_crew",                            
            "min_rf_helmet_crew_winter",                      
            "min_rf_helmet_crew_desert",                      
            "min_rf_helmet_pilot",                            
            "min_rf_helmet_ace",                              
            "min_rf_helmet_soldier_izlom",                    
            "min_rf_helmet_soldier_surpat",                   
            "min_rf_helmet_soldier_flora",                    
            "min_rf_helmet_soldier_winter",                   
            "min_rf_helmet_soldier_desert"                   		
    	};
    };
    
    class RussianArmedForcesBackpacks
    {
    	name = "RussianArmed Backpacks";
    	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\backpack_ca.paa";
    	items[] =
        {
            // Рюкраки                                                    
            "min_rf_backpack_vsr",                                     
            "min_rf_backpack_surpat",                                  
            "min_rf_backpack_flora",                                   
            "min_rf_backpack_green",                                   
            "min_rf_backpack_winter",                                  
            "min_rf_backpack_black",                                   
            "min_rf_torna_vsr",                                        
            "min_rf_torna_surpat",                                     
            "min_rf_torna_flora",                                      
            "min_rf_torna_green",                                      
            "min_rf_torna_black" 
    	};
    };
    
    class RussianArmedForcesUniforms
    {
    	name = "RussianArmed Uniforms";
    	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\uniform_ca.paa";
    	items[] =
        {
            // Форма                                                      
            "min_rf_emr_desert_ghillie",                          
            "min_rf_emr_ghillie",                                 
            "min_rf_winter_suit_hood_lite",                       
            "min_rf_winter_suit_hood",                            
            "min_rf_winter_suit",                                 
            "min_rf_winter_suit_officer",                         
            "min_rf_pilot_desert_overall",                        
            "min_rf_pilot_overall",                               
            "min_rf_helipilot_desert_overall",                    
            "min_rf_helipilot_overall",                           
            "min_rf_hex_officer",                                 
            "min_rf_hex",                                         
            "min_rf_hex_lite",                                    
            "min_rf_izlom_officer",                               
            "min_rf_izlom",                                       
            "min_rf_izlom_lite",                                  
            "min_rf_surpat_officer",                              
            "min_rf_surpat",                                      
            "min_rf_surpat_lite",                                 
            "min_rf_urban_officer",                               
            "min_rf_urban_lite",                                  
            "min_rf_urban",                                       
            "min_rf_flora_officer",                               
            "min_rf_flora",                                       
            "min_rf_flora_lite",                                  
            "min_rf_green_hex_officer",                           
            "min_rf_green_hex",                                   
            "min_rf_green_hex_lite",                              
            "min_rf_flora_desert_officer",                        
            "min_rf_flora_desert",                                
            "min_rf_flora_desert_lite",                           
            "min_rf_tactical_multicam",                           
            "min_rf_tactical_skol",                               
            "min_rf_tactical_surpat",                             
            "min_rf_tactical_emr",                                
            "min_rf_gorka_officer",                               
            "min_rf_gorka_hood",                                  
            "min_rf_gorka_hood_lite",                             
            "min_rf_gorka",                                       
            "min_rf_gorka_lite",                                  
            "min_rf_klmk_officer",                                
            "min_rf_klmk_hood",                                   
            "min_rf_klmk_hood_lite",                              
            "min_rf_klmk",                                        
            "min_rf_klmk_lite",                                   
            "min_rf_gorka_partizan_officer",                      
            "min_rf_gorka_partizan_hood",                         
            "min_rf_gorka_partizan_hood_lite",                    
            "min_rf_gorka_partizan",                              
            "min_rf_gorka_partizan_lite",                         
            "min_rf_gorka_surpat_officer",                        
            "min_rf_gorka_surpat_hood",                           
            "min_rf_gorka_surpat_hood_lite",                      
            "min_rf_gorka_surpat",                                
            "min_rf_gorka_surpat_lite",                           
            "min_rf_emr_officer",                                 
            "min_rf_emr_hood",                                    
            "min_rf_emr_hood_lite",                               
            "min_rf_emr",                                         
            "min_rf_emr_lite",                                    
            "min_rf_emr_desert_officer",                          
            "min_rf_emr_desert_hood",                             
            "min_rf_emr_desert_hood_lite",                        
            "min_rf_emr_desert",                                  
            "min_rf_emr_desert_lite"    
    	};
    };
    
    class 2035RUS_af
    {
    	name = "2035 RUS AF";
    	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
    	items[] =
        {
    	    //Тех камуфляж                                                                                           
            "min_rf_t_15",                                             
            "min_rf_gaz_2330",                                         
            "min_rf_gaz_2330_HMG",                                     
            "min_rf_truck_medical",                                    
            "min_rf_truck_box",                                        
            "min_rf_truck_ammo",                                       
            "min_rf_truck_fuel",                                       
            "min_rf_truck_transport",                                  
            "min_rf_truck_covered",                                   
            "min_rf_sa_22",                                            
            "min_rf_t_14",
            //Тех зима                                                   
            "min_rf_t_15_winter",                                      
            "min_rf_gaz_2330_winter",                                  
            "min_rf_gaz_2330_HMG_winter",                              
            "min_rf_truck_medical_winter",                             
            "min_rf_truck_box_winter",                                 
            "min_rf_truck_ammo_winter",                                
            "min_rf_truck_fuel_winter",                                
            "min_rf_truck_transport_winter",                          
            "min_rf_truck_covered_winter",                             
            "min_rf_sa_22_winter",                                     
            "min_rf_t_14_winter",                                      
            //Тех пустыня                                                      
            "min_rf_t_15_desert",                                      
            "min_rf_gaz_2330_desert",                                  
            "min_rf_gaz_2330_HMG_desert",                              
            "min_rf_truck_medical_desert",                             
            "min_rf_truck_box_desert",                                 
            "min_rf_truck_ammo_desert",                                
            "min_rf_truck_fuel_desert",                                
            "min_rf_truck_transport_desert",                           
            "min_rf_truck_covered_desert",                             
            "min_rf_sa_22_desert",
			"min_rf_t_14_desert"
    	};
    };
    
    class 2035RUS_helis_jets
    {
    	name = "2035 RUS helis & jets";
    	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
    	items[] =
        {
            // Воздух                                                                                             
            "min_rf_ka_52",                                            
            "min_rf_heli_light_black",                                 
            "min_rf_heli_light_unarmed_black",                         
            "min_rf_su_34",
            // Воздух пустыня                                             
            "min_rf_ka_52_grey",                                       
            "min_rf_heli_light_grey",                                  
            "min_rf_heli_light_unarmed_grey",                          
            "min_rf_su_34_desert",
			"min_rf_pchela_1t"			
    	};
    };
	
    class RussianArmedForcesAmmunition
    {
    	name = "RussianArmed Ammunition";
    	icon = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\itemacc_ca.paa";
    	items[] =
    	{
    		"100Rnd_min_rf_762x54_Box",   
    		"100Rnd_min_rf_762x54_T_Box", 
    		"20Rnd_min_rf_9x19_T_Mag",    
    		"5Rnd_min_rf_338_Mag",        
    		"20Rnd_min_rf_127x55_Mag"    	
    	};
    };
