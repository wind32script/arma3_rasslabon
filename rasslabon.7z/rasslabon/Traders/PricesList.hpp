//PricesList.hpp

    ///////////////////////
	//батарейки
	///////////////////////
	class Laserbatteries                                           { quality = 4; price = 1500; };
    class rhs_LaserMag                                             { quality = 4; price = 1500; };	
    class rhs_LaserFCSMag                                          { quality = 4; price = 1500; };
    class rhs_LaserMag_ai                                          { quality = 4; price = 1500; };
	
	//миноискатель
	class MineDetector                                             { quality = 4; price = 30000; }; 
    
	///////////////////////////////////////////////////////////////////////////////
	////////added by traicer
	///////////////////////////////////////////////////////////////////////////////
	class B_Truck_01_mover_F                                      { quality = 3; price = 1000000; };
	class rhsusf_M1117_D                                          { quality = 4; price = 1500000; };
	class rhsusf_M1117_O										  { quality = 4; price = 1500000; };
	class CUP_O_Mi8_SLA_2                               	      { quality = 3; price = 2500000; };
	class rhsgref_nat_uaz_dshkm                      	  	      { quality = 1; price = 500000; sellPrice = 100000; };
	class rhsgref_nat_uaz_ags                    	              { quality = 1; price = 500000; sellPrice = 100000; };
	class B_Heli_Light_01_armed_F                                 { quality = 3; price = 1000000; };
	class C_IDAP_Heli_Transport_02_F                              { quality = 3; price = 3000000; };
	class rhs_uh1h_idap                                           { quality = 2; price = 2000000; };
	class rhsgref_mi24g_CAS                                       { quality = 5; price = 4000000; };
	class CUP_I_MI6T_UN                                        	  { quality = 3; price = 3000000; };
	class CUP_O_UH1H_gunship_SLA                                  { quality = 4; price = 3500000; };
	class CUP_O_MI6A_TKA                                          { quality = 3; price = 3000000; };
	class Exile_Item_RubberDuck                                   { quality = 7; price = 500000; sellPrice = 50000; };
	//class classname                                             { quality = 3; price = 100000; };
	//class classname                                             { quality = 3; price = 100000; };
	//class classname                                             { quality = 3; price = 100000; };
	//class classname                                             { quality = 3; price = 100000; };
	//class classname                                             { quality = 3; price = 100000; };
	//class classname                                             { quality = 3; price = 100000; };
		
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////КОНТАКТ DLC
/////////////////////////////////////////////////////////////////////////////////////////////////////////	
//////////////////////Машинки
	class I_E_Quadbike_01_F                                     { quality = 1; price = 5000; };

//////////////////////UGV	
	class I_E_UGV_01_F                                          { quality = 3; price = 20000; };
///////////////////////////////////////////КЕПКИ///////////////////////////////////////////////////////////
	class H_MilCap_grn                                          { quality = 2; price = 100; };
	class H_MilCap_wdl                                          { quality = 2; price = 100; };
	class H_MilCap_taiga                                        { quality = 2; price = 100; };
	class H_MilCap_eaf                                          { quality = 2; price = 100; };
	class H_PilotHelmetFighter_I_E                              { quality = 2; price = 100; };
	class H_Beret_EAF_01_F                                      { quality = 2; price = 100; };
	class H_Booniehat_mgrn                                      { quality = 2; price = 100; };
	class H_Booniehat_wdl                                       { quality = 2; price = 100; };
	class H_Booniehat_taiga                                     { quality = 2; price = 100; };
	class H_Booniehat_eaf                                       { quality = 2; price = 100; };
	class H_Tank_eaf_F                                          { quality = 2; price = 100; };
	class H_HelmetCrew_I_E                                      { quality = 2; price = 100; };
	class H_PilotHelmetHeli_I_E                                 { quality = 2; price = 100; };
	class H_CrewHelmetHeli_I_E                                  { quality = 2; price = 100; };
	class H_Hat_Tinfoil_F                                       { quality = 2; price = 100; };
	
//////////////////////////////////////////НАМОРДНИКИ////////////////////////////////////////////
	class G_Blindfold_01_white_F                                { quality = 3; price = 100; };
	class G_Blindfold_01_black_F                                { quality = 3; price = 100; };
	class G_RegulatorMask_F                                     { quality = 3; price = 100; };
	class G_AirPurifyingRespirator_02_olive_F                   { quality = 3; price = 100; };
	class G_AirPurifyingRespirator_02_sand_F                    { quality = 3; price = 100; };
	class G_AirPurifyingRespirator_02_black_F                   { quality = 3; price = 100; };
	class G_AirPurifyingRespirator_01_F                         { quality = 3; price = 100; };	
	
//////////////////////////////////////////ШЛЕМЫ/////////////////////////////////////////////////////////
	class H_HelmetB_light_wdl                                   { quality = 3; price = 200; };		
	class H_HelmetSpecB_wdl                                     { quality = 3; price = 200; };		
	class H_HelmetHBK_headset_F                                 { quality = 3; price = 200; };		
	class H_HelmetHBK_chops_F                                   { quality = 3; price = 200; };		
	class H_HelmetHBK_ear_F                                     { quality = 3; price = 200; };		
	class H_HelmetHBK_F                                         { quality = 3; price = 200; };		
	class H_HelmetAggressor_F                                   { quality = 3; price = 200; };		
	class H_HelmetAggressor_cover_taiga_F                       { quality = 3; price = 200; };		
	class H_HelmetAggressor_cover_F                             { quality = 3; price = 200; };		
	class H_HelmetB_plain_wdl                                   { quality = 3; price = 200; };	
    
//////////////////////////////////////////ЖИЛЕТЫ////////////////////////////////////////////////////////	
	class V_SmershVest_01_F                                     { quality = 2; price = 500; };
	class V_SmershVest_01_radio_F                               { quality = 2; price = 500; };
	class V_PlateCarrierGL_wdl                                  { quality = 2; price = 500; };
	class V_CarrierRigKBT_01_heavy_EAF_F                        { quality = 2; price = 500; };
	class V_CarrierRigKBT_01_heavy_olive_F                      { quality = 2; price = 500; };
	class V_CarrierRigKBT_01_light_EAF_F                        { quality = 2; price = 500; };
	class V_CarrierRigKBT_01_light_olive_F                      { quality = 2; price = 500; };
	class V_CarrierRigKBT_01_EAF_F                              { quality = 2; price = 500; };
	class V_CarrierRigKBT_01_olive_F                            { quality = 2; price = 500; };
	class V_PlateCarrier1_wdl                                   { quality = 2; price = 500; };
	class V_PlateCarrier2_wdl                                   { quality = 2; price = 500; };
	class V_PlateCarrierSpec_wdl                                { quality = 2; price = 500; };
/////////////////////////////////////////ОДЕЖДА///////////////////////////////////////////////////////////	
	class U_I_L_Uniform_01_camo_F                               { quality = 2; price = 200; };
	class U_I_L_Uniform_01_deserter_F                           { quality = 2; price = 200; };
	class U_C_Uniform_Farmer_01_F                               { quality = 2; price = 200; };
	class U_C_E_LooterJacket_01_F                               { quality = 2; price = 200; };
	class U_I_L_Uniform_01_tshirt_olive_F                       { quality = 2; price = 200; };
	class U_I_L_Uniform_01_tshirt_sport_F                       { quality = 2; price = 200; };
	class U_I_L_Uniform_01_tshirt_skull_F                       { quality = 2; price = 200; };
	class U_I_L_Uniform_01_tshirt_black_F                       { quality = 2; price = 200; };
	class U_I_E_Uniform_01_coveralls_F                          { quality = 3; price = 400; };
	class U_O_R_Gorka_01_F                                      { quality = 3; price = 400; };
	class U_O_R_Gorka_01_brown_F                                { quality = 3; price = 400; };
	class U_O_R_Gorka_01_camo_F                                 { quality = 3; price = 400; };
	class U_C_Uniform_Scientist_02_formal_F                     { quality = 3; price = 400; };
	class U_C_Uniform_Scientist_02_F                            { quality = 3; price = 400; };
	class U_C_Uniform_Scientist_01_F                            { quality = 3; price = 400; };
	class U_C_Uniform_Scientist_01_formal_F                     { quality = 3; price = 400; };
	class U_B_CombatUniform_mcam_wdl_f                          { quality = 3; price = 400; };
	class U_B_CombatUniform_tshirt_mcam_wdL_f                   { quality = 3; price = 400; };
	class U_I_E_Uniform_01_tanktop_F                            { quality = 3; price = 400; };
	class U_I_E_Uniform_01_officer_F                            { quality = 3; price = 400; };
	class U_I_E_Uniform_01_sweater_F                            { quality = 3; price = 400; };
	class U_I_E_Uniform_01_shortsleeve_F                        { quality = 3; price = 400; };
	class U_I_E_Uniform_01_F                                    { quality = 3; price = 400; };
	class U_O_R_Gorka_01_black_F                                { quality = 3; price = 400; };
	class U_B_CombatUniform_vest_mcam_wdl_f                     { quality = 3; price = 400; };
	class U_C_CBRN_Suit_01_White_F                              { quality = 3; price = 400; };
	class U_B_CBRN_Suit_01_Wdl_F                                { quality = 3; price = 400; };
	class U_C_CBRN_Suit_01_Blue_F                               { quality = 3; price = 400; };
	class U_B_CBRN_Suit_01_Tropic_F                             { quality = 3; price = 400; };
	class U_B_CBRN_Suit_01_MTP_F                                { quality = 3; price = 400; };
	class U_I_E_CBRN_Suit_01_EAF_F                              { quality = 3; price = 400; };
	class U_I_CBRN_Suit_01_AAF_F                                { quality = 3; price = 400; };
	
	/////////////////////////////////////////////////////////РЮКЗАКИ//////////////////////////////////////////
	class B_SCBA_01_F                                           { quality = 3; price = 500; };
	class B_CombinationUnitRespirator_01_F                      { quality = 3; price = 500; };
	class B_FieldPack_green_F                                   { quality = 3; price = 500; };
	class B_FieldPack_taiga_F                                   { quality = 3; price = 500; };
	class B_RadioBag_01_hex_F                                   { quality = 3; price = 500; };
	class B_RadioBag_01_eaf_F                                   { quality = 3; price = 500; };
	class B_RadioBag_01_oucamo_F                                { quality = 3; price = 500; };
	class B_RadioBag_01_ghex_F                                  { quality = 3; price = 500; };
	class B_RadioBag_01_wdl_F                                   { quality = 3; price = 500; };
	class B_RadioBag_01_tropic_F                                { quality = 3; price = 500; };
	class B_RadioBag_01_digi_F                                  { quality = 3; price = 500; };
	class B_RadioBag_01_black_F                                 { quality = 3; price = 500; };
	class B_RadioBag_01_mtp_F                                   { quality = 3; price = 500; };
	class B_Carryall_eaf_F                                      { quality = 3; price = 500; };
	class B_Carryall_green_F                                    { quality = 3; price = 500; };
	class B_Carryall_wdl_F                                      { quality = 3; price = 500; };
	class B_Carryall_taiga_F                                    { quality = 3; price = 500; };
	class B_AssaultPack_eaf_F                                   { quality = 3; price = 500; };
	class B_AssaultPack_wdl_F                                   { quality = 3; price = 500; };
	
	/////////////////////////////////////////РЮКЗАКИ-БЕСПИЛОТНИКИ////////////////////////////////////
	class C_IDAP_UGV_02_Demining_backpack_F                     { quality = 5; price = 10000; };
	class I_E_UGV_02_Demining_backpack_F                        { quality = 5; price = 10000; };
	class B_UGV_02_Demining_backpack_F                          { quality = 5; price = 10000; };
	class I_UGV_02_Demining_backpack_F                          { quality = 5; price = 10000; };
	class O_UGV_02_Demining_backpack_F                          { quality = 5; price = 10000; };
	class I_E_UGV_02_Science_backpack_F                         { quality = 5; price = 10000; };
	class B_UGV_02_Science_backpack_F                           { quality = 5; price = 10000; };
	class I_UGV_02_Science_backpack_F                           { quality = 5; price = 10000; };
	class O_UGV_02_Science_backpack_F                           { quality = 5; price = 10000; };
	class I_E_UAV_06_backpack_F                                 { quality = 5; price = 10000; };
	class I_E_UAV_06_medical_backpack_F                         { quality = 5; price = 10000; };
	class I_E_UAV_01_backpack_F                                 { quality = 5; price = 10000; };
	
///////////////////////////////////////////ОРУЖИЕ//////////////////////////////////////////////////	
	class hgun_Pistol_heavy_01_green_F                          { quality = 1; price = 100; };
	class sgun_HunterShotgun_01_F                               { quality = 1; price = 500; };
	class sgun_HunterShotgun_01_sawedoff_F                      { quality = 1; price = 500; };
	class srifle_DMR_06_hunter_F                                { quality = 2; price = 800; };
	class arifle_AK12U_F                                        { quality = 3; price = 1200; };
	class arifle_AK12U_lush_f                                   { quality = 3; price = 1200; };
	class arifle_AK12U_arid_f                                   { quality = 3; price = 1200; };
	class arifle_MSBS65_black_F                                 { quality = 3; price = 1200; };
	class arifle_MSBS65_Mark_F                                  { quality = 3; price = 1500; };
	class arifle_MSBS65_Mark_camo_F                             { quality = 3; price = 1500; };
	class arifle_MSBS65_Mark_sand_F                             { quality = 3; price = 1500; };
	class arifle_MSBS65_Mark_black_F                            { quality = 3; price = 1500; };
	class arifle_MSBS65_GL_F                                    { quality = 3; price = 1700; };
	class arifle_MSBS65_GL_camo_F                               { quality = 3; price = 1700; };
	class arifle_MSBS65_GL_sand_F                               { quality = 3; price = 1700; };
	class arifle_MSBS65_GL_black_F                              { quality = 3; price = 1700; };
	class arifle_AK12_lush_f                                    { quality = 3; price = 1500; };
	class arifle_AK12_arid_f                                    { quality = 3; price = 1500; };
	class arifle_AK12_GL_lush_F                                 { quality = 3; price = 1700; };
	class arifle_AK12_GL_arid_F                                 { quality = 3; price = 1700; };
	class arifle_MSBS65_UBS_F                                   { quality = 3; price = 1700; };
	class arifle_MSBS65_UBS_camo_F                              { quality = 3; price = 1700; };
	class arifle_MSBS65_UBS_sand_F                              { quality = 3; price = 1700; };
	class arifle_MSBS65_UBS_black_F                             { quality = 3; price = 1700; };
	class arifle_RPK12_F                                        { quality = 3; price = 11900; };
	class arifle_RPK12_lush_f                                   { quality = 3; price = 11900; };
	class arifle_RPK12_arid_f                                   { quality = 3; price = 11900; };
	class LMG_Mk200_black_F                                     { quality = 3; price = 11700; };
	
//////////////////////////////////////////////ПАТРОНЫ/////////////////////////////////////////////
class 2Rnd_12Gauge_Pellets                                      { quality = 1; price = 50; };	
class 2Rnd_12Gauge_Slug                                         { quality = 1; price = 50; };
class 30rnd_762x39_AK12_Lush_Mag_F                              { quality = 1; price = 100; };	
class 30rnd_762x39_AK12_Lush_Mag_Tracer_F                       { quality = 1; price = 100; };	
class 30Rnd_762x39_AK12_Mag_F                                   { quality = 1; price = 100; };	
class 30Rnd_762x39_AK12_Mag_Tracer_F                            { quality = 1; price = 100; };	
class 30rnd_762x39_AK12_Arid_Mag_F                              { quality = 1; price = 100; };	
class 30rnd_762x39_AK12_Arid_Mag_Tracer_F                       { quality = 1; price = 100; };	
class 75rnd_762x39_AK12_Mag_F                                   { quality = 1; price = 100; };	
class 75rnd_762x39_AK12_Mag_Tracer_F                            { quality = 1; price = 100; };	
class 75rnd_762x39_AK12_Lush_Mag_F                              { quality = 1; price = 100; };	
class 75rnd_762x39_AK12_Lush_Mag_Tracer_F                       { quality = 1; price = 100; };	
class 75rnd_762x39_AK12_Arid_Mag_F                              { quality = 1; price = 100; };	
class 75rnd_762x39_AK12_Arid_Mag_Tracer_F                       { quality = 1; price = 100; };		
class 200Rnd_65x39_cased_Box_Red                                { quality = 1; price = 150; };	
class 200Rnd_65x39_cased_Box_Tracer_Red                         { quality = 1; price = 150; };	
class 200Rnd_65x39_cased_box_blank                              { quality = 1; price = 150; };	
class 30Rnd_65x39_caseless_msbs_mag                             { quality = 1; price = 100; };	
class 30Rnd_65x39_caseless_msbs_mag_Tracer                      { quality = 1; price = 100; };	
class 30Rnd_65x39_caseless_msbs_blank_mag                       { quality = 1; price = 100; };	
class 6Rnd_12Gauge_Slug                                         { quality = 1; price = 100; };	
class 6Rnd_12Gauge_Pellets                                      { quality = 1; price = 100; };	
	
//////////////////////////////////////////ПУСКОВЫЕ УСТАНОВКИ////////////////////////////////////////////////	
	class launch_RPG32_green_F                                  { quality = 3; price = 5000; };
	class launch_I_Titan_eaf_F                                  { quality = 3; price = 60000; };
	class launch_B_Titan_olive_F                                { quality = 3; price = 60000; };
	
/////////////////////////////////////////НАВЕСЫ НА ОРУЖИЕ///////////////////////////////////////////////////////	
	class muzzle_snds_B_lush_F                                  { quality = 3; price = 500; };
	class muzzle_snds_B_arid_F                                  { quality = 3; price = 500; };
	class optic_Holosight_lush_F                                { quality = 3; price = 500; };
	class optic_Holosight_arid_F                                { quality = 3; price = 500; };
	class optic_ico_01_f                                        { quality = 3; price = 500; };
	class optic_ico_01_camo_f                                   { quality = 3; price = 500; };
	class optic_ico_01_sand_f                                   { quality = 3; price = 500; };
	class optic_ico_01_black_f                                  { quality = 3; price = 500; };
	class optic_Arco_lush_F                                     { quality = 3; price = 500; };
	class optic_Arco_arid_F                                     { quality = 3; price = 500; };
	class optic_Arco_AK_lush_F                                  { quality = 3; price = 500; };
	class optic_Arco_AK_arid_F                                  { quality = 3; price = 500; };
	class optic_Arco_AK_blk_F                                   { quality = 3; price = 500; };
	class optic_DMS_weathered_F                                 { quality = 3; price = 5500; };
	class optic_DMS_weathered_Kir_F                             { quality = 3; price = 5500; };
	class optic_MRD_black                                       { quality = 3; price = 500; };
	class bipod_02_F_lush                                       { quality = 3; price = 500; };
	class bipod_02_F_arid                                       { quality = 3; price = 500; };


	
	///////////////////////////////////////////////////////////////////////////////
	// @2035-RussianArmedForces
	///////////////////////////////////////////////////////////////////////////////
	
    //Тех камуфляж                                                                                         
	class min_rf_t_15                                             { quality = 7; price = 800000; };   // Курганец    
	class min_rf_gaz_2330                                         { quality = 3; price = 70000; };    // Тигр        
	class min_rf_gaz_2330_HMG                                     { quality = 5; price = 150000; };   // Тигр Корд   
	class min_rf_truck_medical                                    { quality = 3; price = 70000; };    // Камазы      
	class min_rf_truck_box                                        { quality = 3; price = 75000; };                 
	class min_rf_truck_ammo                                       { quality = 3; price = 75000; };                 
	class min_rf_truck_fuel                                       { quality = 3; price = 75000; };                 
	class min_rf_truck_transport                                  { quality = 3; price = 73000; };               
	class min_rf_truck_covered                                    { quality = 3; price = 74000; };                 
	class min_rf_sa_22                                            { quality = 7; price = 800000; };    // Панцырь     
	class min_rf_t_14                                             { quality = 7; price = 1500000; };   // Армата      
    //Тех зима                                                      
	class min_rf_t_15_winter                                      { quality = 7; price = 800000; };
	class min_rf_gaz_2330_winter                                  { quality = 3; price = 25000; };
	class min_rf_gaz_2330_HMG_winter                              { quality = 5; price = 100000; };
	class min_rf_truck_medical_winter                             { quality = 3; price = 70000; };
	class min_rf_truck_box_winter                                 { quality = 3; price = 75000; };
	class min_rf_truck_ammo_winter                                { quality = 3; price = 75000; };
	class min_rf_truck_fuel_winter                                { quality = 3; price = 75000; };
	class min_rf_truck_transport_winter                           { quality = 3; price = 73000; };
	class min_rf_truck_covered_winter                             { quality = 3; price = 74000; };
	class min_rf_sa_22_winter                                     { quality = 7; price = 800000; };
	class min_rf_t_14_winter                                      { quality = 7; price = 1500000; };
    //Тех пустыня                                                   
	class min_rf_t_15_desert                                      { quality = 7; price = 800000; };
	class min_rf_gaz_2330_desert                                  { quality = 3; price = 70000; };
	class min_rf_gaz_2330_HMG_desert                              { quality = 5; price = 150000; };
	class min_rf_truck_medical_desert                             { quality = 3; price = 70000; };
	class min_rf_truck_box_desert                                 { quality = 3; price = 75000; };
	class min_rf_truck_ammo_desert                                { quality = 3; price = 75000; };
	class min_rf_truck_fuel_desert                                { quality = 3; price = 75000; };
	class min_rf_truck_transport_desert                           { quality = 3; price = 73000; };
	class min_rf_truck_covered_desert                             { quality = 3; price = 74000; };
	class min_rf_sa_22_desert                                     { quality = 7; price = 800000; };
	class min_rf_t_14_desert                                      { quality = 7; price = 1500000; };
    // Воздух                                                                   
	class min_rf_ka_52                                            { quality = 5; price = 340000; };  // КА_50             
	class min_rf_heli_light_black                                 { quality = 5; price = 90000; };   // Касатка с оружием 
	class min_rf_heli_light_unarmed_black                         { quality = 5; price = 85000; };   // Касатка     
	class min_rf_su_34                                            { quality = 6; price = 550000; };  // СУ_34
	class min_rf_pchela_1t										  { quality = 5; price = 50000; };	//UAV
    // Воздух пустыня                                                
	class min_rf_ka_52_grey                                       { quality = 5; price = 340000; };
	class min_rf_heli_light_grey                                  { quality = 5; price = 90000; };
	class min_rf_heli_light_unarmed_grey                          { quality = 5; price = 85000; };
	class min_rf_su_34_desert                                     { quality = 6; price = 550000; };
    // Головные уборы                                                
	class min_rf_cap_surpat                                       { quality = 5; price = 100; };
	class min_rf_cap_flora                                        { quality = 5; price = 100; };
	class min_rf_cap_flora_desert                                 { quality = 5; price = 100; };
	class min_rf_bandana_white                                    { quality = 5; price = 100; };
	class min_rf_bandana_olive                                    { quality = 5; price = 100; };
	class min_rf_bandana_black                                    { quality = 5; price = 100; };
	class min_rf_beret_green                                      { quality = 5; price = 100; };
	class min_rf_beret_red                                        { quality = 5; price = 100; };
	class min_rf_cap_headphones                                   { quality = 5; price = 100; };
	class min_rf_headset                                          { quality = 5; price = 100; };
	class min_rf_ushanka                                          { quality = 5; price = 100; };
	class min_rf_beanie_white                                     { quality = 5; price = 100; };
	class min_rf_beanie_black                                     { quality = 5; price = 100; };
	class min_rf_hat_multicam                                     { quality = 5; price = 100; };
	class min_rf_hat_skol                                         { quality = 5; price = 100; };
	class min_rf_hat_surpat                                       { quality = 5; price = 100; };
	class min_rf_hat_flora                                        { quality = 5; price = 100; };
	class min_rf_hat_flora_desert                                 { quality = 5; price = 100; };
    // Жилеты                                                        
	class min_rf_combat_belt_vsr                                  { quality = 5; price = 450; };
	class min_rf_combat_belt_multicam                             { quality = 5; price = 450; };
	class min_rf_combat_belt_surpat                               { quality = 5; price = 450; };
	class min_rf_combat_belt_flora                                { quality = 5; price = 450; };
	class min_rf_combat_belt_green                                { quality = 5; price = 450; };
	class min_rf_combat_belt_black                                { quality = 5; price = 450; };
	class min_rf_armor_vest_GL_vsr                                { quality = 5; price = 450; };
	class min_rf_armor_vest_GL_multicam                           { quality = 5; price = 450; };
	class min_rf_armor_vest_GL_surpat                             { quality = 5; price = 450; };
	class min_rf_armor_vest_GL_flora                              { quality = 5; price = 450; };
	class min_rf_armor_vest_GL_green                              { quality = 5; price = 450; };
	class min_rf_armor_vest_GL_black                              { quality = 5; price = 450; };
	class min_rf_armor_vest_AR_vsr                                { quality = 5; price = 450; };
	class min_rf_armor_vest_AR_multicam                           { quality = 5; price = 450; };
	class min_rf_armor_vest_AR_surpat                             { quality = 5; price = 450; };
	class min_rf_armor_vest_AR_flora                              { quality = 5; price = 450; };
	class min_rf_armor_vest_AR_green                              { quality = 5; price = 450; };
	class min_rf_armor_vest_AR_black                              { quality = 5; price = 450; };
	class min_rf_armor_vest_M_vsr                                 { quality = 5; price = 450; };
	class min_rf_armor_vest_M_multicam                            { quality = 5; price = 450; };
	class min_rf_armor_vest_M_surpat                              { quality = 5; price = 450; };
	class min_rf_armor_vest_M_flora                               { quality = 5; price = 450; };
	class min_rf_armor_vest_M_green                               { quality = 5; price = 450; };
	class min_rf_armor_vest_M_black                               { quality = 5; price = 450; };
	class min_rf_lite_vest_GL_surpat                              { quality = 5; price = 450; };
	class min_rf_lite_vest_GL_flora                               { quality = 5; price = 450; };
	class min_rf_lite_vest_GL_green                               { quality = 5; price = 450; };
	class min_rf_lite_vest_GL_black                               { quality = 5; price = 450; };
	class min_rf_lite_vest_AR_vsr                                 { quality = 5; price = 450; };
	class min_rf_lite_vest_AR_multicam                            { quality = 5; price = 450; };
	class min_rf_lite_vest_AR_surpat                              { quality = 5; price = 450; };
	class min_rf_lite_vest_AR_flora                               { quality = 5; price = 450; };
	class min_rf_lite_vest_AR_green                               { quality = 5; price = 450; };
	class min_rf_lite_vest_AR_black                               { quality = 5; price = 450; };
	class min_rf_lite_vest_M_vsr                                  { quality = 5; price = 450; };
	class min_rf_lite_vest_M_multicam                             { quality = 5; price = 450; };
	class min_rf_lite_vest_M_surpat                               { quality = 5; price = 450; };
	class min_rf_lite_vest_M_flora                                { quality = 5; price = 450; };
	class min_rf_lite_vest_M_green                                { quality = 5; price = 450; };
	class min_rf_lite_vest_M_black                                { quality = 5; price = 450; };
	class min_rf_lite_vest_vsr                                    { quality = 5; price = 450; };
	class min_rf_lite_vest_multicam                               { quality = 5; price = 450; };
	class min_rf_lite_vest_surpat                                 { quality = 5; price = 450; };
	class min_rf_lite_vest_flora                                  { quality = 5; price = 450; };
	class min_rf_lite_vest_green                                  { quality = 5; price = 450; };
	class min_rf_lite_vest_black                                  { quality = 5; price = 450; };
	class min_rf_tactical_vest_GL_vsr                             { quality = 5; price = 450; };
	class min_rf_tactical_vest_GL_multicam                        { quality = 5; price = 450; };
	class min_rf_tactical_vest_GL_surpat                          { quality = 5; price = 450; };
	class min_rf_tactical_vest_GL_flora                           { quality = 5; price = 450; };
	class min_rf_tactical_vest_GL_green                           { quality = 5; price = 450; };
	class min_rf_tactical_vest_GL_black                           { quality = 5; price = 450; };
	class min_rf_tactical_vest_AR_vsr                             { quality = 5; price = 450; };
	class min_rf_tactical_vest_AR_multicam                        { quality = 5; price = 450; };
	class min_rf_tactical_vest_AR_surpat                          { quality = 5; price = 450; };
	class min_rf_tactical_vest_AR_flora                           { quality = 5; price = 450; };
	class min_rf_tactical_vest_AR_green                           { quality = 5; price = 450; };
	class min_rf_tactical_vest_AR_black                           { quality = 5; price = 450; };
	class min_rf_tactical_vest_M_vsr                              { quality = 5; price = 450; };
	class min_rf_tactical_vest_M_multicam                         { quality = 5; price = 450; };
	class min_rf_tactical_vest_M_surpat                           { quality = 5; price = 450; };
	class min_rf_tactical_vest_M_flora                            { quality = 5; price = 450; };
	class min_rf_tactical_vest_M_green                            { quality = 5; price = 450; };
	class min_rf_tactical_vest_M_black                            { quality = 5; price = 450; };
	class min_rf_tactical_vest_vsr                                { quality = 5; price = 450; };
	class min_rf_tactical_vest_multicam                           { quality = 5; price = 450; };
	class min_rf_tactical_vest_surpat                             { quality = 5; price = 450; };
	class min_rf_tactical_vest_flora                              { quality = 5; price = 450; };
	class min_rf_tactical_vest_green                              { quality = 5; price = 450; };
	class min_rf_tactical_vest_black                              { quality = 5; price = 450; };
	class min_rf_armor_vest_vsr                                   { quality = 5; price = 450; };
	class min_rf_armor_vest_multicam                              { quality = 5; price = 450; };
	class min_rf_armor_vest_surpat                                { quality = 5; price = 450; };
	class min_rf_armor_vest_flora                                 { quality = 5; price = 450; };
	class min_rf_armor_vest_green                                 { quality = 5; price = 450; };
	class min_rf_armor_vest_black                                 { quality = 5; price = 450; };
	class min_rf_highcapacity_special_GL_vsr                      { quality = 5; price = 450; };
	class min_rf_highcapacity_special_GL_multicam                 { quality = 5; price = 450; };
	class min_rf_highcapacity_special_GL_surpat                   { quality = 5; price = 450; };
	class min_rf_highcapacity_special_GL_flora                    { quality = 5; price = 450; };
	class min_rf_highcapacity_special_GL_green                    { quality = 5; price = 450; };
	class min_rf_highcapacity_special_GL_black                    { quality = 5; price = 450; };
	class min_rf_highcapacity_special_vsr                         { quality = 5; price = 450; };
	class min_rf_highcapacity_special_multicam                    { quality = 5; price = 450; };
	class min_rf_highcapacity_special_surpat                      { quality = 5; price = 450; };
	class min_rf_highcapacity_special_flora                       { quality = 5; price = 450; };
	class min_rf_highcapacity_special_green                       { quality = 5; price = 450; };
	class min_rf_highcapacity_special_black                       { quality = 5; price = 450; };
	class min_rf_highcapacity_vest_vsr                            { quality = 5; price = 450; };
	class min_rf_highcapacity_vest_multicam                       { quality = 5; price = 450; };
	class min_rf_highcapacity_vest_surpat                         { quality = 5; price = 450; };
	class min_rf_highcapacity_vest_flora                          { quality = 5; price = 450; };
	class min_rf_highcapacity_vest_green                          { quality = 5; price = 450; };
	class min_rf_highcapacity_vest_black                          { quality = 5; price = 450; };
	class min_rf_belt_surpat                                      { quality = 5; price = 450; };
	class min_rf_belt_flora                                       { quality = 5; price = 450; };
    // Рюкраки                                                       
	class min_rf_backpack_vsr                                     { quality = 5; price = 300; };    //гоблин
	class min_rf_backpack_surpat                                  { quality = 5; price = 300; };
	class min_rf_backpack_flora                                   { quality = 5; price = 300; };
	class min_rf_backpack_green                                   { quality = 5; price = 300; };
	class min_rf_backpack_winter                                  { quality = 5; price = 300; };
	class min_rf_backpack_black                                   { quality = 5; price = 300; };
	class min_rf_torna_vsr                                        { quality = 5; price = 300; };
	class min_rf_torna_surpat                                     { quality = 5; price = 300; };
	class min_rf_torna_flora                                      { quality = 5; price = 300; };
	class min_rf_torna_green                                      { quality = 5; price = 300; };
	class min_rf_torna_black                                      { quality = 5; price = 300; };
    // Форма                                                         
	class min_rf_emr_desert_ghillie                               { quality = 5; price = 250; };
	class min_rf_emr_ghillie                                      { quality = 5; price = 250; };
	class min_rf_winter_suit_hood_lite                            { quality = 5; price = 250; };
	class min_rf_winter_suit_hood                                 { quality = 5; price = 250; };
	class min_rf_winter_suit                                      { quality = 5; price = 250; };
	class min_rf_winter_suit_officer                              { quality = 5; price = 250; };
	class min_rf_pilot_desert_overall                             { quality = 5; price = 250; };
	class min_rf_pilot_overall                                    { quality = 5; price = 250; };
	class min_rf_helipilot_desert_overall                         { quality = 5; price = 250; };
	class min_rf_helipilot_overall                                { quality = 5; price = 250; };
	class min_rf_hex_officer                                      { quality = 5; price = 250; };
	class min_rf_hex                                              { quality = 5; price = 250; };
	class min_rf_hex_lite                                         { quality = 5; price = 250; };
	class min_rf_izlom_officer                                    { quality = 5; price = 250; };
	class min_rf_izlom                                            { quality = 5; price = 250; };
	class min_rf_izlom_lite                                       { quality = 5; price = 250; };
	class min_rf_surpat_officer                                   { quality = 5; price = 250; };
	class min_rf_surpat                                           { quality = 5; price = 250; };
	class min_rf_surpat_lite                                      { quality = 5; price = 250; };
	class min_rf_urban_officer                                    { quality = 5; price = 250; };
	class min_rf_urban_lite                                       { quality = 5; price = 250; };
	class min_rf_urban                                            { quality = 5; price = 250; };
	class min_rf_flora_officer                                    { quality = 5; price = 250; };
	class min_rf_flora                                            { quality = 5; price = 250; };
	class min_rf_flora_lite                                       { quality = 5; price = 250; };
	class min_rf_green_hex_officer                                { quality = 5; price = 250; };
	class min_rf_green_hex                                        { quality = 5; price = 250; };
	class min_rf_green_hex_lite                                   { quality = 5; price = 250; };
	class min_rf_flora_desert_officer                             { quality = 5; price = 250; };
	class min_rf_flora_desert                                     { quality = 5; price = 250; };
	class min_rf_flora_desert_lite                                { quality = 5; price = 250; };
	class min_rf_tactical_multicam                                { quality = 5; price = 250; };
	class min_rf_tactical_skol                                    { quality = 5; price = 250; };
	class min_rf_tactical_surpat                                  { quality = 5; price = 250; };
	class min_rf_tactical_emr                                     { quality = 5; price = 250; };
	class min_rf_gorka_officer                                    { quality = 5; price = 250; };
	class min_rf_gorka_hood                                       { quality = 5; price = 250; };
	class min_rf_gorka_hood_lite                                  { quality = 5; price = 250; };
	class min_rf_gorka                                            { quality = 5; price = 250; };
	class min_rf_gorka_lite                                       { quality = 5; price = 250; };
	class min_rf_klmk_officer                                     { quality = 5; price = 250; };
	class min_rf_klmk_hood                                        { quality = 5; price = 250; };
	class min_rf_klmk_hood_lite                                   { quality = 5; price = 250; };
	class min_rf_klmk                                             { quality = 5; price = 250; };
	class min_rf_klmk_lite                                        { quality = 5; price = 250; };
	class min_rf_gorka_partizan_officer                           { quality = 5; price = 250; };
	class min_rf_gorka_partizan_hood                              { quality = 5; price = 250; };
	class min_rf_gorka_partizan_hood_lite                         { quality = 5; price = 250; };
	class min_rf_gorka_partizan                                   { quality = 5; price = 250; };
	class min_rf_gorka_partizan_lite                              { quality = 5; price = 250; };
	class min_rf_gorka_surpat_officer                             { quality = 5; price = 250; };
	class min_rf_gorka_surpat_hood                                { quality = 5; price = 250; };
	class min_rf_gorka_surpat_hood_lite                           { quality = 5; price = 250; };
	class min_rf_gorka_surpat                                     { quality = 5; price = 250; };
	class min_rf_gorka_surpat_lite                                { quality = 5; price = 250; };
	class min_rf_emr_officer                                      { quality = 5; price = 250; };
	class min_rf_emr_hood                                         { quality = 5; price = 250; };
	class min_rf_emr_hood_lite                                    { quality = 5; price = 250; };
	class min_rf_emr                                              { quality = 5; price = 250; };
	class min_rf_emr_lite                                         { quality = 5; price = 250; };
	class min_rf_emr_desert_officer                               { quality = 5; price = 250; };
	class min_rf_emr_desert_hood                                  { quality = 5; price = 250; };
	class min_rf_emr_desert_hood_lite                             { quality = 5; price = 250; };
	class min_rf_emr_desert                                       { quality = 5; price = 250; };
	class min_rf_emr_desert_lite                                  { quality = 5; price = 250; };
    // Шлемы                                                         
	class min_rf_helmet_para                                      { quality = 5; price = 200; };
	class min_rf_helmet_mich_hex                                  { quality = 5; price = 200; };
	class min_rf_helmet_mich_urban                                { quality = 5; price = 200; };
	class min_rf_helmet_mich_green_hex                            { quality = 5; price = 200; };
	class min_rf_helmet_recon                                     { quality = 5; price = 200; };
	class min_rf_helmet_recon_desert                              { quality = 5; price = 200; };
	class min_rf_helmet_recon_black                               { quality = 5; price = 200; };
	class min_rf_helmet_crew_surpat                               { quality = 5; price = 200; };
	class min_rf_helmet_crew                                      { quality = 5; price = 200; };
	class min_rf_helmet_crew_winter                               { quality = 5; price = 200; };
	class min_rf_helmet_crew_desert                               { quality = 5; price = 200; };
	class min_rf_helmet_pilot                                     { quality = 5; price = 200; };
	class min_rf_helmet_ace                                       { quality = 5; price = 200; };
	class min_rf_helmet_soldier_izlom                             { quality = 5; price = 200; };
	class min_rf_helmet_soldier_surpat                            { quality = 5; price = 200; };
	class min_rf_helmet_soldier_flora                             { quality = 5; price = 200; };
	class min_rf_helmet_soldier_winter                            { quality = 5; price = 200; };
	class min_rf_helmet_soldier_desert                            { quality = 5; price = 200; };
    // Глушители                                                    
	class muzzle_min_rf_pbs_1                                     { quality = 5; price = 100150; };
	class muzzle_min_rf_tgp_a                                     { quality = 5; price = 100150; };
    // Прицелы                                                            
	class optic_min_rf_pkm_a                                      { quality = 5; price = 300; };
	class optic_min_rf_ekp_8_18                                   { quality = 5; price = 300; };
	class optic_min_rf_eotech_553                                 { quality = 5; price = 300; };
	class optic_min_rf_1p_87                                      { quality = 5; price = 300; };
	class optic_min_rf_po_4x24_p                                  { quality = 5; price = 300; };
	class optic_min_rf_1pn_97                                     { quality = 5; price = 300; };
    // Пистолет-Пулемёты                                             
	class SMG_min_rf_pp_2000                                      { quality = 5; price = 1350; };
    // Пулемёты                                                             
	class LMG_min_rf_6p69_camo                                    { quality = 5; price = 11500; };
	class LMG_min_rf_6p69_desert                                  { quality = 5; price = 11500; };
	class LMG_min_rf_6p69                                         { quality = 5; price = 11500; };
    // Снайперские винтовки                                                
	class srifle_min_rf_vs_121_winter                             { quality = 5; price = 1800; };
	class srifle_min_rf_vs_121_camo                               { quality = 5; price = 1800; };
	class srifle_min_rf_vs_121_desert                             { quality = 5; price = 1800; };
	class srifle_min_rf_vs_121                                    { quality = 5; price = 1800; };
	class srifle_min_rf_orsis_t5000_winter                        { quality = 5; price = 12500; };
	class srifle_min_rf_orsis_t5000_camo                          { quality = 5; price = 12500; };
	class srifle_min_rf_orsis_t5000_desert                        { quality = 5; price = 12500; };
    // Штурмовые винтовки                                                   
	class arifle_min_rf_ash_12_camo                               { quality = 5; price = 1850; };
	class arifle_min_rf_ash_12_desert                             { quality = 5; price = 1850; };
	class arifle_min_rf_ash_12                                    { quality = 5; price = 1850; };
	class arifle_min_rf_aek_a545_winter                           { quality = 5; price = 850; };
	class arifle_min_rf_aek_a545_camo                             { quality = 5; price = 850; };
	class arifle_min_rf_aek_a545_desert                           { quality = 5; price = 850; };
	class arifle_min_rf_aek_a545                                  { quality = 5; price = 850; };
	class arifle_min_rf_aek_a545_folded_winter                    { quality = 5; price = 850; };
	class arifle_min_rf_aek_a545_folded_camo                      { quality = 5; price = 850; };
	class arifle_min_rf_aek_a545_folded_desert                    { quality = 5; price = 850; };
	class arifle_min_rf_aek_a545_folded                           { quality = 5; price = 850; };
	class arifle_min_rf_ak_12_gp_winter                           { quality = 5; price = 850; };
	class arifle_min_rf_ak_12_gp_camo                             { quality = 5; price = 850; };
	class arifle_min_rf_ak_12_gp_desert                           { quality = 5; price = 850; };
	class arifle_min_rf_ak_12_gp                                  { quality = 5; price = 850; };
	class arifle_min_rf_ak_12_winter                              { quality = 5; price = 850; };
	class arifle_min_rf_ak_12_camo                                { quality = 5; price = 850; };
	class arifle_min_rf_ak_12_desert                              { quality = 5; price = 850; };
	class arifle_min_rf_ak_12                                     { quality = 5; price = 850; };
	class arifle_min_rf_ak_12_grip_winter                         { quality = 5; price = 850; };
	class arifle_min_rf_ak_12_grip_camo                           { quality = 5; price = 850; };
	class arifle_min_rf_ak_12_grip_desert                         { quality = 5; price = 850; };
	class arifle_min_rf_ak_12_grip                                { quality = 5; price = 850; };	
	// Боеприпассы
	class 100Rnd_min_rf_762x54_Box                                { quality = 1; price = 100; };
    class 100Rnd_min_rf_762x54_T_Box                              { quality = 1; price = 100; };
    class 20Rnd_min_rf_9x19_T_Mag                                 { quality = 1; price = 50; };
    class 5Rnd_min_rf_338_Mag                                     { quality = 1; price = 100; };
    class 20Rnd_min_rf_127x55_Mag                                 { quality = 1; price = 80; };
	/*
	///////////////////////////////////////////////////////////////////////////////
	// WY Snow Vests // Жилеты
	///////////////////////////////////////////////////////////////////////////////
	class WY_Vest_snow_a						{ quality = 3; price = 350; sellPrice = 300; };
	class WY_Vest_snow_b						{ quality = 3; price = 350; sellPrice = 300; };
	class WY_Vest_snow_c	                    { quality = 3; price = 350; sellPrice = 300; };
	class WY_Vest_snow_tact_a				    { quality = 3; price = 350; sellPrice = 300; };
	class WY_Vest_snow_tact_b					{ quality = 3; price = 350; sellPrice = 300; };
	class WY_Vest_snow_tact_c	                { quality = 3; price = 350; sellPrice = 300; };

    ///////////////////////////////////////////////////////////////////////////////
	// WY Snow HeadGears // Головные уборы
	///////////////////////////////////////////////////////////////////////////////
	class WY_Snow_Boonie_a						{ quality = 3; price = 350; sellPrice = 300; };
	class WY_Snow_Boonie_b						{ quality = 3; price = 350; sellPrice = 300; };
	class WY_Snow_Boonie_c	                    { quality = 3; price = 350; sellPrice = 300; };
	class WY_Snow_Boonie_d						{ quality = 3; price = 350; sellPrice = 300; };
	class WY_Snow_Boonie_e						{ quality = 3; price = 350; sellPrice = 300; };
	class WY_Snow_Boonie_f	                    { quality = 3; price = 350; sellPrice = 300; };

	class WY_Snow_Shemag_a						{ quality = 3; price = 350; sellPrice = 300; };
	class WY_Snow_Shemag_b						{ quality = 3; price = 350; sellPrice = 300; };
	class WY_Snow_Shemag_c	                    { quality = 3; price = 350; sellPrice = 300; };
	class WY_Snow_Shemag_d						{ quality = 3; price = 350; sellPrice = 300; };
	class WY_Snow_Shemag_e						{ quality = 3; price = 350; sellPrice = 300; };
	class WY_Snow_Shemag_f	                    { quality = 3; price = 350; sellPrice = 300; };

	class WY_Snow_PilotHelmetHeli_O				{ quality = 3; price = 350; sellPrice = 300; };
	class WY_Snow_CrewtHelmetHeli_O				{ quality = 3; price = 350; sellPrice = 300; };
	class WY_Snow_H_HelmetO_ocamo_a	            { quality = 3; price = 350; sellPrice = 300; };
	class WY_Snow_H_HelmetO_ocamo_b				{ quality = 3; price = 350; sellPrice = 300; };

	class WY_Snow_H_Watchcap_a				    { quality = 3; price = 350; sellPrice = 300; };
	class WY_Snow_H_Watchcap_b	                { quality = 3; price = 350; sellPrice = 300; };

	///////////////////////////////////////////////////////////////////////////////
	// WY Snow Backpacks // Рюкзаки
	///////////////////////////////////////////////////////////////////////////////
	class WY_Snow_Carryall_A				    { quality = 3; price = 350; sellPrice = 300; };
	class WY_Snow_Carryall_B					{ quality = 3; price = 350; sellPrice = 300; };
	class WY_Snow_Carryall_C	                { quality = 3; price = 350; sellPrice = 300; };
	class WY_Snow_Carryall_D					{ quality = 3; price = 350; sellPrice = 300; };
	class WY_Snow_Carryall_E				    { quality = 3; price = 350; sellPrice = 300; };
	class WY_Snow_Carryall_F	                { quality = 3; price = 350; sellPrice = 300; };

	class WY_Snow_AssoultPack_A				    { quality = 3; price = 350; sellPrice = 300; };
	class WY_Snow_AssoultPack_B					{ quality = 3; price = 350; sellPrice = 300; };
	class WY_Snow_AssoultPack_C	                { quality = 3; price = 350; sellPrice = 300; };
	class WY_Snow_AssoultPack_D					{ quality = 3; price = 350; sellPrice = 300; };
	class WY_Snow_AssoultPack_E					{ quality = 3; price = 350; sellPrice = 300; };


	///////////////////////////////////////////////////////////////////////////////      
	// WY Snow Facewear // Одежда для лица                                               
	///////////////////////////////////////////////////////////////////////////////      
	class WY_Snow_G_Combat_a				    { quality = 3; price = 350; sellPrice = 300; };
	class WY_Snow_G_Combat_b					{ quality = 3; price = 350; sellPrice = 300; };
	class WY_Snow_G_Combat_c	                { quality = 3; price = 350; sellPrice = 300; };
	class WY_Snow_G_Balaclava_combat_a			{ quality = 3; price = 350; sellPrice = 300; };
	class WY_Snow_G_Balaclava_combat_b			{ quality = 3; price = 350; sellPrice = 300; };
	class WY_Snow_G_Balaclava_combat_c	        { quality = 3; price = 350; sellPrice = 300; };
	class WY_Snow_G_Balaclava	                { quality = 3; price = 350; sellPrice = 300; };
	
	
	///////////////////////////////////////////////////////////////////////////////
	// WY Snow Uniforms // Униформа
	///////////////////////////////////////////////////////////////////////////////
	class WY_Snow_co_a						    { quality = 3; price = 500; sellPrice = 350; };
	class WY_Snow_co_b						    { quality = 3; price = 500; sellPrice = 350; };
	class WY_Snow_co_c						    { quality = 3; price = 500; sellPrice = 350; };
	class WY_GhillieFull_Night				    { quality = 3; price = 500; sellPrice = 350; };
	class WY_GhillieFull_Day				    { quality = 3; price = 500; sellPrice = 350; };
	class WY_GhillieLeo						    { quality = 3; price = 500; sellPrice = 350; };
	class WY_Snow_i_a						    { quality = 3; price = 500; sellPrice = 350; };
	class WY_Snow_i_b						    { quality = 3; price = 500; sellPrice = 350; };
	class WY_Snow_i_c						    { quality = 3; price = 500; sellPrice = 350; };
	class WY_Ghillie_coverall_a				    { quality = 3; price = 500; sellPrice = 350; };
	class WY_Ghillie_coverall_b				    { quality = 3; price = 500; sellPrice = 350; };

	///////////////////////////////////////////////////////////////////////////////
	// WY Snow Offroads
	///////////////////////////////////////////////////////////////////////////////
	class WY_Snow_Offroad_A						    { quality = 3; price = 16000; };
	class WY_Snow_Offroad_B						    { quality = 3; price = 16000; };
	class WY_Snow_Offroad_C						    { quality = 3; price = 16000; };
	class WY_Snow_Offroad_armed_D				    { quality = 4; price = 25000; };
	class WY_Snow_Offroad_armed_E				    { quality = 4; price = 25000; };
	class WY_Snow_Offroad_F						    { quality = 3; price = 16000; };

	///////////////////////////////////////////////////////////////////////////////
	// WY Snow Quadbikes
	///////////////////////////////////////////////////////////////////////////////
	class WY_Snow_Quadbike_F_A						{ quality = 3; price = 2500; };
	class WY_Snow_Quadbike_F_B						{ quality = 3; price = 2500; };
	class WY_Snow_Quadbike_F_C	                    { quality = 3; price = 2500; };
	class WY_Snow_Quadbike_F_D						{ quality = 3; price = 2500; };
	class WY_Snow_Quadbike_F_E						{ quality = 3; price = 2500; };
	class WY_Snow_Quadbike_F_F	                    { quality = 3; price = 2500; };


	///////////////////////////////////////////////////////////////////////////////
	// WY Snow Hunters
	///////////////////////////////////////////////////////////////////////////////
	class WY_Snow_B_MRAP_01_F_A						{ quality = 3; price = 65000; };
	class WY_Snow_B_MRAP_01_armed_F_B				{ quality = 4; price = 90000; };
	class WY_Snow_B_MRAP_01_F_C						{ quality = 3; price = 65000; };
	class WY_Snow_B_MRAP_01_F_D						{ quality = 3; price = 65000; };
	class WY_Snow_B_MRAP_01_armed_F_E				{ quality = 4; price = 90000; };
	class WY_Snow_B_MRAP_01_armed_F_F				{ quality = 4; price = 90000; };

	///////////////////////////////////////////////////////////////////////////////
	// WY Snow Hemmts
	///////////////////////////////////////////////////////////////////////////////
	class WY_Snow_B_Truck_01_fuel_F_A				{ quality = 4; price = 75000; };
	class WY_Snow_B_Truck_01_fuel_F_B				{ quality = 4; price = 75000; };
	class WY_Snow_B_Truck_01_ammo_F_C	            { quality = 4; price = 75000; };
	class WY_Snow_B_Truck_01_ammo_F_D				{ quality = 4; price = 75000; };
	class WY_Snow_B_Truck_01_mover_F_E				{ quality = 3; price = 48000; };
	class WY_Snow_B_Truck_01_mover_F_F	            { quality = 3; price = 48000; };

	///////////////////////////////////////////////////////////////////////////////
	// WY Snow Kamaz
	///////////////////////////////////////////////////////////////////////////////
	class WY_Snow_I_Truck_02_fuel_F_A				{ quality = 3; price = 45000; };
	class WY_Snow_I_Truck_02_fuel_F_B				{ quality = 3; price = 45000; };
	class WY_Snow_I_Truck_02_covered_F_C	        { quality = 3; price = 43000; };
	class WY_Snow_I_Truck_02_covered_F_D			{ quality = 3; price = 43000; };
	class WY_Snow_I_Truck_02_transport_F_E			{ quality = 3; price = 43000; };
	class WY_Snow_I_Truck_02_transport_F_F	        { quality = 3; price = 43000; };

	///////////////////////////////////////////////////////////////////////////////
	// WY Snow Strider
	///////////////////////////////////////////////////////////////////////////////
	class WY_Snow_I_mrap_03_F_A						{ quality = 3; price = 90000; };
	class WY_Snow_I_mrap_03_F_B						{ quality = 3; price = 90000; };
	class WY_Snow_I_mrap_03_gmg_F_C	                { quality = 4; price = 150000; };
	class WY_Snow_I_mrap_03_gmg_F_D				    { quality = 4; price = 150000; };

	///////////////////////////////////////////////////////////////////////////////
	// WY Snow Heli Light 1
	///////////////////////////////////////////////////////////////////////////////
	class WY_Snow_B_Heli_Light_01_F_A			    { quality = 3; price = 17000; };
	class WY_Snow_B_Heli_Light_01_F_B			    { quality = 3; price = 17000; };
	class WY_Snow_B_Heli_Light_01_F_C	            { quality = 3; price = 17000; };

	///////////////////////////////////////////////////////////////////////////////
	// WY Snow Transport 1
	///////////////////////////////////////////////////////////////////////////////
	class WY_Snow_B_Heli_Transport_01_F_A			{ quality = 3; price = 400000; };
	class WY_Snow_B_Heli_Transport_01_F_B			{ quality = 3; price = 400000; };
	class WY_Snow_B_Heli_Transport_01_F_C	        { quality = 3; price = 400000; };

	///////////////////////////////////////////////////////////////////////////////
	// WY Snow Transport 3
	///////////////////////////////////////////////////////////////////////////////
	class WY_Snow_B_Heli_Transport_03_F_A			{ quality = 3; price = 80000; };
	class WY_Snow_B_Heli_Transport_03_F_B			{ quality = 3; price = 80000; };
	class WY_Snow_B_Heli_Transport_03_F_C	        { quality = 3; price = 80000; };

	///////////////////////////////////////////////////////////////////////////////
	// WY Snow APC WHEELED
	///////////////////////////////////////////////////////////////////////////////
	class WY_Snow_O_APC_Wheeled_02_rcws_F_a		    { quality = 5; price = 400000; };
	class WY_Snow_O_APC_Wheeled_02_rcws_F_b		    { quality = 5; price = 400000; };
	class WY_Snow_O_APC_Wheeled_02_rcws_F_c	        { quality = 5; price = 400000; };

	///////////////////////////////////////////////////////////////////////////////
	// WY Snow IFRIT
	///////////////////////////////////////////////////////////////////////////////
	class WY_Snow_O_MRAP_02_base_F_a				{ quality = 3; price = 70000; };
	class WY_Snow_O_MRAP_02_gmg_F_b				    { quality = 4; price = 95000; };
	class WY_Snow_O_MRAP_02_gmg_F_c	                { quality = 4; price = 95000; };

	///////////////////////////////////////////////////////////////////////////////
	// WY Snow Heli Light 3
	///////////////////////////////////////////////////////////////////////////////
	class WY_Snow_I_Heli_light_03_unarmed_F_a		{ quality = 3; price = 30000; };
	class WY_Snow_I_Heli_light_03_F_b				{ quality = 4; price = 35000; };
	class WY_Snow_I_Heli_light_03_F_c	            { quality = 4; price = 35000; };

	///////////////////////////////////////////////////////////////////////////////
	// WY Snow Heli Light 2
	///////////////////////////////////////////////////////////////////////////////
	class WY_Snow_O_Heli_Light_02_unarmed_F_a		{ quality = 3; price = 85000; };
	class WY_Snow_O_Heli_Light_02_unarmed_F_b		{ quality = 3; price = 85000; };
	class WY_Snow_O_Heli_Light_02_F_c	            { quality = 4; price = 90000; };


	///////////////////////////////////////////////////////////////////////////////
	// WY Snow Weapons // оружие
	///////////////////////////////////////////////////////////////////////////////

	class WY_Snow_cheytac_m200_A			    { quality = 4; price = 2500; };
	class WY_Snow_cheytac_m200_B				{ quality = 4; price = 2500; };
	class WY_Snow_Rahim_a						{ quality = 3; price = 1500; };
	class WY_Snow_Rahim_b						{ quality = 3; price = 1500; };
	class WY_Snow_Mar10_a						{ quality = 4; price = 1500; };
	class WY_Snow_Mar10_b						{ quality = 4; price = 1500; };
	class WY_Snow_MK_I_EMR_a					{ quality = 3; price = 1500; };
	class WY_Snow_MK_I_EMR_b					{ quality = 3; price = 1500; };
	class WY_Snow_MMG_01_a						{ quality = 3; price = 1500; };
	class WY_Snow_MMG_01_b						{ quality = 3; price = 1500; };
	class WY_Snow_LMG_Zafir_F_a					{ quality = 3; price = 850; };
	class WY_Snow_LMG_Zafir_F_b					{ quality = 3; price = 850; };
	class WY_Snow_MX_F_a						{ quality = 3; price = 850; };
	class WY_Snow_MX_F_b						{ quality = 3; price = 850; };
	class WY_Snow_MXM_F_a						{ quality = 3; price = 1450; };

	class WY_Snow_GM6_F_a						{ quality = 4; price = 2500; };
	class WY_Snow_GM6_F_b						{ quality = 4; price = 2500; };
	class WY_Snow_GM6_F_c						{ quality = 4; price = 2500; };
	class WY_Snow_MMG_02_a						{ quality = 3; price = 1500; };
	class WY_Snow_MMG_02_b						{ quality = 3; price = 1500; };
	class WY_Snow_MMG_02_c						{ quality = 3; price = 1500; };

	///////////////////////////////////////////////////////////////////////////////
	// WY Snow NV Goggles // очки
	///////////////////////////////////////////////////////////////////////////////

    class WY_Snow_NVGoggles						{ quality = 3; price = 500; sellPrice = 250; };

    //////////////////////////////////////////////////////////////////////////////////
    // WY ToolKIT
    //////////////////////////////////////////////////////////////////////////////////

    //class WY_ToolKit

	// Конец WY Snow
	*/
	
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////BELtraicer PRICES/////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////CARS & TRUCKS///////////////////////////////////////////////////////////

	class Exile_Car_Ikarus_Blue 							        	{ quality = 1; price = 15000; };
	class Ikarus_Govnodav_01 				   					     	{ quality = 1; price = 15000; };
	class Ikarus_Govnodav_02	 			    				    	{ quality = 1; price = 15000; };
	class B_G_Offroad_01_F                                              { quality = 1; price = 15000; };	
	class O_G_Offroad_01_F                                              { quality = 1; price = 15000; };	
	class C_Offroad_01_F                                                { quality = 1; price = 15000; };	
	class SUV_civ_01                                         		    { quality = 1; price = 20000; };	
	class B_G_Offroad_01_repair_F                                       { quality = 2; price = 20000; };	
	class O_G_Offroad_01_repair_F                                       { quality = 2; price = 20000; };	
	class I_G_Offroad_01_repair_F                                       { quality = 2; price = 20000; };
	class SUV_armored_Base										    	{ quality = 3; price = 25000; };
	class Exile_Car_SUV_Armed_Black 							 		{ quality = 3; price = 25000; };
	class UAZ_AGS30_Base	                							{ quality = 3; price = 25000;};
	class UAZ_MG_Base	                								{ quality = 3; price = 25000;};
	class HMMWV_M2_des                                           	    { quality = 3; price = 25000; };	
	class HMMWV_M2_GPK_1                                                { quality = 3; price = 25000; };	
	class HMMWV_M2_GPK_Base                                             { quality = 3; price = 25000; };
	class Exile_Car_HMMWV_M2_Green 								    	{ quality = 3; price = 25000; };
	class Exile_Car_HMMWV_M2_Desert 									{ quality = 3; price = 25000; };
	class B_G_Offroad_01_AT_F											{ quality = 3; price = 25000; };
	class O_G_Offroad_01_AT_F                                           { quality = 3; price = 25000; };
	class I_G_Offroad_01_armed_F              	                        { quality = 3; price = 25000; };
	class I_G_Offroad_01_AT_F                                           { quality = 3; price = 25000; };	
	class O_G_Offroad_01_armed_F                                        { quality = 3; price = 25000; };	
	class B_G_Offroad_01_armed_F                                        { quality = 3; price = 25000; };	
	class B_G_Van_01_fuel_F                                             { quality = 3; price = 30000; };	
	class O_G_Van_01_transport_F                                        { quality = 3; price = 30000; };	
	class O_G_Van_01_fuel_F                                             { quality = 3; price = 30000; };	
	class B_G_Van_01_transport_F                                        { quality = 3; price = 30000; };	
	class I_G_Van_01_transport_F                                        { quality = 3; price = 30000; };	
	class I_G_Van_01_fuel_F                                             { quality = 3; price = 30000; };	
	class C_Van_01_transport_F                                          { quality = 3; price = 30000; };	
	class C_Van_01_box_F                                                { quality = 3; price = 30000; };	
	class C_Van_01_fuel_F                                               { quality = 3; price = 30000; };
	class Exile_Car_V3S_Covered			     				            { quality = 3; price = 30000; };
	class Exile_Car_V3S_Open			           					    { quality = 3; price = 30000; };
	class V3S_base                                       		        { quality = 3; price = 30000; };	
	class V3S_Base_EP1                                        	        { quality = 3; price = 30000; };
	class Exile_Car_Van_White 											{ quality = 3; price = 30000; };
	class Exile_Car_Van_Box_Guerilla03 									{ quality = 3; price = 30000; };
	class Exile_Car_Van_Fuel_Red 										{ quality = 3; price = 30000; };
	class Exile_Car_Ural_Covered_Military		    				    { quality = 3; price = 35000; };
	class Exile_Car_Ural_Covered_Yellow			 				        { quality = 3; price = 35000; };
	class Exile_Car_Ural_Open_Military		         				    { quality = 3; price = 35000; };
	class Ural_Civ_03                                      		        { quality = 3; price = 35000; };	
	class Ural_Open_Civ_03                                              { quality = 3; price = 35000; };	
	class Ural_Open_Civ_02                                              { quality = 3; price = 35000; };	
	class O_Truck_02_transport_F                                        { quality = 3; price = 35000; };	
	class O_Truck_02_covered_F                                          { quality = 3; price = 35000; };	
	class I_Truck_02_transport_F                                        { quality = 3; price = 35000; };	
	class I_Truck_02_covered_F                                          { quality = 3; price = 35000; };	
	class O_Truck_02_medical_F                                          { quality = 3; price = 40000; };
	class O_Truck_02_box_F											    { quality = 3; price = 40000; };
	class O_Truck_02_Ammo_F							 			        { quality = 3; price = 50000; };
	class O_Truck_02_fuel_F							 				    { quality = 3; price = 50000; };
	class I_Truck_02_medical_F               				            { quality = 3; price = 40000; };
	class I_Truck_02_box_F                                              { quality = 3; price = 40000; };	
	class I_Truck_02_ammo_F                                             { quality = 3; price = 50000; };	
	class I_Truck_02_fuel_F                                             { quality = 3; price = 50000; };	
	class C_Truck_02_fuel_F                                             { quality = 3; price = 50000; };	
	class C_Truck_02_box_F                                              { quality = 3; price = 40000; };
	class O_Truck_03_repair_F						  				    { quality = 3; price = 50000; };
	class O_Truck_03_medical_F										    { quality = 3; price = 50000; };
	class O_Truck_03_fuel_F											    { quality = 3; price = 50000; };
	class O_Truck_03_transport_F                     				    { quality = 3; price = 50000; };
	class O_Truck_03_covered_F                 				            { quality = 3; price = 50000; };
	class O_Truck_03_ammo_F											    { quality = 3; price = 50000; };
	class O_Truck_03_device_F                                           { quality = 3; price = 500000; };
	class B_MRAP_01_gmg_F												{ quality = 3; price = 100000; };
	class B_MRAP_01_hmg_F												{ quality = 3; price = 100000; };
	class O_MRAP_02_gmg_F												{ quality = 3; price = 100000; };
	class O_MRAP_02_hmg_F												{ quality = 3; price = 100000; };
	class I_MRAP_03_hmg_F												{ quality = 3; price = 100000; };
	class I_MRAP_03_gmg_F												{ quality = 3; price = 100000; };
	
///////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////APC & TANKs////////////////////////////////////////////////////////////////
	
	class O_APC_Wheeled_02_rcws_v2_F             				        { quality = 3; price = 150000; };
	class B_APC_Wheeled_01_cannon_F                   				    { quality = 5; price = 450000; };
	class I_APC_Wheeled_03_cannon_F                   				    { quality = 5; price = 450000; };
	class I_APC_tracked_03_cannon_F                 				    { quality = 4; price = 400000; };
	class B_APC_Tracked_01_CRV_F                   				        { quality = 4; price = 550000; };
	class B_APC_Tracked_01_rcws_F                				        { quality = 4; price = 360000; };
	class O_APC_Tracked_02_cannon_F                   				    { quality = 5; price = 450000; };
	class O_APC_Tracked_02_AA_F           				                { quality = 7; price = 500000; };
	class B_APC_Tracked_01_AA_F                				            { quality = 6; price = 400000; };
	class B_MBT_01_cannon_F                  				            { quality = 7; price = 1000000; };
    class B_MBT_01_TUSK_F 	                 				            { quality = 7; price = 1050000; };
    //class B_MBT_01_TUSK_F 	                 				            { quality = 7; price = 1050000; };
    class CUP_B_M1A2C_TUSK_NATO 	                 				    { quality = 7; price = 1250000; };
	class O_MBT_02_cannon_F                       				        { quality = 7; price = 1100000; };
	class I_MBT_03_cannon_F                      				        { quality = 7; price = 1100000; };
	
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////Helis & Jets///////////////////////////////////////////////////////////////

///////////////////////////////////////////HELIS///////////////////////////////////////////////////////////////
	
	class Exile_Chopper_Hummingbird_Green						    	{ quality = 3; price = 230000; sellPrice = 10000; };
	class B_Heli_Light_01_F                                             { quality = 3; price = 230000; };	
	class B_Heli_Light_01_dynamicLoadout_F                              { quality = 3; price = 1000000; };
	class Exile_Chopper_Mohawk_FIA										{ quality = 3; price = 500000; };
	class Exile_Chopper_Huron_Black										{ quality = 5; price = 800000; };
	class Exile_Chopper_Huron_Green										{ quality = 5; price = 800000; };
	class Exile_Chopper_Taru_Transport_CSAT								{ quality = 2; price = 1100000; };
	class Exile_Chopper_Taru_Transport_Black							{ quality = 2; price = 1100000; };
	class Exile_Chopper_Taru_CSAT										{ quality = 2; price = 1100000; };
	class Exile_Chopper_Taru_Black										{ quality = 2; price = 1100000; };
	class Exile_Chopper_Taru_Covered_CSAT								{ quality = 2; price = 1150000; };
	class Exile_Chopper_Taru_Covered_Black								{ quality = 2; price = 1150000; };	
	class I_Heli_Transport_02_F                                         { quality = 2; price = 500000; };
    class B_Heli_Transport_01_F          					            { quality = 3; price = 1000000; };
	class O_Heli_Light_02_dynamicLoadout_F                              { quality = 3; price = 2000000; };
	class I_Heli_light_03_dynamicLoadout_F                   	        { quality = 5; price = 3500000; };
	class O_Heli_Attack_02_dynamicLoadout_F                 	        { quality = 3; price = 4500000; };
	class O_Heli_Attack_02_F                     					    { quality = 7; price = 4500000; }; // кайман
	class O_Heli_Attack_02_black_F               					    { quality = 7; price = 4500000; }; // кайман
	class B_Heli_Attack_01_dynamicLoadout_F								{ quality = 7; price = 5000000; }; //AH 99
	class Exile_Plane_BlackfishVehicle									{ quality = 7; price = 5000000; };
	
///////////////////////////////////////JETS////////////////////////////////////////////////////////////////////////
	class I_Plane_Fighter_03_dynamicLoadout_F                           { quality = 7; price = 4000000; };
	class O_Plane_CAS_02_dynamicLoadout_F								{ quality = 7; price = 5500000; };	
	class B_Plane_CAS_01_dynamicLoadout_F                               { quality = 7; price = 6000000; };
	class B_Plane_CAS_01_F  											{ quality = 7; price = 6000000; };
	
///////////////////////////////////////////////UAVs////////////////////////////////////////////////////////////////
	class B_UAV_02_dynamicLoadout_F		        					    { quality = 6; price = 65000; };
	class O_UAV_02_dynamicLoadout_F		        					    { quality = 6; price = 65000; };
	class I_UAV_02_dynamicLoadout_F		        	 				    { quality = 6; price = 70000; };

//////////////////////////////////////////////UGVs////////////////////////////////////////////////////////////////
	class I_UGV_01_rcws_F												{ quality = 3; price = 50000; };
	class B_UGV_01_rcws_F                                               { quality = 3; price = 50000; };
	class O_UGV_01_rcws_F                                               { quality = 3; price = 50000; };

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////DLC CARS & TRUCKS//////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	class C_Tractor_01_F                         		                { quality = 1; price = 7000; };	
	class B_GEN_Offroad_01_gen_F                                        { quality = 1; price = 15000; };
	class B_GEN_Offroad_01_                                             { quality = 1; price = 15000; };
	class B_GEN_Offroad_01_covered_F       			                    { quality = 1; price = 15000; };
	class B_GEN_Offroad_01_comms_F                      		        { quality = 1; price = 15000; };
	class I_E_Offroad_01_F                              		        { quality = 1; price = 15000; };
	class I_E_Offroad_01_covered_F                		                { quality = 1; price = 15000; };
	class I_E_Offroad_01_comms_F                        		        { quality = 1; price = 15000; };
	class I_G_Offroad_01_F                               		        { quality = 1; price = 15000; };
	class C_Offroad_01_covered_F                             		    { quality = 1; price = 15000; };
	class C_Offroad_01_comms_F                               		    { quality = 1; price = 15000; };	
	class C_IDAP_Offroad_01_F                                           { quality = 1; price = 15000; };
	class B_LSV_01_armed_F                                   	        { quality = 2; price = 40000; };
	class B_LSV_01_AT_F													{ quality = 3; price = 40000; };	
	class B_T_LSV_01_armed_F                      			            { quality = 3; price = 40000; };
	class B_T_LSV_01_AT_F												{ quality = 3; price = 40000; };
    class O_LSV_02_armed_F                  				            { quality = 3; price = 40000; };
	class O_LSV_02_AT_F													{ quality = 3; price = 40000; };	
	class O_T_LSV_02_armed_F                                            { quality = 3; price = 40000; };
	class O_T_LSV_02_AT_F												{ quality = 3; price = 40000; };
	class I_C_Offroad_02_AT_F											{ quality = 3; price = 40000; };
	class I_C_Offroad_02_LMG_F                                          { quality = 3; price = 40000; };		
	class I_E_Van_02_transport_F                        		        { quality = 1; price = 20000; };
	class I_E_Van_02_transport_MP_F                       		        { quality = 1; price = 20000; };
	class I_E_Van_02_vehicle_F                         		            { quality = 1; price = 20000; };
	class B_GEN_Van_02_transport_F                                      { quality = 1; price = 20000; };
	class B_GEN_Van_02_vehicle_F                                        { quality = 1; price = 20000; };
	class B_G_Van_02_transport_F										{ quality = 1; price = 20000; };
	class O_G_Van_02_transport_F										{ quality = 1; price = 20000; };
	class O_G_Van_02_vehicle_F											{ quality = 1; price = 20000; };
	class I_C_Van_02_transport_F										{ quality = 1; price = 20000; };
	class I_C_Van_02_vehicle_F											{ quality = 1; price = 20000; };
	class C_Van_02_vehicle_F											{ quality = 1; price = 20000; };
	class C_Van_02_transport_F											{ quality = 1; price = 20000; };
	class C_IDAP_Van_02_transport_F										{ quality = 1; price = 20000; };
	class C_IDAP_Van_02_vehicle_F										{ quality = 1; price = 20000; };
	class I_E_Van_02_medevac_F                              		    { quality = 1; price = 30000; };
	class C_Van_02_medevac_F											{ quality = 1; price = 30000; };
	class C_Van_02_service_F											{ quality = 1; price = 30000; };
	class C_IDAP_Van_02_medevac_F                                       { quality = 1; price = 30000; };	
	class I_C_Van_01_transport_F                                        { quality = 3; price = 35000; };	
	class O_T_Truck_02_Medical_F                                        { quality = 2; price = 40000; };	
	class O_T_Truck_02_transport_F                                      { quality = 2; price = 40000; };	
	class O_T_Truck_02_F                                       	        { quality = 2; price = 40000; };
	class I_E_Truck_02_Medical_F                            		    { quality = 2; price = 40000; };
	class I_E_Truck_02_transport_F                       		        { quality = 2; price = 40000; };
	class I_E_Truck_02_F                               		            { quality = 2; price = 40000; };	
	class C_IDAP_Truck_02_transport_F                                   { quality = 2; price = 40000; };	
	class C_IDAP_Truck_02_F                                             { quality = 2; price = 40000; };	
	class O_T_Truck_03_medical_ghex_F                                   { quality = 2; price = 50000; };	
	class O_T_Truck_03_transport_ghex_F                                 { quality = 2; price = 50000; };
	class O_T_Truck_03_covered_ghex_F                                   { quality = 2; price = 50000; };	
	class B_Truck_01_transport_F                                        { quality = 2; price = 45000; };
	class B_Truck_01_covered_F                                          { quality = 2; price = 45000; };
	class B_Truck_01_box_F											    { quality = 2; price = 45000; };
	class B_Truck_01_medical_F										    { quality = 2; price = 45000; };	
	class B_T_Truck_01_transport_F                                      { quality = 2; price = 45000; };	
	class B_T_Truck_01_covered_F                                        { quality = 2; price = 45000; };	
	class B_T_Truck_01_box_F                                            { quality = 2; price = 45000; };	
	class B_T_Truck_01_medical_F                                        { quality = 2; price = 45000; };
	class B_Truck_01_cargo_F                             		        { quality = 2; price = 45000; };
	class B_Truck_01_flatbed_F                        		            { quality = 2; price = 45000; };
	class B_T_Truck_01_cargo_F                         		            { quality = 2; price = 45000; };
	class B_T_Truck_01_flatbed_F                             		    { quality = 2; price = 45000; };	
	class O_T_Truck_02_Box_F                                            { quality = 3; price = 50000; };	
	class O_T_Truck_02_Ammo_F                                           { quality = 3; price = 50000; };	
	class O_T_Truck_02_fuel_F                                           { quality = 3; price = 50000; };
	class I_E_Truck_02_Box_F                                		    { quality = 3; price = 50000; };
	class I_E_Truck_02_Ammo_F                         		            { quality = 3; price = 50000; };
	class I_E_Truck_02_fuel_F                   		                { quality = 3; price = 50000; };
	class C_IDAP_Truck_02_water_F                                       { quality = 3; price = 50000; };
	class B_Truck_01_Repair_F                                           { quality = 3; price = 50000; };
	class B_Truck_01_fuel_F											    { quality = 3; price = 50000; };
	class B_Truck_01_ammo_F											    { quality = 3; price = 50000; };	
	class B_T_Truck_01_Repair_F                                         { quality = 3; price = 50000; };	
	class B_T_Truck_01_fuel_F                                           { quality = 3; price = 50000; };	
	class B_T_Truck_01_ammo_F                                           { quality = 3; price = 50000; };	
	class O_T_Truck_03_repair_ghex_F                                    { quality = 3; price = 75000; };	
	class O_T_Truck_03_fuel_ghex_F                                      { quality = 3; price = 75000; };	
	class O_T_Truck_03_ammo_ghex_F                                      { quality = 3; price = 75000; };
	class O_T_Truck_03_device_ghex_F                                    { quality = 3; price = 500000; };	
	class B_T_MRAP_01_gmg_F                                             { quality = 3; price = 100000; };	
	class B_T_MRAP_01_hmg_F                                             { quality = 3; price = 100000; };	
	class O_T_MRAP_02_gmg_ghex_F                                        { quality = 3; price = 100000; };	
	class O_T_MRAP_02_hmg_ghex_F                                        { quality = 3; price = 100000; };

///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////DLC TANKs & APC/////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////

	class I_LT_01_AA_F													{ quality = 5; price = 300000; };
	class I_LT_01_AT_F													{ quality = 5; price = 300000; };
	class I_LT_01_cannon_F												{ quality = 5; price = 300000; };
	class O_T_APC_Wheeled_02_rcws_v2_ghex_F            				    { quality = 5; price = 150000; };
	class B_T_APC_Wheeled_01_cannon_F          				            { quality = 6; price = 450000; };
    class O_T_APC_Tracked_02_cannon_ghex_F   	      				    { quality = 6; price = 450000; }; 
	class I_E_APC_tracked_03_cannon_F                                   { quality = 6; price = 500000; };
	class B_T_APC_Tracked_01_CRV_F                 				        { quality = 5; price = 550000; }; 
	class B_T_APC_Tracked_01_rcws_F                   				    { quality = 5; price = 550000; };
	class B_T_APC_Tracked_01_AA_F                  				        { quality = 6; price = 600000; };
	class O_T_APC_Tracked_02_AA_ghex_F          				        { quality = 6; price = 500000; };
	class B_AFV_Wheeled_01_cannon_F										{ quality = 7; price = 800000; };
	class B_T_AFV_Wheeled_01_cannon_F									{ quality = 7; price = 800000; };
	class B_AFV_Wheeled_01_up_cannon_F									{ quality = 7; price = 850000; };
	class B_T_AFV_Wheeled_01_up_cannon_F								{ quality = 7; price = 850000; };
	class O_T_MBT_02_cannon_ghex_F                   				    { quality = 7; price = 1100000; };
	class B_T_MBT_01_cannon_F                   				        { quality = 7; price = 1000000; };
	class B_T_MBT_01_TUSK_F         				                    { quality = 7; price = 1050000; };
	class O_MBT_04_cannon_F										    	{ quality = 7; price = 1500000; };
	class O_T_MBT_04_cannon_F											{ quality = 7; price = 1500000; };
	class O_MBT_04_command_F											{ quality = 7; price = 1700000; };
	class O_T_MBT_04_command_F											{ quality = 7; price = 1700000; };
	
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////DLC HELIs & JETs///////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	class O_Heli_Transport_04_F                                         { quality = 3; price = 500000; };	
	class O_Heli_Transport_04_ammo_F                                    { quality = 3; price = 500000; };	
	class O_Heli_Transport_04_box_F                                     { quality = 3; price = 500000; };	
	class O_Heli_Transport_04_medevac_F                                 { quality = 3; price = 500000; };	
	class O_Heli_Transport_04_repair_F                                  { quality = 3; price = 500000; };	
	class O_Heli_Transport_04_bench_F                                   { quality = 3; price = 500000; };	
	class O_Heli_Transport_04_fuel_F                                    { quality = 3; price = 500000; };	
	class O_Heli_Transport_04_covered_F                                 { quality = 3; price = 500000; };	
	class B_CTRG_Heli_Transport_01_sand_F                               { quality = 3; price = 750000; };	
	class B_CTRG_Heli_Transport_01_tropic_F                             { quality = 3; price = 750000; };	
	class B_Heli_Transport_03_F                                         { quality = 3; price = 1000000; sellPrice = 100000; };
	class I_E_Heli_light_03_unarmed_F                      			    { quality = 3; price = 1000000; };
	class I_E_Heli_light_03_dynamicLoadout_F               		        { quality = 3; price = 2000000; };
	class B_T_VTOL_01_vehicle_F                                         { quality = 3; price = 3000000; };
	class B_T_VTOL_01_infantry_F                                        { quality = 3; price = 3000000; };
	class B_T_VTOL_01_armed_olive_F									    { quality = 7; price = 5000000; };	
	class B_T_VTOL_01_armed_blue_F									    { quality = 7; price = 5000000; };	
	class B_T_VTOL_01_armed_F					    				    { quality = 7; price = 5000000; };		
	class O_T_VTOL_02_vehicle_dynamicLoadout_F                          { quality = 7; price = 6000000; };	
	class O_T_VTOL_02_infantry_dynamicLoadout_F                         { quality = 7; price = 6000000; };
	class O_T_VTOL_02_vehicle_grey_F                 				  	{ quality = 7; price = 6000000; };	
	class O_T_VTOL_02_vehicle_ghex_F              				     	{ quality = 7; price = 6000000; };	
	class O_T_VTOL_02_vehicle_hex_F               				    	{ quality = 7; price = 6000000; };
	class I_Plane_Fighter_04_F											{ quality = 7; price = 4750000; };
	class O_Plane_Fighter_02_F											{ quality = 7; price = 4750000; };
	class O_Plane_Fighter_02_Stealth_F									{ quality = 7; price = 4000000; };
	class B_Plane_Fighter_01_F											{ quality = 7; price = 4750000; };
	class B_Plane_Fighter_01_Stealth_F									{ quality = 7; price = 4000000; };

////////////////////////////////////////////////DLC UAVs & UGVs///////////////////////////////////////////////////	
	class B_T_UAV_03_dynamicLoadout_F	        					    { quality = 6; price = 100000; };
    class O_T_UAV_04_CAS_F				        					    { quality = 6; price = 55000; };
	class B_UAV_05_F                                 				    { quality = 6; price = 100000; };
	class I_E_UGV_01_rcws_F                                   		    { quality = 3; price = 50000; };
	class B_T_UGV_01_rcws_olive_F                                       { quality = 3; price = 50000; };	
	class O_T_UGV_01_rcws_ghex_F                                        { quality = 3; price = 50000; };

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////CUP CARs & TRUCKs//////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	class CUP_B_TowingTractor_USMC                                      { quality = 1; price = 5000; };
    class CUP_O_UAZ_AGS30_SLA	                   				        { quality = 1; price = 20000; };
	class CUP_O_UAZ_MG_SLA                           				    { quality = 1; price = 20000; };
	class CUP_O_UAZ_METIS_SLA                    				        { quality = 1; price = 20000; };
	class CUP_O_UAZ_SPG9_SLA                 				            { quality = 1; price = 20000; };
	class CUP_O_UAZ_AGS30_RU	                 				        { quality = 1; price = 20000; };
	class CUP_O_UAZ_MG_RU	                    				        { quality = 1; price = 20000; };
	class CUP_O_UAZ_METIS_RU                  				            { quality = 1; price = 20000; };
	class CUP_O_UAZ_SPG9_RU                 				            { quality = 1; price = 20000; };
    class CUP_O_UAZ_AGS30_CSAT           				                { quality = 1; price = 20000; };
	class CUP_O_UAZ_MG_CSAT                        				        { quality = 1; price = 20000; };
	class CUP_O_UAZ_METIS_CSAT                  			            { quality = 1; price = 20000; };
	class CUP_O_UAZ_SPG9_CSAT          				                    { quality = 1; price = 20000; };
	class CUP_B_LR_Special_Des_CZ_D	              				        { quality = 1; price = 23000; };
	class CUP_B_LR_Special_GMG_GB_D			      				        { quality = 1; price = 23000; };
	class CUP_B_LR_Special_GMG_GB_W    				                    { quality = 1; price = 23000; };
	class CUP_B_LR_Special_M2_GB_D	              				        { quality = 1; price = 23000; };
	class CUP_B_LR_Special_M2_GB_W	        				            { quality = 1; price = 23000; };
    class CUP_B_LR_MG_GB_D	                      				        { quality = 1; price = 23000; };
	class CUP_B_LR_MG_GB_W	                   				            { quality = 1; price = 23000; };
	class CUP_I_LR_MG_AAF	                   				            { quality = 1; price = 23000; };	
	class CUP_I_LR_SF_GMG_AAF                                           { quality = 1; price = 23000; };	
	class CUP_I_LR_SF_HMG_AAF                                           { quality = 1; price = 23000; };
	class CUP_B_BAF_Coyote_GMG_D	           				            { quality = 1; price = 40000; };
	class CUP_B_BAF_Coyote_GMG_W	         				            { quality = 1; price = 40000; };
	class CUP_B_BAF_Coyote_L2A1_D			     				        { quality = 1; price = 40000; };
	class CUP_B_BAF_Coyote_L2A1_W			        				    { quality = 1; price = 40000; };
	class CUP_B_Jackal2_GMG_GB_D			       				        { quality = 1; price = 40000; };
	class CUP_B_Jackal2_GMG_GB_W	        				            { quality = 1; price = 40000; };
	class CUP_B_Jackal2_L2A1_GB_D			       				        { quality = 1; price = 40000; };
	class CUP_B_Jackal2_L2A1_GB_W	          				            { quality = 1; price = 40000; };
	class CUP_B_HMMWV_SOV_M2_USA			   				            { quality = 1; price = 25000; };
	class CUP_B_HMMWV_SOV_USA	               				            { quality = 1; price = 25000; };
	class CUP_B_HMMWV_SOV_M2_NATO_T               				        { quality = 1; price = 25000; };	
	class CUP_B_HMMWV_SOV_NATO_T                                        { quality = 1; price = 25000; };
	class CUP_B_HMMWV_AGS_GPK_ACR	                 				    { quality = 1; price = 30000; };
	class CUP_B_HMMWV_DSHKM_GPK_ACR	              				        { quality = 1; price = 30000; };
	class CUP_B_HMMWV_M2_GPK_ACR       				                    { quality = 1; price = 30000; };
	class CUP_B_HMMWV_M2_GPK_USA	          				            { quality = 1; price = 30000; };
    class CUP_B_M1151_M2_USA	               					        { quality = 1; price = 30000; };
    class CUP_B_M1151_Mk19_USA	    				                    { quality = 1; price = 30000; };
    class CUP_B_M1165_GMV_USA                      				        { quality = 1; price = 30000; };
    class CUP_B_M1167_USA	                   				            { quality = 1; price = 30000; };
	class CUP_B_HMMWV_M2_USMC	              				            { quality = 1; price = 30000; };
	class CUP_B_HMMWV_M1114_USMC	             				        { quality = 1; price = 30000; };
	class CUP_B_HMMWV_MK19_USMC	               				            { quality = 1; price = 30000; };
	class CUP_B_M1165_GMV_USMC                				            { quality = 1; price = 30000; };
	class CUP_B_M1167_USMC                         					    { quality = 1; price = 30000; };
	class CUP_B_M1151_M2_NATO_T              				            { quality = 1; price = 30000; };
	class CUP_B_M1151_Mk19_NATO_T               			            { quality = 1; price = 30000; };
	class CUP_B_M1165_GMV_NATO_T            				            { quality = 1; price = 30000; };
	class CUP_B_M1167_NATO_T                       				        { quality = 1; price = 30000; };
	class CUP_O_GAZ_Vodnik_PK_RU			       				        { quality = 3; price = 40000; };
	class CUP_O_GAZ_Vodnik_BPPU_RU                				        { quality = 4; price = 100000; }; 
	class CUP_O_GAZ_Vodnik_AGS_RU                    				    { quality = 3; price = 50000; };
	class CUP_B_Dingo_GER_Wdl 				      				        { quality = 3; price = 60000; };
	class CUP_B_Dingo_GL_CZ_Des               				            { quality = 3; price = 60000; };
	class CUP_B_Dingo_GL_CZ_Wdl               				            { quality = 3; price = 60000; };
	class CUP_B_Dingo_CZ_Des                      				        { quality = 3; price = 60000; };
	class CUP_B_Dingo_CZ_Wdl         				                    { quality = 3; price = 60000; };
	class CUP_B_Dingo_GL_GER_Des                                        { quality = 3; price = 60000; };
	class CUP_B_Dingo_GL_GER_Wdl         				                { quality = 3; price = 60000; };
	class CUP_B_Dingo_GER_Des                  				            { quality = 3; price = 60000; };	
	class CUP_B_RG31E_M2_USA                                            { quality = 3; price = 70000; };
	class CUP_B_RG31E_M2_OD_USMC              				            { quality = 3; price = 70000; };
	class CUP_B_Ridgback_GMG_GB_D	        			                { quality = 3; price = 70000; };
	class CUP_B_Ridgback_GMG_GB_W	        				            { quality = 3; price = 70000; };
    class CUP_B_Ridgback_HMG_GB_D	       				                { quality = 3; price = 70000; };
	class CUP_B_Ridgback_HMG_GB_W			  				            { quality = 3; price = 70000; };
	class CUP_B_Ridgback_LMG_GB_D	              				        { quality = 3; price = 70000; };
	class CUP_B_Ridgback_LMG_GB_W	                				    { quality = 3; price = 70000; };
	class CUP_B_Wolfhound_GMG_GB_D               				        { quality = 3; price = 75000; };
	class CUP_B_Wolfhound_GMG_GB_W              				        { quality = 3; price = 75000; };
	class CUP_B_Wolfhound_HMG_GB_D            				            { quality = 3; price = 75000; };
	class CUP_B_Wolfhound_HMG_GB_W               				        { quality = 3; price = 75000; };
	class CUP_B_Wolfhound_LMG_GB_D              				        { quality = 3; price = 75000; };
	class CUP_B_Wolfhound_LMG_GB_W              				        { quality = 3; price = 75000; };
	class CUP_B_Mastiff_GMG_GB_W         				                { quality = 3; price = 80000; };
    class CUP_B_Mastiff_HMG_GB_D                      				    { quality = 3; price = 80000; };
	class CUP_B_Mastiff_HMG_GB_W			       				        { quality = 3; price = 80000; };
	class CUP_B_Mastiff_LMG_GB_D                 				        { quality = 3; price = 80000; };
	class CUP_B_Mastiff_LMG_GB_W                  				        { quality = 3; price = 80000; };
    class CUP_B_Mastiff_GMG_GB_D           				                { quality = 3; price = 80000; };
    class CUP_B_Boxer_HMG_GER_WDL                                       { quality = 3; price = 1000000; sellPrice = 600000; };
/////////////////////////////////////////////////////CUP TRUCKS///////////////////////////////////////////

	class CUP_B_T810_Armed_CZ_DES			        				    { quality = 2; price = 40000; };
	class CUP_B_T810_Armed_CZ_WDL                                       { quality = 2; price = 40000; };
	class CUP_O_Kamaz_RU                          		                { quality = 1; price = 41000; };
	class CUP_O_Kamaz_Open_RU                      		                { quality = 1; price = 40000; };
	class CUP_I_Ural_UN	                      				            { quality = 1; price = 40000; };
	class CUP_O_Ural_RU	              				                    { quality = 1; price = 40000; };
	class CUP_O_Ural_SLA	                   				            { quality = 1; price = 40000; };
	class CUP_O_Ural_Open_RU	                    				    { quality = 1; price = 40000; };
	class CUP_B_MTVR_USMC                          				        { quality = 2; price = 45000; };
	class CUP_B_MTVR_USA                      				            { quality = 2; price = 45000; };
    class CUP_O_Ural_Reammo_SLA                       				    { quality = 1; price = 55000; };
	class CUP_O_Ural_Refuel_SLA	           					            { quality = 1; price = 55000; };
	class CUP_O_Ural_Repair_SLA	                  				        { quality = 1; price = 55000; };
	class CUP_O_Kamaz_Reammo_RU                          	            { quality = 1; price = 55000; };
	class CUP_O_Kamaz_Refuel_RU                               		    { quality = 1; price = 55000; };
	class CUP_O_Kamaz_Repair_RU                             	        { quality = 1; price = 55000; };
    class CUP_O_Ural_Reammo_RU                    				        { quality = 1; price = 55000; };
	class CUP_O_Ural_Refuel_RU	               				            { quality = 1; price = 55000; };
	class CUP_O_Ural_Repair_RU	             				            { quality = 1; price = 55000; };
	class CUP_I_Ural_Repair_UN	    				                    { quality = 1; price = 55000; };
    class CUP_I_Ural_Reammo_UN                     				        { quality = 1; price = 55000; };   
	class CUP_B_T810_Reammo_CZ_WDL                                      { quality = 2; price = 60000; };
	class CUP_B_T810_Reammo_CZ_DES			        				    { quality = 2; price = 60000; };	
	class CUP_B_T810_Refuel_CZ_DES                                      { quality = 2; price = 60000; };	
	class CUP_B_T810_Refuel_CZ_WDL                                      { quality = 2; price = 60000; };	
	class CUP_B_T810_Repair_CZ_DES                                      { quality = 2; price = 60000; };	
	class CUP_B_T810_Repair_CZ_WDL                                      { quality = 2; price = 60000; };
	class CUP_B_MTVR_Ammo_USA                        				    { quality = 2; price = 70000; };
	class CUP_B_MTVR_Refuel_USA                     				    { quality = 2; price = 70000; };
	class CUP_B_MTVR_Repair_USA            				                { quality = 2; price = 70000; };
	class CUP_B_MTVR_Ammo_USMC                				            { quality = 2; price = 70000; };
	class CUP_B_MTVR_Refuel_USMC            				            { quality = 2; price = 70000; };
	class CUP_B_MTVR_Repair_USMC                   				        { quality = 2; price = 70000; };
	
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////CUP APC///////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////CUP NATO APC///////////////////////////////////////////////////////

	class CUP_B_M113_desert_USA									        { quality = 3; price = 110000; };
	class CUP_B_M113_USA                                  	            { quality = 3; price = 110000; };
	class CUP_I_M113_UN			                   				        { quality = 3; price = 110000; };	
	class CUP_I_M113_AAF                                           	    { quality = 3; price = 110000; };
	class CUP_B_M163_USA               				                    { quality = 4; price = 160000; };
	class CUP_I_M163_AAF                         				        { quality = 4; price = 160000; };
	class CUP_B_FV432_Bulldog_GB_D           				            { quality = 3; price = 150000; }; 
    class CUP_B_FV432_Bulldog_GB_W              				        { quality = 3; price = 150000; };
	class CUP_B_FV432_Bulldog_GB_W_RWS		          				    { quality = 3; price = 165000; };
	class CUP_B_FV432_Bulldog_GB_D_RWS              				    { quality = 3; price = 165000; };
	class CUP_B_M1130_CV_M2_Woodland              				        { quality = 4; price = 190000; };
	class CUP_B_M1130_CV_M2_Desert                 				        { quality = 4; price = 190000; };
	class CUP_B_M1126_ICV_MK19_Woodland        				            { quality = 4; price = 170000; };
	class CUP_B_M1126_ICV_MK19_Desert             				        { quality = 4; price = 170000; };
	class CUP_B_M1126_ICV_MK19_Desert_Slat          				    { quality = 4; price = 180000; };
	class CUP_B_M1126_ICV_MK19_Woodland_Slat          				    { quality = 4; price = 180000; };
	class CUP_B_M1130_CV_M2_Desert_Slat              				    { quality = 4; price = 200000; };
	class CUP_B_M1130_CV_M2_Woodland_Slat      				            { quality = 4; price = 200000; };
	class CUP_B_AAV_USMC												{ quality = 4; price = 100000; };
	class CUP_B_LAV25M240_USMC				         				    { quality = 6; price = 250000; };
	class CUP_B_LAV25M240_desert_USMC          				            { quality = 6; price = 250000; };
	class CUP_B_LAV25M240_green                                         { quality = 6; price = 250000; };
    class CUP_B_FV510_GB_D                   				            { quality = 4; price = 220000; };
    class CUP_B_FV510_GB_W                       				        { quality = 4; price = 220000; };
    class CUP_B_MCV80_GB_D	                			                { quality = 4; price = 250000; };
    class CUP_B_MCV80_GB_W	                     				        { quality = 4; price = 250000; };
    class CUP_B_MCV80_GB_D_SLAT	              				            { quality = 5; price = 400000; }; 
    class CUP_B_MCV80_GB_W_SLAT	                  				        { quality = 5; price = 400000; };
    class CUP_B_FV510_GB_D_SLAT                 				        { quality = 5; price = 300000; }; 
    class CUP_B_FV510_GB_W_SLAT              				            { quality = 5; price = 300000; };
	class CUP_B_M7Bradley_USA_D                				            { quality = 6; price = 350000; };
	class CUP_B_M7Bradley_USA_W                    				        { quality = 6; price = 350000; };
	class CUP_B_M2Bradley_NATO_T        				                { quality = 6; price = 450000; };
	class CUP_B_M2Bradley_USA_D                     				    { quality = 6; price = 450000; };
	class CUP_B_M2Bradley_USA_W                   				        { quality = 6; price = 450000; };
	class CUP_B_M2A3Bradley_NATO_T            				            { quality = 6; price = 500000; };
	class CUP_B_M2A3Bradley_USA_D                				        { quality = 6; price = 500000; };
	class CUP_B_M2A3Bradley_USA_W                     				    { quality = 6; price = 500000; };
	class CUP_B_M6LineBacker_USA_D               				        { quality = 6; price = 470000; };
	class CUP_B_M6LineBacker_USA_W                 				        { quality = 6; price = 470000; };
	class CUP_B_M6LineBacker_NATO_T 	           				        { quality = 6; price = 470000; };
	class CUP_B_M1128_MGS_Desert            				            { quality = 6; price = 550000; };
	class CUP_B_M1128_MGS_Woodland                				        { quality = 6; price = 550000; };
	class CUP_B_M1128_MGS_Desert_Slat             				        { quality = 6; price = 600000; };
	class CUP_B_M1128_MGS_Woodland_Slat            				        { quality = 6; price = 600000; };
	class CUP_I_FENNEK_GMG_ION                                          { quality = 6; price = 400000; };
	class CUP_I_FENNEK_HMG_ION                                          { quality = 6; price = 400000; };  
	class CUP_I_Hilux_armored_podnos_TK                                 { quality = 6; price = 1200000; };
/////////////////////////////////////////////////////CUP Russian APC///////////////////////////////////////
	
	class CUP_B_MTLB_pk_FIA                                             { quality = 1; price = 85000; };	
	class CUP_O_MTLB_pk_SLA                                             { quality = 1; price = 85000; };
	class CUP_O_MTLB_pk_WDL_RU          							    { quality = 1; price = 85000; };	
	class CUP_O_MTLB_pk_Green_RU                                        { quality = 1; price = 85000; };	
	class CUP_O_MTLB_pk_Winter_RU                                       { quality = 1; price = 85000; };	
	class CUP_I_MTLB_pk_NAPA                                            { quality = 1; price = 85000; };	
	class CUP_I_MTLB_pk_UN                                              { quality = 1; price = 85000; };
	class CUP_O_BRDM2_SLA	            	     				        { quality = 2; price = 120000; };	
	class CUP_O_BRDM2_RUS                                          	    { quality = 2; price = 120000; };	
	class CUP_O_BRDM2_CSAT                                              { quality = 2; price = 120000; };	
	class CUP_O_BRDM2_CSAT_T                                            { quality = 2; price = 120000; };
	class CUP_I_BRDM2_TK_Gue	                   				        { quality = 2; price = 120000; };
	class CUP_I_BRDM2_UN	            	          				    { quality = 2; price = 120000; };	
	class CUP_O_BRDM2_ATGM_SLA                                          { quality = 3; price = 150000; };	
	class CUP_O_BRDM2_ATGM_RUS                                          { quality = 3; price = 150000; };	
	class CUP_O_BRDM2_ATGM_CSAT                                         { quality = 3; price = 150000; };	
	class CUP_O_BRDM2_ATGM_CSAT_T                                       { quality = 3; price = 150000; };	
	class CUP_I_BRDM2_ATGM_TK_Gue                                       { quality = 3; price = 150000; };
	class CUP_B_BTR60_FIA                            				    { quality = 3; price = 200000; };
	class CUP_O_BTR60_SLA                          				        { quality = 3; price = 200000; };
	class CUP_O_BTR60_CSAT                                              { quality = 3; price = 200000; };
	class CUP_O_BTR60_RU                             				    { quality = 3; price = 200000; };
	class CUP_O_BTR60_Green_RU                     				        { quality = 3; price = 200000; };
	class CUP_O_BTR60_Winter_RU                      				    { quality = 3; price = 200000; };
	class CUP_I_BTR60_UN                    				            { quality = 3; price = 200000; };
	class CUP_O_BMP2_ZU_CSAT                  				            { quality = 3; price = 250000; };
	class CUP_O_BMP2_ZU_CSAT_T                     				        { quality = 3; price = 250000; };
	class CUP_O_ZSU23_CSAT                         				        { quality = 4; price = 350000; };
	class CUP_O_ZSU23_SLA                           				    { quality = 4; price = 350000; };
	class CUP_I_ZSU23_AAF                            				    { quality = 4; price = 350000; };
	class CUP_O_BMP1_CSAT                          				        { quality = 3; price = 370000; };
	class CUP_O_BMP1P_CSAT                          				    { quality = 3; price = 370000; };
	class CUP_O_BMP1_CSAT_T                         				    { quality = 3; price = 370000; };
	class CUP_O_BMP1P_CSAT_T                         				    { quality = 3; price = 370000; };
	class CUP_I_BMP1_TK_GUE                          				    { quality = 3; price = 370000; };
	class CUP_O_BMP2_SLA                     				            { quality = 3; price = 400000; };
	class CUP_O_BMP2_RU                        				            { quality = 3; price = 400000; };
	class CUP_O_BMP2_CSAT              				                    { quality = 3; price = 400000; };
	class CUP_O_BMP2_CSAT_T                       				        { quality = 3; price = 400000; };
	class CUP_I_BMP2_NAPA                          				        { quality = 3; price = 400000; };
	class CUP_I_BMP2_UN                                 				{ quality = 3; price = 400000; };
	class CUP_O_BTR90_RU					       				        { quality = 4; price = 500000; };
	class CUP_O_2S6_RU									 				{ quality = 5; price = 650000; }; //тунгуска
	class CUP_O_2S6M_RU                							        { quality = 5; price = 680000; }; //тунгуска
	class CUP_O_BMP3_RU													{ quality = 6; price = 700000; };
	class CUP_O_BMP3_CSAT_T               							    { quality = 6; price = 700000; };	
	
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////CUP TANKs//////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	class CUP_I_T34_TK_GUE                    				            { quality = 3; price = 400000; };
	class CUP_O_T55_SLA                          				        { quality = 4; price = 600000; };
	class CUP_O_T55_CSAT                          				        { quality = 4; price = 600000; }; 
	class CUP_O_T55_CSAT_T                         				        { quality = 4; price = 600000; };
	class CUP_I_T55_TK_GUE                  			                { quality = 4; price = 600000; };
	class CUP_I_T55_NAPA                	                            { quality = 4; price = 600000; };
	class CUP_O_T72_SLA	                           				        { quality = 5; price = 700000; };
	class CUP_O_T72_CSAT                           				        { quality = 5; price = 700000; };
	class CUP_O_T72_CSAT_T                            				    { quality = 5; price = 700000; };
	class CUP_O_T72_RU                          				        { quality = 5; price = 700000; };
	class CUP_O_T90_RU						        				    { quality = 6; price = 1000000; };
	class CUP_B_Challenger2_Desert_BAF									{ quality = 7; price = 1100000; };
	class CUP_B_Challenger2_Snow_BAF    							    { quality = 7; price = 1100000; };
	class CUP_B_Challenger2_2CW_BAF										{ quality = 7; price = 1100000; };
	class CUP_B_Challenger2_Woodland_BAF								{ quality = 7; price = 1100000; };
	class CUP_B_Challenger2_NATO										{ quality = 7; price = 1100000; };
	class CUP_B_Challenger2_Sand_CTRG									{ quality = 7; price = 1100000; };
	class CUP_B_Challenger2_Green_CTRG									{ quality = 7; price = 1100000; };
	class CUP_B_Leopard2A6_GER                            		        { quality = 7; price = 1200000; };
	class CUP_B_M1A1_DES_US_Army        							    { quality = 7; price = 1300000; };
	class CUP_B_M1A1_Woodland_US_Army									{ quality = 7; price = 1300000; };
	class CUP_B_M1A1_NATO_T                							    { quality = 7; price = 1300000; };
	class CUP_B_M1A2_TUSK_MG_US_Army       							    { quality = 7; price = 1400000; };
	class CUP_B_M1A2_TUSK_MG_DES_US_Army   							    { quality = 7; price = 1400000; };
	class CUP_B_M1A2_TUSK_MG_USMC          							    { quality = 7; price = 1400000; };
	class CUP_B_M1A2_TUSK_MG_DES_USMC       							{ quality = 7; price = 1400000; };
	
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////CUP HELIs/////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	class CUP_B_MH6J_USA                                                { quality = 2; price = 500000; };	
	class CUP_B_AH6M_USA                                          	    { quality = 2; price = 700000; };	
	class CUP_B_Merlin_HC3_VIV_GB                                       { quality = 3; price = 800000; };	
	class CUP_B_CH47F_VIV_USA                                           { quality = 3; price = 850000; };
	class CUP_I_CH47F_VIV_RACS                                          { quality = 3; price = 850000; };	
	class CUP_O_MI6A_RU                                     	        { quality = 3; price = 1000000; };
	class CUP_C_MI6A_RU                                        		    { quality = 3; price = 1000000; };
	class CUP_O_MI6A_CSAT_T                                             { quality = 3; price = 1000000; };	
	class CUP_I_MI6A_UN                                                 { quality = 3; price = 1000000; };	
	class CUP_B_CH53E_VIV_GER                        				    { quality = 3; price = 1200000; };	
	class CUP_B_CH53E_VIV_USMC                                          { quality = 3; price = 1200000; };
	class CUP_B_UH60M_US	                         				    { quality = 2; price = 1900000; };	
	class CUP_B_UH60S_USN                                          	    { quality = 2; price = 1900000; };	
	class CUP_B_UH1D_armed_GER_KSK                                      { quality = 3; price = 2000000; };	
	class CUP_B_UH1D_armed_GER_KSK_Des                                  { quality = 3; price = 2000000; };	
	class CUP_B_UH1D_gunship_GER_KSK_Des                                { quality = 3; price = 2500000; };	
	class CUP_B_UH1D_gunship_GER_KSK                                    { quality = 3; price = 2500000; };	
	class CUP_B_UH1Y_Gunship_Dynamic_USMC                               { quality = 3; price = 2000000; };	
	class CUP_O_Ka60_Grey_RU                                            { quality = 3; price = 2500000; };	
	class CUP_O_Ka60_Hex_CSAT                                           { quality = 3; price = 2500000; };	
	class CUP_O_Ka60_Whale_CSAT                                         { quality = 3; price = 2500000; };
	class CUP_I_Ka60_Digi_AAF                                           { quality = 3; price = 2500000; };	
	class CUP_I_Ka60_GL_Digi_AAF                                        { quality = 3; price = 2500000; };	
	class CUP_O_Mi8_RU                                           	    { quality = 3; price = 2600000; };		
	class CUP_B_MH60L_DAP_2x_US                                         { quality = 4; price = 2700000; };	
	class CUP_B_MH60L_DAP_2x_USN                                        { quality = 4; price = 2700000; };
	class CUP_B_MH60L_DAP_4x_USN			        				    { quality = 5; price = 2900000; };	
	class CUP_B_MH60L_DAP_4x_US                                         { quality = 5; price = 2900000; };	
	class CUP_B_AW159_GB                                         	    { quality = 5; price = 2900000; };
	class CUP_I_Wildcat_Green_AAF                           	        { quality = 5; price = 2900000; };
	class CUP_I_Wildcat_Digital_AAF                                     { quality = 5; price = 2900000; };		
	class CUP_O_Mi24_V_Dynamic_RU                                       { quality = 5; price = 3000000; };	
	class CUP_O_Mi24_P_Dynamic_RU                                       { quality = 5; price = 3000000; };
	class CUP_O_Mi24_V_Dynamic_CSAT_T                                   { quality = 5; price = 3000000; };	
	class CUP_O_Mi24_D_Dynamic_CSAT_T                                   { quality = 5; price = 3000000; };	
	class CUP_O_Mi24_P_Dynamic_CSAT_T                                   { quality = 5; price = 3000000; };	
	class CUP_I_Mi24_D_Dynamic_UN                                       { quality = 5; price = 3000000; };	
	class CUP_I_Mi24_D_Dynamic_AAF                                      { quality = 5; price = 3000000; };	
	class CUP_O_Mi24_Mk3_CSAT_T								            { quality = 6; price = 3500000; };
	class CUP_I_Mi24_Mk3_UN					      				        { quality = 6; price = 3500000; };
	class CUP_I_Mi24_Mk3_AAF				   				            { quality = 6; price = 3500000; };
	class CUP_I_Mi24_Mk3_FAB_AAF			          				    { quality = 6; price = 3500000; };
	class CUP_I_Mi24_Mk3_AT_AAF								            { quality = 6; price = 3500000; };
	class CUP_I_Mi24_Mk3_S8_GSh_AAF			      				        { quality = 6; price = 3500000; };
	class CUP_O_Mi24_Mk3_S8_GSh_CSAT_T		       				        { quality = 6; price = 3500000; };
	class CUP_O_Mi24_Mk3_AT_CSAT_T			         				    { quality = 6; price = 3500000; };
	class CUP_O_Mi24_Mk3_FAB_CSAT_T			 				            { quality = 6; price = 3500000; };
	class CUP_I_Mi24_Mk3_AT_UN				     				        { quality = 6; price = 3500000; };
	class CUP_I_Mi24_Mk3_FAB_UN				   				            { quality = 6; price = 3500000; };
	class CUP_I_Mi24_Mk3_S8_GSh_UN			     				        { quality = 6; price = 3500000; };
	class CUP_O_Mi24_Mk4_CSAT_T				        				    { quality = 6; price = 4000000; };
	class CUP_I_Mi24_Mk4_UN					         				    { quality = 6; price = 4000000; };
	class CUP_I_Mi24_Mk4_AAF				      				        { quality = 6; price = 4000000; };
	class CUP_I_Mi24_Mk4_AT_AAF				       				        { quality = 6; price = 4000000; };
	class CUP_I_Mi24_Mk4_FAB_AAF			          				    { quality = 6; price = 4000000; };
	class CUP_I_Mi24_Mk4_S8_GSh_AAF			          				    { quality = 6; price = 4000000; };
	class CUP_O_Mi24_Mk4_AT_CSAT_T			       				        { quality = 6; price = 4000000; };
	class CUP_O_Mi24_Mk4_FAB_CSAT_T			           				    { quality = 6; price = 4000000; };
	class CUP_O_Mi24_Mk4_S8_GSh_CSAT_T		       				        { quality = 6; price = 4000000; };
	class CUP_I_Mi24_Mk4_AT_UN				         				    { quality = 6; price = 4000000; };
	class CUP_I_Mi24_Mk4_FAB_UN				         				    { quality = 6; price = 4000000; };
	class CUP_I_Mi24_Mk4_S8_GSh_UN			          				    { quality = 6; price = 4000000; };
	class CUP_I_AH1Z_Dynamic_AAF                        	            { quality = 6; price = 4500000; };
	class CUP_B_AH1Z_Dynamic_USMC                                       { quality = 6; price = 4500000; };	
	class CUP_O_Ka50_DL_RU                                              { quality = 7; price = 4200000; };	
	class CUP_O_Ka50_DL_SLA                                             { quality = 7; price = 4200000; };	
	class CUP_O_Ka50_SLA								                { quality = 7; price = 4500000; };
	class CUP_O_Ka52_RU						      				        { quality = 7; price = 4700000; };
	class CUP_O_Ka52_Blk_RU					      				        { quality = 7; price = 4700000; };
	class CUP_O_Ka52_GreyCamo_RU			          				    { quality = 7; price = 4700000; };
	class CUP_O_Ka52_Grey_RU				        				    { quality = 7; price = 4700000; };
	class CUP_B_AH64_DL_USA                                             { quality = 6; price = 4900000; };	
	class CUP_B_AH64D_DL_USA                                            { quality = 6; price = 5000000; };
	class CUP_B_AH64D_ES_USA                                            { quality = 6; price = 5000000; };

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////CUP JETs////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	class CUP_B_C130J_USMC                     					        { quality = 2; price = 600000; };
	class CUP_B_C130J_Cargo_USMC                				        { quality = 2; price = 600000; };
	class CUP_I_L39_AAF                                   	            { quality = 4; price = 2000000; };	
	class CUP_O_Su25_Dyn_RU                                             { quality = 5; price = 4000000; };
	class CUP_B_Su25_CDF                              				    { quality = 5; price = 4000000; };
	class CUP_O_Su25_TKA                            				    { quality = 5; price = 4000000; };
	class CUP_O_Su25_SLA                           				        { quality = 5; price = 4000000; };
	class CUP_O_Su25_RU_1                          				        { quality = 5; price = 4000000; };
	class CUP_O_Su25_RU_2                          					    { quality = 5; price = 4000000; };
	class CUP_O_Su25_RU_3                      				            { quality = 5; price = 4000000; };
	class CUP_B_A10_DYN_USA                                             { quality = 5; price = 5000000; };
	class CUP_B_A10_CAS_USA                           				    { quality = 5; price = 5000000; };
	class CUP_B_A10_AT_USA												{ quality = 5; price = 5000000; };	
	class CUP_B_GR9_DYN_GB                                              { quality = 7; price = 5500000; };
	class CUP_B_GR9_CAP_GB                            				    { quality = 7; price = 5500000; };
	class CUP_B_GR9_Mk82_GB                          				    { quality = 7; price = 5500000; };
	class CUP_B_GR9_GBU12_GB                         				    { quality = 7; price = 5500000; };
	class CUP_B_GR9_AGM_GB                           				    { quality = 7; price = 5500000; };
	class CUP_B_AV8B_DYN_USMC                                           { quality = 7; price = 5500000; };	
	class CUP_I_AV8B_DYN_AAF                                            { quality = 7; price = 5500000; };
	class CUP_B_AV8B_CAP_USMC                     				        { quality = 7; price = 5500000; };
	class CUP_I_AV8B_CAP_AAF                          				    { quality = 7; price = 5500000; };
	class CUP_B_AV8B_MK82_USMC                       				    { quality = 7; price = 5500000; };
	class CUP_I_AV8B_MK82_AAF                         				    { quality = 7; price = 5500000; };
	class CUP_B_AV8B_GBU12_USMC                      				    { quality = 7; price = 5500000; };
	class CUP_I_AV8B_GBU12_AAF                       				    { quality = 7; price = 5500000; };
	class CUP_B_AV8B_AGM_USMC                       				    { quality = 7; price = 5500000; };
	class CUP_I_AV8B_AGM_AAF                          				    { quality = 7; price = 5500000; };	
	class CUP_B_SU34_CDF                                       	        { quality = 7; price = 5600000; };	
	class CUP_O_SU34_RU                                           	    { quality = 7; price = 5600000; };	
	class CUP_I_SU34_AAF                                          	    { quality = 7; price = 5600000; };
	class CUP_O_SU34_LGB_RU                          				    { quality = 7; price = 5600000; };
	class CUP_O_SU34_AGM_RU                          				    { quality = 7; price = 5600000; };
	class CUP_O_SU34_LGB_SLA                         				    { quality = 7; price = 5600000; };
	class CUP_O_SU34_AGM_SLA                          				    { quality = 7; price = 5600000; };
	class CUP_I_SU34_LGB_AAF                         				    { quality = 7; price = 5600000; };
	class CUP_I_SU34_AGM_AAF                           				    { quality = 7; price = 5600000; };
	class CUP_B_SU34_LGB_CDF                          				    { quality = 7; price = 5600000; };
	class CUP_B_SU34_AGM_CDF                         				    { quality = 7; price = 5600000; };	
	class CUP_B_F35B_BAF                                           	    { quality = 7; price = 6000000; };	
	class CUP_B_F35B_Stealth_BAF                                        { quality = 7; price = 6000000; };
	class CUP_B_F35B_AA_USMC                           				    { quality = 7; price = 6000000; };
	class CUP_B_F35B_CAS_USMC                        				    { quality = 7; price = 6000000; };
	class CUP_B_F35B_LGB_USMC                        				    { quality = 7; price = 6000000; };
	class CUP_B_F35B_AA_BAF                           				    { quality = 7; price = 6000000; };
	class CUP_B_F35B_CAS_BAF                          				    { quality = 7; price = 6000000; };
	class CUP_B_F35B_LGB_BAF                          				    { quality = 7; price = 6000000; };

///////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////CUP UAVs & USVs///////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////

	class CUP_B_AH6X_USA                                             	{ quality = 3; price = 100000; };	
	class CUP_B_USMC_DYN_MQ9                                            { quality = 3; price = 100000; };
	class CUP_B_USMC_MQ9				        	 				    { quality = 3; price = 100000; };
	class CUP_B_Seafox_USV_USMC                      				    { quality = 3; price = 10000; };	
	class CUP_B_Pchela1T_CDF                                            { quality = 3; price = 10000; };	
	class CUP_O_Pchela1T_RU                                             { quality = 3; price = 10000; };

///////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////RHS CARs & TRUCKs///////////////////////////////////////////	
///////////////////////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////RHS Russian TRUCKs & CARs////////////////////////////////////

	class rhs_gaz66_vdv                                           	    { quality = 2; price = 18250; };
	class rhs_gaz66_flat_vdv 											{ quality = 2; price = 18250; };
	class rhs_gaz66o_vdv 												{ quality = 2; price = 18250; };
	class rhs_gaz66o_flat_vdv 											{ quality = 2; price = 18250; };
	class RHS_Ural_VDV_01												{ quality = 2; price = 30000; };
	class RHS_Ural_Open_VDV_01											{ quality = 2; price = 30000; };	
	class rhs_kamaz5350_vdv                                             { quality = 2; price = 30000; };	
	class rhs_kamaz5350_open_vdv                                        { quality = 2; price = 30000; };	
	class rhs_zil131_vdv                                                { quality = 2; price = 30000; };	
	class rhs_zil131_open_vdv                                           { quality = 2; price = 30000; };	
	class rhs_gaz66_zu23_vdv                                            { quality = 2; price = 40000; };
	class rhs_gaz66_r142_vdv											{ quality = 2; price = 40000; };	
	class rhs_gaz66_ammo_vdv                                            { quality = 2; price = 40000; };	
	class rhs_gaz66_ap2_vdv                                             { quality = 2; price = 40000; };
	class rhs_gaz66_repair_vdv											{ quality = 2; price = 40000; };
	class RHS_Ural_Fuel_VDV_01											{ quality = 2; price = 45000; };	
	class RHS_Ural_Zu23_VDV_01                                          { quality = 3; price = 50000; };	
	class RHS_Ural_Repair_VDV_01                                        { quality = 2; price = 45000; };
	class rhs_typhoon_vdv												{ quality = 3; price = 60000; };	
	class rhs_tigr_m_vdv                                                { quality = 3; price = 70000; };	
	class rhs_tigr_m_3camo_vdv                                          { quality = 3; price = 70000; };
	class rhs_tigr_ffv_3camo_vdv										{ quality = 3; price = 90000; };
	class rhs_tigr_3camo_vdv											{ quality = 3; price = 90000; };
	class rhs_tigr_ffv_vdv												{ quality = 3; price = 90000; };
	class rhs_tigr_vdv													{ quality = 3; price = 90000; };
	class rhs_tigr_sts_3camo_vdv										{ quality = 3; price = 90000; };
	class rhs_tigr_sts_vdv                                              { quality = 3; price = 90000; };

////////////////////////////////////////////RHS NATO TRUCKs & CARs//////////////////////////////////////////
	
	class rhsusf_M1078A1R_SOV_M2_D_fmtv_socom                           { quality = 1; price = 20000; };	
	class rhsusf_M1084A1R_SOV_M2_D_fmtv_socom                           { quality = 1; price = 20000; };
	class rhsusf_M1078A1P2_B_WD_CP_fmtv_usarmy                          { quality = 1; price = 25000; };	
	class rhsusf_M1078A1P2_B_D_CP_fmtv_usarmy                           { quality = 1; price = 25000; };	
	class rhsusf_M1078A1P2_B_M2_WD_flatbed_fmtv_usarmy                  { quality = 1; price = 25000; };	
	class rhsusf_M1083A1P2_B_M2_WD_flatbed_fmtv_usarmy                	{ quality = 1; price = 25000; };	
	class rhsusf_M1078A1P2_B_M2_D_flatbed_fmtv_usarmy                   { quality = 1; price = 25000; };	
	class rhsusf_M1083A1P2_B_M2_D_flatbed_fmtv_usarmy                   { quality = 1; price = 25000; };
	class rhsusf_M1083A1P2_B_M2_wd_fmtv_usarmy							{ quality = 1; price = 25000; };	
	class rhsusf_M1078A1P2_B_M2_WD_fmtv_usarmy                          { quality = 1; price = 25000; };	
	class rhsusf_M1078A1P2_B_M2_D_fmtv_usarmy                           { quality = 1; price = 25000; };	
	class rhsusf_M1083A1P2_B_M2_D_fmtv_usarmy                           { quality = 1; price = 25000; };	
	class rhsusf_M977A4_BKIT_M2_usarmy_wd           					{ quality = 1; price = 30000; };
	class rhsusf_M977A4_BKIT_M2_usarmy_d            					{ quality = 1; price = 30000; };
	class rhsusf_M1084A1P2_B_M2_D_fmtv_usarmy                           { quality = 1; price = 30000; };	
	class rhsusf_M1084A1P2_B_M2_WD_fmtv_usarmy                          { quality = 1; price = 30000; };
	class rhsusf_M977A4_AMMO_BKIT_M2_usarmy_wd      					{ quality = 2; price = 50000; };
	class rhsusf_M1085A1P2_B_WD_Medical_fmtv_usarmy                     { quality = 2; price = 50000; };
	class rhsusf_M977A4_REPAIR_BKIT_M2_usarmy_wd						{ quality = 2; price = 50000; };
	class rhsusf_M978A4_usarmy_wd                                       { quality = 2; price = 50000; };		
	class rhsusf_M1085A1P2_B_D_Medical_fmtv_usarmy                      { quality = 2; price = 50000; };
	class rhsusf_M977A4_AMMO_BKIT_M2_usarmy_d       					{ quality = 2; price = 50000; };
	class rhsusf_M977A4_REPAIR_BKIT_M2_usarmy_d                         { quality = 2; price = 50000; };
	class rhsusf_M978A4_BKIT_usarmy_d               					{ quality = 2; price = 50000; };	
	class rhsusf_m1043_d_m2                               	      		{ quality = 1; price = 60000; };
	class rhsusf_m1043_d_mk19                            	     	    { quality = 1; price = 60000; };	
	class rhsusf_m966_d                                             	{ quality = 1; price = 60000; };	
	class rhsusf_m1043_w_m2                                             { quality = 1; price = 60000; };	
	class rhsusf_m1043_w_mk19                                           { quality = 1; price = 60000; };	
	class rhsusf_m1045_w                                             	{ quality = 1; price = 60000; };
    class rhsusf_CGRCAT1A2_M2_usmc_d                					{ quality = 3; price = 70000; }; 
	class rhsusf_CGRCAT1A2_M2_usmc_wd                                   { quality = 3; price = 70000; };	
	class rhsusf_CGRCAT1A2_Mk19_usmc_wd                                 { quality = 3; price = 70000; };	
	class rhsusf_CGRCAT1A2_Mk19_usmc_d                                  { quality = 3; price = 70000; };
    class rhsusf_M1220_M153_M2_usarmy_wd	        					{ quality = 3; price = 80000; };	
	class classrhsusf_M1220_M2_usarmy_wdname                            { quality = 3; price = 80000; };	
	class rhsusf_M1220_M2_usarmy_wd                            			{ quality = 3; price = 80000; };	
	class rhsusf_M1220_M153_MK19_usarmy_wd                              { quality = 3; price = 80000; };	
	class rhsusf_M1220_MK19_usarmy_wd                                   { quality = 3; price = 80000; };
	class rhsusf_M1220_M153_M2_usarmy_d                           		{ quality = 3; price = 80000; };
	class rhsusf_M1220_M2_usarmy_d										{ quality = 3; price = 80000; };
	class rhsusf_M1220_MK19_usarmy_d                              		{ quality = 3; price = 80000; };	
	class rhsusf_M1230_M2_usarmy_wd                                     { quality = 3; price = 90000; };	
	class rhsusf_M1230_MK19_usarmy_wd                                  	{ quality = 3; price = 90000; };
	class rhsusf_M1230_M2_usarmy_d                                		{ quality = 3; price = 90000; };
	class rhsusf_M1230_MK19_usarmy_d                              		{ quality = 3; price = 90000; };
	class rhsusf_M1232_M2_usarmy_wd       		    					{ quality = 4; price = 100000; };
	class rhsusf_M1232_MK19_usarmy_wd     		    					{ quality = 4; price = 100000; };
	class rhsusf_M1232_M2_usarmy_d        		    					{ quality = 4; price = 100000; };
	class rhsusf_M1232_MK19_usarmy_d      		    					{ quality = 4; price = 100000; };	
	class rhsusf_M1232_MC_M2_usmc_wd                                    { quality = 4; price = 100000; };	
	class rhsusf_M1232_MC_MK19_usmc_wd                                  { quality = 4; price = 100000; };	
	class rhsusf_M1232_MC_M2_usmc_d                                    	{ quality = 4; price = 100000; };	
	class rhsusf_M1232_MC_MK19_usmc_d                                   { quality = 4; price = 100000; };
	class rhsusf_M1237_M2_usarmy_wd       		    					{ quality = 4; price = 100000; };
	class rhsusf_M1237_MK19_usarmy_wd	  		    					{ quality = 4; price = 100000; };
	class rhsusf_M1237_M2_usarmy_d        		    					{ quality = 4; price = 100000; };
	class rhsusf_M1237_MK19_usarmy_d      		    					{ quality = 4; price = 100000; };	
	class rhsusf_M1238A1_M2_socom_d                                     { quality = 3; price = 110000; };	
	class rhsusf_M1238A1_Mk19_socom_d                                   { quality = 3; price = 110000; };	
	class rhsusf_M1239_M2_socom_d                                       { quality = 3; price = 120000; };	
	class rhsusf_M1239_MK19_socom_d                                     { quality = 3; price = 120000; };	
	class rhsusf_M1239_M2_Deploy_socom_d                                { quality = 3; price = 120000; };	
	class rhsusf_M1239_MK19_Deploy_socom_d                              { quality = 3; price = 120000; };
	class CUP_I_Van_Cargo_ION            				                { quality = 3; price = 120000; };
	class CUP_I_MATV_HMG_ION            				                { quality = 3; price = 120000; };
	class CUP_I_LSV_02_Minigun_ION           				            { quality = 3; price = 120000; };
	
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////RHS APC////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	class rhsusf_m113_usarmy_MK19                                       { quality = 4; price = 150000; };	
	class rhsusf_m113_usarmy                                            { quality = 4; price = 150000; };
	class rhsusf_m113_usarmy_M240   									{ quality = 4; price = 150000; };	
	class rhsusf_m113_usarmy_supply                                     { quality = 4; price = 150000; };	
	class rhsusf_m113_usarmy_M2_90                                      { quality = 4; price = 150000; };	
	class rhsusf_m113_usarmy_MK19_90                                    { quality = 4; price = 150000; };	
	class rhsusf_m113d_usarmy_MK19                                      { quality = 4; price = 150000; };	
	class rhsusf_m113d_usarmy                                           { quality = 4; price = 150000; };	
	class rhsusf_m113d_usarmy_M240                                      { quality = 4; price = 150000; };	
	class rhsusf_m113d_usarmy_supply                                    { quality = 4; price = 150000; };
	class rhs_btr60_vmf 												{ quality = 2; price = 170000; };
	class rhs_btr60_vdv 												{ quality = 2; price = 170000; };
	class rhs_btr60_vv 													{ quality = 2; price = 170000; };
	class rhs_btr60_msv 												{ quality = 2; price = 170000; };
	class RHS_BTR70_VDV 												{ quality = 2; price = 190000; };	
	class RHS_BTR70_MSV 												{ quality = 2; price = 190000; };
	class RHS_BTR70_VMF 												{ quality = 2; price = 190000; };
	class RHS_BTR70_VV 							    					{ quality = 2; price = 190000; };
	class RHS_BTR80_MSV 												{ quality = 3; price = 200000; };
	class RHS_BTR80_VV													{ quality = 3; price = 200000; };
	class RHS_BTR80_VDV 												{ quality = 3; price = 200000; };
	class RHS_BTR80_VMF 												{ quality = 3; price = 200000; };
	class RHS_BTR80A_MSV 												{ quality = 4; price = 210000; };
	class RHS_BTR80A_VDV 												{ quality = 4; price = 210000; };
	class RHS_BTR80A_VMF 												{ quality = 4; price = 210000; };
	class RHS_BTR80A_VV 												{ quality = 4; price = 210000; };
	class rhsusf_stryker_m1126_m2_wd                                    { quality = 5; price = 210000; };
	class rhs_bmd1r														{ quality = 5; price = 250000; };	
	class rhs_bmd1p                                             		{ quality = 5; price = 250000; };	
	class rhs_bmd1pk                                             		{ quality = 5; price = 250000; };	
	class rhs_bmd1k                                             		{ quality = 5; price = 250000; };	
	class rhs_bmd1                                             			{ quality = 5; price = 250000; };	
	class rhs_bmd2m                                             		{ quality = 5; price = 260000; };
	class rhs_bmd2														{ quality = 5; price = 260000; };	
	class rhs_bmd2k                                             		{ quality = 5; price = 260000; };	
	class rhs_bmd4m_vdv                                             	{ quality = 5; price = 280000; };	
	class rhs_bmd4ma_vdv                                             	{ quality = 5; price = 280000; };
	class rhs_bmd4_vdv													{ quality = 5; price = 280000; };
	class rhs_bmp1d_vdv													{ quality = 5; price = 300000; };	
	class rhs_bmp1k_vdv                                             	{ quality = 3; price = 300000; };	
	class rhs_bmp1p_vdv                                             	{ quality = 3; price = 300000; };
	class rhs_bmp1_vdv													{ quality = 5; price = 300000; };
	class rhs_brm1k_vdv                                             	{ quality = 5; price = 300000; };			
	class rhs_Ob_681_2                                             		{ quality = 5; price = 310000; };
	class rhs_bmp2d_vdv                                             	{ quality = 5; price = 320000; };	
	class rhs_bmp2k_vdv                                             	{ quality = 5; price = 320000; };
	class rhs_bmp2e_vdv													{ quality = 5; price = 320000; };
	class rhs_bmp2_vdv													{ quality = 5; price = 320000; };
	class rhs_zsu234_aa													{ quality = 6; price = 400000; };
	class RHS_M2A2_wd													{ quality = 6; price = 450000; };	
	class RHS_M2A2                                             			{ quality = 6; price = 450000; };
	class RHS_M2A3_wd													{ quality = 6; price = 450000; };
	class RHS_M2A3														{ quality = 6; price = 450000; };
	class RHS_M2A2_BUSKI_WD												{ quality = 6; price = 470000; };
	class RHS_M2A2_BUSKI												{ quality = 6; price = 470000; };
	class RHS_M2A3_BUSKI_wd												{ quality = 6; price = 500000; };
	class RHS_M2A3_BUSKI												{ quality = 6; price = 500000; };
	class RHS_M2A3_BUSKIII_wd											{ quality = 6; price = 550000; };
	class RHS_M2A3_BUSKIII												{ quality = 6; price = 550000; };	
	class RHS_M6_wd                                             		{ quality = 6; price = 570000; };	
	class RHS_M6                                             			{ quality = 6; price = 570000; };	
	class rhs_bmp3_msv                                             		{ quality = 6; price = 590000; };
	class rhs_bmp3_late_msv												{ quality = 6; price = 590000; };
	class rhs_bmp3m_msv                                             	{ quality = 6; price = 590000; };
	class rhs_bmp3mera_msv			                					{ quality = 6; price = 600000; };

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////RHS TANKS///////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

	class rhs_sprut_vdv                                           		{ quality = 5; price = 700000; };
	class rhs_t72ba_tv													{ quality = 5; price = 710000; };
	class rhs_t72bb_tv													{ quality = 5; price = 720000; };
	class rhs_t72bc_tv													{ quality = 5; price = 730000; };
	class rhs_t72bd_tv													{ quality = 5; price = 740000; };
	class rhs_t72be_tv                                             		{ quality = 5; price = 750000; };
	class rhs_t80                                             			{ quality = 6; price = 760000; };		
	class rhs_t80b                                             			{ quality = 6; price = 770000; };
	class rhs_t80bk                                             		{ quality = 6; price = 780000; };	
	class rhs_t80a                                             			{ quality = 6; price = 790000; };	
	class rhs_t80bv                                             		{ quality = 6; price = 800000; };	
	class rhs_t80bvk                                             		{ quality = 6; price = 810000; };
	class rhs_t80ue1													{ quality = 6; price = 820000; };	
	class rhs_t80um                                             		{ quality = 6; price = 830000; };	
	class rhs_t80u                                             			{ quality = 6; price = 840000; };	
	class rhs_t80u45m                                       	        { quality = 6; price = 850000; };
	class rhs_t80uk														{ quality = 6; price = 860000; };
	class rhs_t90_tv													{ quality = 6; price = 870000; };
	class rhs_t90a_tv													{ quality = 6; price = 880000; };
	class rhs_t90saa_tv                                             	{ quality = 6; price = 890000; };	
	class rhs_t90sab_tv                                             	{ quality = 6; price = 900000; };	
	class rhsusf_m1a1fep_wd                                             { quality = 7; price = 910000; };	
	class rhsusf_m1a1fep_od                                             { quality = 7; price = 920000; };
	class rhsusf_m1a1fep_d												{ quality = 7; price = 930000; };
	class rhsusf_m1a1hc_wd												{ quality = 7; price = 940000; };
	class rhsusf_m1a1aimwd_usarmy										{ quality = 7; price = 950000; };	
	class rhsusf_m1a1aimd_usarmy                                        { quality = 7; price = 960000; };
	class rhsusf_m1a1aim_tuski_wd										{ quality = 7; price = 970000; };	
	class rhsusf_m1a1aim_tuski_d                                        { quality = 7; price = 980000; };	
	class rhsusf_m1a2sep1wd_usarmy                                      { quality = 7; price = 990000; };	
	class rhsusf_m1a2sep1d_usarmy                                       { quality = 7; price = 1000000; };	
	class rhsusf_m1a2sep1tuskiwd_usarmy                                 { quality = 7; price = 1010000; };	
	class rhsusf_m1a2sep1tuskid_usarmy                                  { quality = 7; price = 1020000; };
	class rhsusf_m1a2sep1tuskiiwd_usarmy								{ quality = 7; price = 1030000; };
	class rhsusf_m1a2sep1tuskiid_usarmy                   	      		{ quality = 7; price = 1040000; };
	class rhs_t90am_tv                                             		{ quality = 6; price = 1100000; };	
	class rhs_t90sm_tv                                             		{ quality = 6; price = 1200000; };	
	class rhs_t14_tv                                             		{ quality = 7; price = 1500000; };

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////RHS HELIs//////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	class RHS_MELB_H6M       											{ quality = 2; price = 200000; };
	class RHS_MELB_MH6M                     							{ quality = 3; price = 400000; };
	class rhs_ka60_c					            					{ quality = 3; price = 600000; };
	class rhs_ka60_grey													{ quality = 3; price = 600000; };
	class RHS_CH_47F													{ quality = 4; price = 800000; };
	class RHS_CH_47F_light												{ quality = 4; price = 800000; };	
	class rhsusf_CH53E_USMC_GAU21                                       { quality = 4; price = 900000; };
	class RHS_Mi8mt_vvsc					        					{ quality = 4; price = 1000000; };
	class RHS_Mi8mt_vvs					            					{ quality = 4; price = 1000000; };
	class RHS_Mi8mt_vdv					        						{ quality = 4; price = 1000000; };	
	class RHS_MELB_AH6M                                             	{ quality = 4; price = 2000000; };
	class RHS_UH1Y							        					{ quality = 4; price = 2100000; };
    class RHS_MI8MTV3_vvsc					     					    { quality = 5; price = 2500000; };
	class RHS_MI8MTV3_vvs					        					{ quality = 5; price = 2500000; };	
	class RHS_Mi8mtv3_Cargo_vvs                                         { quality = 5; price = 2500000; };
	class RHS_Mi8MTV3_vdv					        					{ quality = 5; price = 2500000; };	
	class RHS_Mi8mtv3_Cargo_vdv                                         { quality = 5; price = 2500000; };
	class RHS_Mi8AMTSh_vvsc				        						{ quality = 6; price = 2800000; };	
	class RHS_Mi8MTV3_heavy_vvsc                                        { quality = 6; price = 2800000; };
	class RHS_Mi8AMTSh_vvs				       	 						{ quality = 6; price = 2800000; };	
	class RHS_Mi8MTV3_heavy_vvs                                         { quality = 6; price = 2800000; };	
	class RHS_Mi8MTV3_heavy_vdv                                         { quality = 6; price = 2800000; };
	class RHS_Mi24Vt_vvs					        					{ quality = 6; price = 3500000; };
	class RHS_Mi24P_vvs					        						{ quality = 6; price = 3500000; };
	class RHS_Mi24P_vvsc					        					{ quality = 6; price = 3500000; };
	class RHS_Mi24P_CAS_vvs					        					{ quality = 6; price = 3500000; };
	class RHS_Mi24P_CAS_vvsc					   					    { quality = 6; price = 3500000; };
	class RHS_Mi24P_CAS_vdv					        					{ quality = 6; price = 3500000; };
	class RHS_Mi24P_AT_vvs					        					{ quality = 6; price = 3500000; };
	class RHS_Mi24P_AT_vvsc					        					{ quality = 6; price = 3500000; };
	class RHS_Mi24P_AT_vdv					        					{ quality = 6; price = 3500000; };
	class RHS_Mi24P_vdv					        						{ quality = 6; price = 3500000; };
	class RHS_Mi24V_vvs					        						{ quality = 6; price = 3500000; };
	class RHS_Mi24V_vvsc					        					{ quality = 6; price = 3500000; };
	class RHS_Mi24V_FAB_vvs					        					{ quality = 6; price = 3500000; };
	class RHS_Mi24V_FAB_vvsc					    					{ quality = 6; price = 3500000; };
	class RHS_Mi24V_FAB_vdv					        					{ quality = 6; price = 3500000; };
	class RHS_Mi24V_UPK23_vvs					    					{ quality = 6; price = 3500000; };
	class RHS_Mi24V_UPK23_vvsc					    					{ quality = 6; price = 3500000; };
	class RHS_Mi24V_UPK23_vdv					    					{ quality = 6; price = 3500000; };
	class RHS_Mi24V_AT_vvs					        					{ quality = 6; price = 3500000; };
	class RHS_Mi24V_AT_vvsc					        					{ quality = 6; price = 3500000; };
	class RHS_Mi24V_AT_vdv					        					{ quality = 6; price = 3500000; };
	class RHS_Mi24V_vdv					        						{ quality = 6; price = 3500000; };
	class RHS_AH1Z					    								{ quality = 5; price = 3900000; };
	class RHS_AH1Z_wd					    							{ quality = 5; price = 3900000; };
	class RHS_AH1Z_CS					    							{ quality = 5; price = 3900000; };
	class RHS_AH1Z_wd_GS					    						{ quality = 5; price = 3900000; };
	class RHS_AH1Z_wd_CS					    						{ quality = 5; price = 3900000; };
	class rhs_mi28n_vvs                        							{ quality = 5; price = 4100000; };          
	class rhs_mi28n_vvsc                       							{ quality = 5; price = 4100000; };
	class rhs_mi28n_s13_vvs                    							{ quality = 5; price = 3900000; };
	class rhs_mi28n_s13_vvsc                   							{ quality = 5; price = 3900000; };
	class RHS_Ka52_vvsc					    							{ quality = 7; price = 4500000; };
	class RHS_Ka52_vvs					    							{ quality = 7; price = 4500000; };
	class RHS_Ka52_UPK23_vvs					    					{ quality = 7; price = 4500000; };
	class RHS_Ka52_UPK23_vvsc					    					{ quality = 7; price = 4500000; };
	class RHS_AH64D					        							{ quality = 6; price = 5000000; };
	class RHS_AH64D_CS					        						{ quality = 6; price = 5000000; };
	class RHS_AH64D_wd_GS					        					{ quality = 6; price = 5000000; };
	class RHS_AH64D_AA					        						{ quality = 6; price = 5000000; };	
	class RHS_AH64DGrey                                             	{ quality = 6; price = 5000000; };	

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////RHS UAV///////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	class rhs_pchela1t_vvs                                             	{ quality = 3; price = 50000; };
	
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////RHS JETs////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	class RHS_Su25SM_vvsc                                             	{ quality = 5; price = 5500000; };
	class RHS_Su25SM_vvs												{ quality = 5; price = 5500000; };
	class RHS_Su25SM_CAS_vvsc                                           { quality = 5; price = 5550000; }; 
	class RHS_A10 														{ quality = 5; price = 5600000; };
	class RHS_A10_AT                                                    { quality = 5; price = 5600000; sellPrice = 600000; };
	class rhs_mig29s_vvsc                                             	{ quality = 6; price = 6000000; };	
	class rhs_mig29s_vvs                                             	{ quality = 6; price = 6000000; };
	class rhs_mig29s_vmf                                             	{ quality = 6; price = 6000000; };	
	class rhs_mig29sm_vvsc                                             	{ quality = 6; price = 6500000; };
	class rhs_mig29sm_vvs												{ quality = 6; price = 6500000; };	
	class rhs_mig29sm_vmf                                             	{ quality = 6; price = 6500000; };
	class RHS_T50_vvs_051												{ quality = 7; price = 6900000; };	
	class RHS_T50_vvs_052                                             	{ quality = 7; price = 7000000; };	
	class RHS_T50_vvs_053                                             	{ quality = 7; price = 7100000; };	
	class RHS_T50_vvs_054                                             	{ quality = 7; price = 7200000; };	
	class RHS_T50_vvs_blueonblue                                        { quality = 7; price = 7300000; };	
	class RHS_T50_vvs_generic_ext                                       { quality = 7; price = 7400000; };
	class rhsusf_f22													{ quality = 7; price = 8000000; };


///////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////BOATs//////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////
	
	class Exile_Boat_WaterScooter									{ quality = 1; price = 5000; };	
	class B_Boat_Transport_01_F                                   	{ quality = 2; price = 10000; };	
	class O_Boat_Transport_01_F                                   	{ quality = 2; price = 10000; };	
	class I_Boat_Transport_01_F                                   	{ quality = 2; price = 10000; };
	class Exile_Boat_RHIB											{ quality = 3; price = 15000; };	
	class C_Boat_Civil_01_F                                         { quality = 3; price = 20000; };	
	class C_Boat_Civil_01_police_F                                  { quality = 3; price = 20000; };	
	class C_Boat_Civil_01_rescue_F                                  { quality = 3; price = 20000; };	
	class Exile_Boat_MotorBoat_Orange								{ quality = 3; price = 20000; };
	class B_Boat_Armed_01_minigun_F									{ quality = 5; price = 300000; };
	class O_Boat_Armed_01_hmg_F										{ quality = 5; price = 300000; };  	
	class I_Boat_Armed_01_minigun_F                                 { quality = 5; price = 300000; };

///////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////CUP & RHS Boats/////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////
	
	class CUP_O_PBX_SLA                                             { quality = 1; price = 5000; };
	class CUP_B_Zodiac_USMC                             			{ quality = 1; price = 7000; };
	class CUP_C_Fishing_Boat_Chernarus                  			{ quality = 2; price = 15000; };
	class CUP_B_RHIB2Turret_USMC                        			{ quality = 3; price = 100000; };
	class CUP_I_RHIB2Turret_RACS                        			{ quality = 3; price = 100000; };	
	class CUP_O_LCVP_SLA                                            { quality = 3; price = 30000; };	
	class CUP_O_LCVP_VIV_SLA                                        { quality = 3; price = 50000; };	
	class CUP_I_LCVP_RACS                                           { quality = 3; price = 50000; };	
	class CUP_I_LCVP_VIV_RACS                                       { quality = 3; price = 50000; };
	class rhsusf_mkvsoc                                             { quality = 7; price = 400000; };	
	//class classname                                             { quality = 3; price = 100000; };	
	//class classname                                             { quality = 3; price = 100000; };	
	//class classname                                             { quality = 3; price = 100000; };	
	//class classname                                             { quality = 3; price = 100000; };	
	//class classname                                             { quality = 3; price = 100000; };	
	//class classname                                             { quality = 3; price = 100000; };	
	//class classname                                             { quality = 3; price = 100000; };	
	//class classname                                             { quality = 3; price = 100000; };	
	//class classname                                             { quality = 3; price = 100000; };	
	//class classname                                             { quality = 3; price = 100000; };	
	//class classname                                             { quality = 3; price = 100000; };	

////////////////////////////////////////////////////////////////////////////////////////////////////
	
	///////////////////////////////////////////////////////////////////////////////
	// Night Vision
	///////////////////////////////////////////////////////////////////////////////
	class NVGoggles_tna_F             				        { quality = 2; price = 250; };
	class O_NVGoggles_ghex_F          				        { quality = 3; price = 500; };
	class O_NVGoggles_hex_F           				        { quality = 3; price = 500; };
	class O_NVGoggles_urb_F           				        { quality = 3; price = 500; };                                                     
	class H_HelmetO_ViperSP_ghex_F    				        { quality = 5; price = 160000; }; //Themal // Шлем
	class H_HelmetO_ViperSP_hex_F     				        { quality = 5; price = 160000; }; //Themal // Шлем
	class Laserdesignator_01_khk_F    				        { quality = 3; price = 1000; };	//Thermal
	class Laserdesignator_02_ghex_F   				        { quality = 3; price = 1000; };	//Thermal
	class NVGogglesB_blk_F            				        { quality = 5; price = 50000; }; //Normal NightV but fullscreen thermal
	class NVGogglesB_grn_F            				        { quality = 5; price = 50000; };	//Normal NightV but fullscreen thermal
	class NVGogglesB_gry_F            				        { quality = 5; price = 50000; };	//Normal NightV but fullscreen thermal
	///////////////////////////////////////////////////////////////////////////////
	// Muzzle Attachment // Глушитили
	///////////////////////////////////////////////////////////////////////////////
	// Apex
	///////////////////////////////////////////////////////////////////////////////
	class muzzle_snds_58_blk_F        				        { quality = 3; price = 10320; };
	class muzzle_snds_58_wdm_F        				        { quality = 3; price = 10320; };
	class muzzle_snds_65_TI_blk_F     				        { quality = 4; price = 10375; };
	class muzzle_snds_65_TI_ghex_F    				        { quality = 4; price = 10375; };
	class muzzle_snds_65_TI_hex_F     				        { quality = 4; price = 10375; };
	class muzzle_snds_B_khk_F         				        { quality = 5; price = 10350; };
	class muzzle_snds_B_snd_F         				        { quality = 5; price = 10350; };
	class muzzle_snds_H_MG_blk_F      				        { quality = 4; price = 10320; };
	class muzzle_snds_H_MG_khk_F      				        { quality = 4; price = 10320; };
	class muzzle_snds_H_khk_F         				        { quality = 4; price = 10350; };
	class muzzle_snds_H_snd_F         				        { quality = 4; price = 10350; };
	class muzzle_snds_m_khk_F         				        { quality = 3; price = 10315; };
	class muzzle_snds_m_snd_F         				        { quality = 3; price = 10315; };
	///////////////////////////////////////////////////////////////////////////////
	//  CUP
	///////////////////////////////////////////////////////////////////////////////
	class CUP_muzzle_Bizon									{ quality = 3; price = 10320; };
	class CUP_muzzle_PB6P9									{ quality = 3; price = 10320; };
	class CUP_muzzle_PBS4									{ quality = 3; price = 10320; };
	class CUP_muzzle_mfsup_SCAR_H							{ quality = 3; price = 10320; };
	class CUP_muzzle_mfsup_SCAR_L							{ quality = 3; price = 10320; };
	class CUP_muzzle_snds_AWM								{ quality = 3; price = 10320; };
	class CUP_muzzle_snds_G36_black							{ quality = 3; price = 10320; };
	class CUP_muzzle_snds_G36_desert						{ quality = 3; price = 10320; };
	class CUP_muzzle_snds_L85								{ quality = 3; price = 10320; };
	class CUP_muzzle_snds_M110								{ quality = 3; price = 10320; };
	class CUP_muzzle_snds_M14								{ quality = 3; price = 10320; };
	class CUP_muzzle_snds_M16								{ quality = 3; price = 10320; };
	class CUP_muzzle_snds_M16_camo							{ quality = 3; price = 10320; };
	class CUP_muzzle_snds_M9								{ quality = 3; price = 10320; };
	class CUP_muzzle_snds_MicroUzi							{ quality = 3; price = 10320; };
	class CUP_muzzle_snds_SCAR_H							{ quality = 3; price = 10320; };
	class CUP_muzzle_snds_SCAR_L							{ quality = 3; price = 10320; };
	class CUP_muzzle_snds_XM8								{ quality = 3; price = 10320; };
	class CUP_muzzle_mfsup_Suppressor_M107_Grey             { quality = 6; price = 100320; };
	class CUP_muzzle_mfsup_Suppressor_M107_Black            { quality = 6; price = 100320; }; 
	class CUP_muzzle_mfsup_Suppressor_M107_Woodland         { quality = 6; price = 100320; };
	///////////////////////////////////////////////////////////////////////////////
	// Exile
	///////////////////////////////////////////////////////////////////////////////
	class muzzle_snds_338_black 					        { quality = 5; price = 100350; };
	class muzzle_snds_338_green 					        { quality = 5; price = 100350; };
	class muzzle_snds_338_sand 						        { quality = 5; price = 100350; };
	class muzzle_snds_93mmg 						        { quality = 4; price = 100350; };
	class muzzle_snds_93mmg_tan 					        { quality = 4; price = 100350; };
	class muzzle_snds_B 							        { quality = 3; price = 10320; };
	class muzzle_snds_H 							        { quality = 2; price = 10320; };
	class muzzle_snds_H_MG 							        { quality = 2; price = 10320; };
	class muzzle_snds_H_SW 							        { quality = 2; price = 10320; };
	class muzzle_snds_L 							        { quality = 1; price = 10310; };
	class muzzle_snds_M 							        { quality = 1; price = 10310; };
	class muzzle_snds_acp 							        { quality = 1; price = 10310; };
	///////////////////////////////////////////////////////////////////////////////
	// RHS
	///////////////////////////////////////////////////////////////////////////////
	//US
	class rhsusf_acc_SF3P556								{ quality = 2; price = 340; };
	class rhsusf_acc_SFMB556								{ quality = 2; price = 340; };
	class rhsusf_acc_nt4_black								{ quality = 3; price = 380; };
	class rhsusf_acc_nt4_tan								{ quality = 3; price = 380; };
	class rhsusf_acc_rotex5_grey							{ quality = 3; price = 380; };
	class rhsusf_acc_rotex5_tan								{ quality = 3; price = 380; };
	class rhsusf_acc_SR25S									{ quality = 2; price = 390; };
	class rhsusf_acc_M2010S									{ quality = 2; price = 400; };
	//Russian                                                                      3
	class rhs_acc_ak5										{ quality = 1; price = 340; };
	class rhs_acc_dtk										{ quality = 1; price = 340; };
	class rhs_acc_dtk1										{ quality = 1; price = 340; };
	class rhs_acc_dtk3										{ quality = 1; price = 340; };
	class rhs_acc_dtk4screws								{ quality = 2; price = 380; };
	class rhs_acc_dtk4long									{ quality = 2; price = 380; };
	class rhs_acc_dtk4short									{ quality = 2; price = 380; };
	class rhs_acc_tgpa										{ quality = 2; price = 380; };
	class rhs_acc_dtk1l										{ quality = 1; price = 340; };
	class rhs_acc_pbs1										{ quality = 2; price = 390; };
	// Added by ElShotte
	class rhsusf_acc_omega9k								{ quality = 3; price = 400; };
	class rhs_acc_uuk										{ quality = 1; price = 350; };
	//MP7A2 Rotex Silencer Variations                                              4
	class rhsusf_acc_rotex_mp7 								{ quality = 3; price = 300; };
	class rhsusf_acc_rotex_mp7_desert 						{ quality = 3; price = 300; };
	class rhsusf_acc_rotex_mp7_winter 						{ quality = 3; price = 300; };
	class rhsusf_acc_rotex_mp7_aor1 						{ quality = 3; price = 300; };

	///////////////////////////////////////////////////////////////////////////////
	// Optics // Оптика
	///////////////////////////////////////////////////////////////////////////////
	// Apex
	///////////////////////////////////////////////////////////////////////////////
	class optic_Arco_blk_F            				        { quality = 1; price = 300; };
	class optic_Arco_ghex_F           				        { quality = 1; price = 300; };
	class optic_DMS_ghex_F            				        { quality = 2; price = 5350; };
	class optic_ERCO_blk_F            				        { quality = 1; price = 425; };
	class optic_ERCO_khk_F            				        { quality = 1; price = 425; };
	class optic_ERCO_snd_F            				        { quality = 1; price = 425; };
	class optic_Hamr_khk_F            				        { quality = 3; price = 400; };
	class optic_Holosight_blk_F       				        { quality = 1; price = 350; };
	class optic_Holosight_khk_F       				        { quality = 1; price = 350; };
	class optic_Holosight_smg_blk_F   				        { quality = 1; price = 350; };
	class optic_LRPS_ghex_F           				        { quality = 5; price = 10500; };
	class optic_LRPS_tna_F            				        { quality = 5; price = 10500; };
	class optic_SOS_khk_F             				        { quality = 2; price = 1000; };
	///////////////////////////////////////////////////////////////////////////////
	//  CUP
	///////////////////////////////////////////////////////////////////////////////
	class CUP_optic_ACOG									{ quality = 2; price = 1000; };
	class CUP_optic_AN_PAS_13c1								{ quality = 2; price = 1000; };
	class CUP_optic_AN_PAS_13c2								{ quality = 2; price = 1000; };
	class CUP_optic_AN_PVS_10								{ quality = 2; price = 1000; };
	class CUP_optic_AN_PVS_4								{ quality = 2; price = 1000; };
	class CUP_optic_CWS										{ quality = 2; price = 1000; };
	class CUP_optic_CompM2_Black							{ quality = 2; price = 1000; };
	class CUP_optic_CompM2_Desert							{ quality = 2; price = 1000; };
	class CUP_optic_CompM2_Woodland							{ quality = 2; price = 1000; };
	class CUP_optic_CompM2_Woodland2						{ quality = 2; price = 1000; };
	class CUP_optic_CompM4									{ quality = 2; price = 1000; };
	class CUP_optic_ELCAN_SpecterDR							{ quality = 2; price = 1000; };
	class CUP_optic_ElcanM145								{ quality = 2; price = 1000; };
	class CUP_optic_Eotech533								{ quality = 2; price = 1000; };
	class CUP_optic_GOSHAWK									{ quality = 2; price = 1000; };
	class CUP_optic_HoloBlack								{ quality = 2; price = 1000; };
	class CUP_optic_HoloDesert								{ quality = 2; price = 1000; };
	class CUP_optic_HoloWdl									{ quality = 2; price = 1000; };
	class CUP_optic_Kobra									{ quality = 2; price = 1000; };
	class CUP_optic_LeupoldM3LR								{ quality = 2; price = 1000; };
	class CUP_optic_LeupoldMk4								{ quality = 2; price = 1000; };
	class CUP_optic_LeupoldMk4_10x40_LRT_Desert				{ quality = 2; price = 1000; };
	class CUP_optic_LeupoldMk4_10x40_LRT_Woodland			{ quality = 2; price = 1000; };
	class CUP_optic_LeupoldMk4_CQ_T							{ quality = 2; price = 1000; };
	class CUP_optic_LeupoldMk4_MRT_tan						{ quality = 2; price = 1000; };
	class CUP_optic_Leupold_VX3								{ quality = 2; price = 1000; };
	class CUP_optic_MAAWS_Scope								{ quality = 2; price = 1000; };
	class CUP_optic_MRad									{ quality = 2; price = 1000; };
	class CUP_optic_NSPU									{ quality = 2; price = 1000; };
	class CUP_optic_PSO_1									{ quality = 2; price = 1000; };
	class CUP_optic_PSO_3									{ quality = 2; price = 1000; };
	class CUP_optic_PechenegScope							{ quality = 2; price = 1000; };
	class CUP_optic_RCO										{ quality = 2; price = 1000; };
	class CUP_optic_RCO_desert								{ quality = 2; price = 1000; };
	class CUP_optic_SB_11_4x20_PM							{ quality = 2; price = 1000; };
	class CUP_optic_SMAW_Scope								{ quality = 2; price = 1000; };
	class CUP_optic_SUSAT									{ quality = 2; price = 1000; };
	class CUP_optic_TrijiconRx01_black						{ quality = 2; price = 1000; };
	class CUP_optic_TrijiconRx01_desert						{ quality = 2; price = 1000; };
	class CUP_optic_ZDDot									{ quality = 2; price = 1000; };
	///////////////////////////////////////////////////////////////////////////////
	// Exile
	///////////////////////////////////////////////////////////////////////////////
	class optic_tws									        { quality = 7; price = 5000; };
	class optic_tws_mg								        { quality = 7; price = 5000; };
	class optic_ACO_grn								        { quality = 1; price = 370; };
	class optic_ACO_grn_smg							        { quality = 1; price = 370; };
	class optic_AMS									        { quality = 5; price = 15600; };
	class optic_AMS_khk								        { quality = 5; price = 15600; };
	class optic_AMS_snd								        { quality = 5; price = 15600; };
	class optic_Aco									        { quality = 1; price = 370; };
	class optic_Aco_smg								        { quality = 1; price = 370; };
	class optic_Arco								        { quality = 1; price = 300; };
	class optic_DMS									        { quality = 2; price = 5350; };
	class optic_Hamr								        { quality = 3; price = 200; };
	class optic_Holosight							        { quality = 1; price = 350; };
	class optic_Holosight_smg						        { quality = 1; price = 350; };
	class optic_KHS_blk								        { quality = 4; price = 600; };
	class optic_KHS_hex								        { quality = 4; price = 600; };
	class optic_KHS_old								        { quality = 4; price = 600; };
	class optic_KHS_tan								        { quality = 4; price = 600; };
	class optic_LRPS								        { quality = 5; price = 10500; sellPrice = 0; };
	class optic_MRCO								        { quality = 1; price = 300; };
	class optic_MRD									        { quality = 1; price = 310; };
	class optic_NVS									        { quality = 4; price = 500; };
	class optic_Nightstalker						        { quality = 6; price = 1000; };
	class optic_SOS									        { quality = 2; price = 200; };
	class optic_Yorris								        { quality = 1; price = 310; };
	///////////////////////////////////////////////////////////////////////////////
	// RHS
	///////////////////////////////////////////////////////////////////////////////
	class rhs_acc_1p29										{ quality = 2; price = 300; };
	class rhs_acc_1p63										{ quality = 2; price = 175; };
	class rhs_acc_1p78										{ quality = 1; price = 250; };
	class rhs_acc_1pn93_1									{ quality = 1; price = 300; };
	class rhs_acc_1pn93_2                           		{ quality = 1; price = 150; };
	class rhs_acc_dh520x56									{ quality = 3; price = 400; };
	class rhs_acc_ekp1										{ quality = 1; price = 150; };
	class rhs_acc_pgo7v										{ quality = 2; price = 300; };
	class rhs_acc_pkas										{ quality = 1; price = 150; };
	class rhs_acc_pso1m2									{ quality = 2; price = 300; };
	class rhs_acc_rakursPM 									{ quality = 3; price = 250; };
	class rhs_weap_optic_smaw 								{ quality = 3; price = 300; };
	class rhsusf_acc_ACOG									{ quality = 2; price = 300; };
	class rhsusf_acc_ACOG2									{ quality = 2; price = 300; };
	class rhsusf_acc_ACOG2_USMC								{ quality = 2; price = 300; };
	class rhsusf_acc_ACOG3									{ quality = 2; price = 300; };
	class rhsusf_acc_ACOG3_USMC								{ quality = 2; price = 300; };
	class rhsusf_acc_ACOG_MDO								{ quality = 4; price = 400; };
	class rhsusf_acc_ACOG_RMR								{ quality = 4; price = 300; };
	class rhsusf_acc_ACOG_USMC								{ quality = 2; price = 300; };
	class rhsusf_acc_ACOG_d 								{ quality = 3; price = 250; };
	class rhsusf_acc_ACOG_pip								{ quality = 2; price = 300; };
	class rhsusf_acc_ACOG_wd 								{ quality = 3; price = 250; };
	class rhsusf_acc_ELCAN									{ quality = 2; price = 500; };
	class rhsusf_acc_ELCAN_pip								{ quality = 2; price = 500; };
	class rhsusf_acc_EOTECH 								{ quality = 2; price = 850; };
	class rhsusf_acc_LEUPOLDMK4 							{ quality = 2; price = 850; };
	class rhsusf_acc_LEUPOLDMK4_2 							{ quality = 2; price = 850; };
	class rhsusf_acc_M8541 									{ quality = 4; price = 500; };
	class rhsusf_acc_M8541_low 								{ quality = 4; price = 500; };
	class rhsusf_acc_M8541_low_d 							{ quality = 4; price = 500; };
	class rhsusf_acc_M8541_low_wd 							{ quality = 4; price = 500; };
	class rhsusf_acc_SpecterDR 								{ quality = 3; price = 200; };
	class rhsusf_acc_SpecterDR_A_3d 						{ quality = 3; price = 200; };
	class rhsusf_acc_SpecterDR_D 							{ quality = 3; price = 200; };
	class rhsusf_acc_SpecterDR_OD 							{ quality = 3; price = 200; };
	class rhsusf_acc_anpas13gv1								{ quality = 5; price = 2000; };
	class rhsusf_acc_compm4									{ quality = 2; price = 150; };
	class rhsusf_acc_eotech_552								{ quality = 2; price = 175; };
	class rhsusf_acc_premier 								{ quality = 5; price = 600; };
	class rhsusf_acc_premier_anpvs27 						{ quality = 5; price = 2500; };
	class rhsusf_acc_premier_low 							{ quality = 5; price = 600; };

	///////////////////////////////////////////////////////////////////////////////
	// Целе указатели и навесное
	///////////////////////////////////////////////////////////////////////////////
	// Exile
	///////////////////////////////////////////////////////////////////////////////
	class acc_flashlight 							        { quality = 1; price = 140; };
	class acc_pointer_IR 							        { quality = 1; price = 200; };
	///////////////////////////////////////////////////////////////////////////////
	// RHS
	///////////////////////////////////////////////////////////////////////////////
	class rhsusf_acc_grip1									{ quality = 4; price = 100; };
	class rhsusf_acc_grip2 									{ quality = 4; price = 100; };
	class rhsusf_acc_grip2_tan 								{ quality = 4; price = 100; };
	class rhsusf_acc_grip3 									{ quality = 4; price = 100; };
	class rhsusf_acc_grip3_tan 								{ quality = 4; price = 100; };
	class rhs_acc_grip_rk2 									{ quality = 4; price = 100; };
	class rhs_acc_grip_rk6 									{ quality = 4; price = 100; };
	class rhs_acc_grip_ffg2 								{ quality = 4; price = 100; };

	///////////////////////////////////////////////////////////////////////////////
	// RHS
	///////////////////////////////////////////////////////////////////////////////
	class rhsusf_acc_anpeq15side							{ quality = 1; price = 100; };
	class rhsusf_acc_anpeq15								{ quality = 1; price = 100; };
	class rhsusf_acc_anpeq15A								{ quality = 1; price = 100; };
	class rhsusf_acc_anpeq15_light							{ quality = 1; price = 100; };
	// Added by ElShotte
	class rhsusf_acc_M952V									{ quality = 3; price = 100; };
	class rhs_acc_perst3									{ quality = 3; price = 100; };
	class rhs_acc_perst3_top								{ quality = 3; price = 100; };
	class rhs_acc_perst3_2dp_h								{ quality = 3; price = 100; };
	class rhs_acc_perst3_2dp_light_h						{ quality = 3; price = 100; };
	class rhs_acc_2dpZenit									{ quality = 3; price = 100; };
	class rhs_acc_2dpZenit_ris								{ quality = 3; price = 100; };
	class rhs_acc_perst1ik									{ quality = 3; price = 100; };
	class rhs_acc_perst1ik_ris								{ quality = 3; price = 100; };
	class rhsusf_acc_anpeq15_bk 							{ quality = 3; price = 100; };
	class rhsusf_acc_anpeq15_bk_light 						{ quality = 3; price = 100; };

	///////////////////////////////////////////////////////////////////////////////
	// Bipods // сошки
	///////////////////////////////////////////////////////////////////////////////
	// Apex
	///////////////////////////////////////////////////////////////////////////////
	class bipod_01_F_khk              				        { quality = 2; price = 100; };
	///////////////////////////////////////////////////////////////////////////////
	// Exile
	///////////////////////////////////////////////////////////////////////////////
	class bipod_01_F_blk	 						        { quality = 2; price = 100; };
	class bipod_01_F_mtp	 						        { quality = 2; price = 100; };
	class bipod_01_F_snd	 						        { quality = 2; price = 100; };
	class bipod_02_F_blk	 						        { quality = 2; price = 100; };
	class bipod_02_F_hex	 						        { quality = 2; price = 100; };
	class bipod_02_F_tan	 						        { quality = 2; price = 100; };
	class bipod_03_F_blk	 						        { quality = 2; price = 100; };
	class bipod_03_F_oli	 						        { quality = 2; price = 100; };
	///////////////////////////////////////////////////////////////////////////////
	// RHS
	///////////////////////////////////////////////////////////////////////////////
	class rhsusf_acc_harris_swivel							{ quality = 3; price = 180; };
	class rhs_acc_harris_swivel								{ quality = 3; price = 180; };
	class rhsusf_acc_harris_bipod							{ quality = 3; price = 180; };


	///////////////////////////////////////////////////////////////////////////////
	// Ammo // боеприпасы
	///////////////////////////////////////////////////////////////////////////////
	// Apex
	///////////////////////////////////////////////////////////////////////////////
	class 100Rnd_580x42_Mag_F                               { quality = 1; price = 115; };
	class 100Rnd_580x42_Mag_Tracer_F                        { quality = 1; price = 115; };
	class 10Rnd_50BW_Mag_F                                  { quality = 1; price = 135; };
	class 10Rnd_9x21_Mag							        { quality = 1; price = 110; };
	class 150Rnd_556x45_Drum_Mag_F                          { quality = 1; price = 175; };
	class 150Rnd_556x45_Drum_Mag_Tracer_F                   { quality = 1; price = 175; };
	class 200Rnd_556x45_Box_F                               { quality = 1; price = 190; };
	class 200Rnd_556x45_Box_Red_F                           { quality = 1; price = 190; };
	class 200Rnd_556x45_Box_Tracer_F                        { quality = 1; price = 190; };
	class 200Rnd_556x45_Box_Tracer_Red_F                    { quality = 1; price = 190; };
	class 20Rnd_650x39_Cased_Mag_F                          { quality = 1; price = 120; };
	class 30Rnd_545x39_Mag_F                                { quality = 1; price = 110; };
	class 30Rnd_545x39_Mag_Green_F                          { quality = 1; price = 110; };
	class 30Rnd_545x39_Mag_Tracer_F                         { quality = 1; price = 110; };
	class 30Rnd_545x39_Mag_Tracer_Green_F                   { quality = 1; price = 110; };
	class 30Rnd_580x42_Mag_F                                { quality = 1; price = 115; };
	class 30Rnd_580x42_Mag_Tracer_F                         { quality = 1; price = 115; };
	class 30Rnd_762x39_Mag_F                                { quality = 1; price = 125; };
	class 30Rnd_762x39_Mag_Green_F                          { quality = 1; price = 125; };
	class 30Rnd_762x39_Mag_Tracer_F                         { quality = 1; price = 125; };
	class 30Rnd_762x39_Mag_Tracer_Green_F                   { quality = 1; price = 125; };
	class 30Rnd_9x21_Mag_SMG_02						        { quality = 1; price = 110; };
	class 30Rnd_9x21_Mag_SMG_02_Tracer_Green                { quality = 1; price = 115; };
	class 30Rnd_9x21_Mag_SMG_02_Tracer_Red                  { quality = 1; price = 115; };
	class 30Rnd_9x21_Mag_SMG_02_Tracer_Yellow               { quality = 1; price = 115; };
	///////////////////////////////////////////////////////////////////////////////
	//  CUP
	///////////////////////////////////////////////////////////////////////////////
	//// Shotgun
	class CUP_20Rnd_B_AA12_74Slug							{ quality = 1; price = 110; };
	class CUP_20Rnd_B_AA12_HE								{ quality = 1; price = 110; };
	class CUP_20Rnd_B_AA12_Pellets							{ quality = 1; price = 110; };
	class CUP_8Rnd_B_Beneli_74Slug							{ quality = 1; price = 110; };
	class CUP_8Rnd_B_Saiga12_74Slug_M						{ quality = 1; price = 110; };
	////                                                                           1
	class CUP_100Rnd_556x45_BetaCMag						{ quality = 1; price = 110; };
	class CUP_100Rnd_TE1_Green_Tracer_556x45_BetaCMag		{ quality = 1; price = 110; };
	class CUP_100Rnd_TE1_Red_Tracer_556x45_BetaCMag			{ quality = 1; price = 110; };
	class CUP_100Rnd_TE1_Yellow_Tracer_556x45_BetaCMag		{ quality = 1; price = 110; };
	class CUP_20Rnd_556x45_Stanag							{ quality = 1; price = 110; };
	class CUP_20Rnd_762x51_B_SCAR							{ quality = 1; price = 110; };
	class CUP_20Rnd_762x51_CZ805B							{ quality = 1; price = 110; };
	class CUP_20Rnd_762x51_DMR								{ quality = 1; price = 110; };
	class CUP_20Rnd_762x51_FNFAL_M							{ quality = 1; price = 110; };
	class CUP_20Rnd_TE1_Green_Tracer_762x51_CZ805B			{ quality = 1; price = 110; };
	class CUP_20Rnd_TE1_Green_Tracer_762x51_DMR				{ quality = 1; price = 110; };
	class CUP_20Rnd_TE1_Green_Tracer_762x51_SCAR			{ quality = 1; price = 110; };
	class CUP_20Rnd_TE1_Red_Tracer_762x51_CZ805B			{ quality = 1; price = 110; };
	class CUP_20Rnd_TE1_Red_Tracer_762x51_DMR				{ quality = 1; price = 110; };
	class CUP_20Rnd_TE1_Red_Tracer_762x51_SCAR				{ quality = 1; price = 110; };
	class CUP_20Rnd_TE1_White_Tracer_762x51_CZ805B			{ quality = 1; price = 110; };
	class CUP_20Rnd_TE1_White_Tracer_762x51_DMR				{ quality = 1; price = 110; };
	class CUP_20Rnd_TE1_White_Tracer_762x51_SCAR			{ quality = 1; price = 110; };
	class CUP_20Rnd_TE1_Yellow_Tracer_762x51_CZ805B			{ quality = 1; price = 110; };
	class CUP_20Rnd_TE1_Yellow_Tracer_762x51_DMR			{ quality = 1; price = 110; };
	class CUP_20Rnd_TE1_Yellow_Tracer_762x51_SCAR			{ quality = 1; price = 110; };
	class CUP_30Rnd_545x39_AK_M								{ quality = 1; price = 110; };
	class CUP_30Rnd_556x45_G36								{ quality = 1; price = 110; };
	class CUP_30Rnd_556x45_Stanag							{ quality = 1; price = 110; };
	class CUP_30Rnd_762x39_AK47_M							{ quality = 1; price = 110; };
	class CUP_30Rnd_Sa58_M									{ quality = 1; price = 110; };
	class CUP_30Rnd_Sa58_M_TracerG							{ quality = 1; price = 110; };
	class CUP_30Rnd_Sa58_M_TracerR							{ quality = 1; price = 110; };
	class CUP_30Rnd_Sa58_M_TracerY							{ quality = 1; price = 110; };
	class CUP_30Rnd_TE1_Green_Tracer_545x39_AK_M			{ quality = 1; price = 110; };
	class CUP_30Rnd_TE1_Green_Tracer_556x45_G36				{ quality = 1; price = 110; };
	class CUP_30Rnd_TE1_Red_Tracer_545x39_AK_M				{ quality = 1; price = 110; };
	class CUP_30Rnd_TE1_Red_Tracer_556x45_G36				{ quality = 1; price = 110; };
	class CUP_30Rnd_TE1_White_Tracer_545x39_AK_M			{ quality = 1; price = 110; };
	class CUP_30Rnd_TE1_Yellow_Tracer_545x39_AK_M			{ quality = 1; price = 110; };
	class CUP_30Rnd_TE1_Yellow_Tracer_556x45_G36			{ quality = 1; price = 110; };
	class CUP_75Rnd_TE4_LRT4_Green_Tracer_545x39_RPK_M		{ quality = 1; price = 110; };
	//// 
	class CUP_10Rnd_127x99_m107								{ quality = 1; price = 110; };
	class CUP_10Rnd_762x51_CZ750							{ quality = 1; price = 110; };
	class CUP_10Rnd_762x51_CZ750_Tracer						{ quality = 1; price = 110; };
	class CUP_10Rnd_762x54_SVD_M							{ quality = 1; price = 110; };
	class CUP_10Rnd_9x39_SP5_VSS_M							{ quality = 1; price = 110; };
	class CUP_10x_303_M										{ quality = 1; price = 110; };
	class CUP_20Rnd_762x51_B_M110							{ quality = 1; price = 110; };
	class CUP_20Rnd_9x39_SP5_VSS_M							{ quality = 1; price = 110; };
	class CUP_20Rnd_TE1_Green_Tracer_762x51_M110			{ quality = 1; price = 110; };
	class CUP_20Rnd_TE1_Red_Tracer_762x51_M110				{ quality = 1; price = 110; };
	class CUP_20Rnd_TE1_White_Tracer_762x51_M110			{ quality = 1; price = 110; };
	class CUP_20Rnd_TE1_Yellow_Tracer_762x51_M110			{ quality = 1; price = 110; };
	//class CUP_5Rnd_127x108_KSVK_M							{ quality = 1; price = 110; };
	class CUP_5Rnd_127x99_as50_M							{ quality = 1; price = 110; };
	class CUP_5Rnd_762x51_M24								{ quality = 1; price = 110; };
	class CUP_5Rnd_86x70_L115A1								{ quality = 1; price = 110; };
	class CUP_5x_22_LR_17_HMR_M								{ quality = 1; price = 110; };
    //// 
	class CUP_10Rnd_9x19_Compact							{ quality = 1; price = 80; };
	class CUP_15Rnd_9x19_M9									{ quality = 1; price = 80; };
	class CUP_17Rnd_9x19_glock17							{ quality = 1; price = 80; };
	class CUP_18Rnd_9x19_Phantom							{ quality = 1; price = 80; };
	class CUP_6Rnd_45ACP_M									{ quality = 1; price = 80; };
	class CUP_7Rnd_45ACP_1911								{ quality = 1; price = 80; };
	class CUP_8Rnd_9x18_MakarovSD_M							{ quality = 1; price = 80; };
	class CUP_8Rnd_9x18_Makarov_M							{ quality = 1; price = 80; };
	///////////////////////////////////////////////////////////////////////////////
	// Exile
	///////////////////////////////////////////////////////////////////////////////
	class 10Rnd_762x51_Mag                                  { quality = 1; price = 130; };
	class 100Rnd_65x39_caseless_mag 						{ quality = 1; price = 130; };
	class 100Rnd_65x39_caseless_mag_Tracer 					{ quality = 1; price = 140; };
	class 10Rnd_127x54_Mag 									{ quality = 1; price = 130; };
	class 10Rnd_338_Mag 									{ quality = 1; price = 130; };
	class 10Rnd_762x54_Mag 									{ quality = 1; price = 130; };
	class 10Rnd_93x64_DMR_05_Mag 							{ quality = 1; price = 140; };
	class 11Rnd_45ACP_Mag 									{ quality = 1; price = 180; };
	class 130Rnd_338_Mag 									{ quality = 1; price = 140; };
	class 150Rnd_762x54_Box 								{ quality = 1; price = 120; };
	class 150Rnd_762x54_Box_Tracer 							{ quality = 1; price = 130; };
	class 150Rnd_93x64_Mag 									{ quality = 1; price = 150; };
	class 16Rnd_9x21_Mag 									{ quality = 1; price = 120; };
	class 200Rnd_65x39_cased_Box 							{ quality = 1; price = 130; };
	class 200Rnd_65x39_cased_Box_Tracer 					{ quality = 1; price = 130; };
	class 20Rnd_556x45_UW_mag 								{ quality = 1; price = 120; };
	class 20Rnd_762x51_Mag 									{ quality = 1; price = 120; };
	class 30Rnd_45ACP_Mag_SMG_01 							{ quality = 1; price = 110; };
	class 30Rnd_45ACP_Mag_SMG_01_Tracer_Green 				{ quality = 1; price = 110; };
	class 30Rnd_45ACP_Mag_SMG_01_Tracer_Red					{ quality = 1; price = 110; };
	class 30Rnd_45ACP_Mag_SMG_01_Tracer_Yellow				{ quality = 1; price = 110; };
	class 30Rnd_556x45_Stanag 								{ quality = 1; price = 120; };
	class 30Rnd_556x45_Stanag_Tracer_Green 					{ quality = 1; price = 120; };
	class 30Rnd_556x45_Stanag_Tracer_Red 					{ quality = 1; price = 120; };
	class 30Rnd_556x45_Stanag_Tracer_Yellow 				{ quality = 1; price = 120; };
	class 30Rnd_556x45_Stanag_green  						{ quality = 1; price = 120; };
	class 30Rnd_556x45_Stanag_red 							{ quality = 1; price = 120; };
	class 30Rnd_65x39_caseless_green 						{ quality = 1; price = 120; };
	class 30Rnd_65x39_caseless_green_mag_Tracer 			{ quality = 1; price = 130; };
	class 30Rnd_65x39_caseless_mag 							{ quality = 1; price = 120; };
	class 30Rnd_65x39_caseless_mag_Tracer 					{ quality = 1; price = 130; };
	class 30Rnd_9x21_Green_Mag								{ quality = 1; price = 140; };
	class 30Rnd_9x21_Mag 									{ quality = 1; price = 140; };
	class 30Rnd_9x21_Red_Mag								{ quality = 1; price = 140; };
	class 30Rnd_9x21_Yellow_Mag								{ quality = 1; price = 140; };
	class 5Rnd_127x108_APDS_Mag 							{ quality = 1; price = 150; };
	class 5Rnd_127x108_Mag 									{ quality = 1; price = 140; };
	class 6Rnd_45ACP_Cylinder 								{ quality = 1; price = 180; };
	class 6Rnd_GreenSignal_F 								{ quality = 1; price = 130; };
	class 6Rnd_RedSignal_F 									{ quality = 1; price = 130; };
	class 7Rnd_408_Mag 										{ quality = 1; price = 110; };
	class 9Rnd_45ACP_Mag 									{ quality = 1; price = 160; };
	// Price for bullet cam magazines is normal magazine price + 20 pop tabs per bullet
	class Exile_Magazine_10Rnd_127x99_m107_Bullet_Cam_Mag 		{ quality = 1; price = 140 + 10 * 20; };
	class Exile_Magazine_10Rnd_338_Bullet_Cam_Mag 				{ quality = 1; price = 130 + 10 * 20; };
	class Exile_Magazine_10Rnd_93x64_DMR_05_Bullet_Cam_Mag 		{ quality = 1; price = 140 + 10 * 20; };
	class Exile_Magazine_5Rnd_127x108_APDS_Bullet_Cam_Mag 		{ quality = 1; price = 140 +  5 * 20; };
	class Exile_Magazine_5Rnd_127x108_APDS_KSVK_Bullet_Cam_Mag 	{ quality = 1; price = 140 +  5 * 20; };
	class Exile_Magazine_5Rnd_127x108_Bullet_Cam_Mag 			{ quality = 1; price = 140 +  5 * 20; };
	class Exile_Magazine_5Rnd_127x108_KSVK_Bullet_Cam_Mag 		{ quality = 1; price = 140 +  5 * 20; };
	class Exile_Magazine_7Rnd_408_Bullet_Cam_Mag 				{ quality = 1; price = 110 +  7 * 20; };
	///////////////////////////////////////////////////////////////////////////////
	// Exile ArmA 2
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Magazine_100Rnd_762x54_PK_Green			    { quality = 1; price = 120; };
	class Exile_Magazine_10Rnd_127x99_m107				    { quality = 1; price = 130; };
	class Exile_Magazine_10Rnd_303						    { quality = 1; price = 120; };
	class Exile_Magazine_10Rnd_762x54					    { quality = 1; price = 120; };
	class Exile_Magazine_10Rnd_765x17_SA61				    { quality = 1; price = 110; };
	class Exile_Magazine_10Rnd_9x39						    { quality = 1; price = 120; };
	class Exile_Magazine_20Rnd_762x51_DMR				    { quality = 1; price = 120; };
	class Exile_Magazine_20Rnd_762x51_DMR_Green			    { quality = 1; price = 120; };
	class Exile_Magazine_20Rnd_762x51_DMR_Red			    { quality = 1; price = 120; };
	class Exile_Magazine_20Rnd_762x51_DMR_Yellow		    { quality = 1; price = 120; };
	class Exile_Magazine_20Rnd_765x17_SA61				    { quality = 1; price = 120; };
	class Exile_Magazine_20Rnd_9x39						    { quality = 1; price = 120; };
	class Exile_Magazine_30Rnd_545x39_AK				    { quality = 1; price = 120; };
	class Exile_Magazine_30Rnd_545x39_AK_Green			    { quality = 1; price = 120; };
	class Exile_Magazine_30Rnd_545x39_AK_Red			    { quality = 1; price = 120; };
	class Exile_Magazine_30Rnd_545x39_AK_White			    { quality = 1; price = 120; };
	class Exile_Magazine_30Rnd_545x39_AK_Yellow			    { quality = 1; price = 120; };
	class Exile_Magazine_30Rnd_762x39_AK				    { quality = 1; price = 120; };
	class Exile_Magazine_45Rnd_545x39_RPK_Green			    { quality = 1; price = 120; };
	class Exile_Magazine_5Rnd_127x108_APDS_KSVK			    { quality = 1; price = 5140; };
	class Exile_Magazine_5Rnd_127x108_KSVK				    { quality = 1; price = 5130; };
	class Exile_Magazine_5Rnd_22LR						    { quality = 1; price = 7120; };
	class Exile_Magazine_6Rnd_45ACP						    { quality = 1; price = 120; };
	class Exile_Magazine_75Rnd_545x39_RPK_Green			    { quality = 1; price = 120; };
	class Exile_Magazine_7Rnd_45ACP						    { quality = 1; price = 120; };
	class Exile_Magazine_8Rnd_74Pellets					    { quality = 1; price = 120; }; // broken?
	class Exile_Magazine_8Rnd_74Slug					    { quality = 1; price = 120; };
	class Exile_Magazine_8Rnd_9x18						    { quality = 1; price = 120; };
	////////////////////////////////////////////////////////////////////////////////
	//CUP
	////////////////////////////////////////////////////////////////////////////////
	class CUP_100Rnd_TE4_Green_Tracer_556x45_M249			{ quality = 1; price = 150; };
	class CUP_100Rnd_TE4_LRT4_White_Tracer_762x51_Belt_M    { quality = 1; price = 150; };
	class CUP_100Rnd_TE4_Red_Tracer_556x45_M249				{ quality = 1; price = 150; };
	class CUP_100Rnd_TE4_Yellow_Tracer_556x45_M249			{ quality = 1; price = 150; };
	class CUP_200Rnd_TE1_Red_Tracer_556x45_M249				{ quality = 1; price = 150; };
	class CUP_200Rnd_TE4_Green_Tracer_556x45_L110A1			{ quality = 1; price = 150; };
	class CUP_200Rnd_TE4_Red_Tracer_556x45_L110A1			{ quality = 1; price = 150; };
	class CUP_200Rnd_TE4_Red_Tracer_556x45_M249				{ quality = 1; price = 150; };
	class CUP_200Rnd_TE4_Yellow_Tracer_556x45_L110A1		{ quality = 1; price = 150; };
	class CUP_200Rnd_TE4_Yellow_Tracer_556x45_M249			{ quality = 1; price = 150; };
	class CUP_50Rnd_UK59_762x54R_Tracer						{ quality = 1; price = 150; };
	///////////////////////////////////////////////////////////////////////////////1//
	class CUP_20Rnd_B_765x17_Ball_M							{ quality = 1; price = 110; };
	class CUP_30Rnd_9x19_EVO								{ quality = 1; price = 110; };
	class CUP_30Rnd_9x19_MP5								{ quality = 1; price = 110; };
	class CUP_30Rnd_9x19_UZI								{ quality = 1; price = 110; };
	class CUP_64Rnd_9x19_Bizon_M							{ quality = 1; price = 120; };
	class CUP_64Rnd_Green_Tracer_9x19_Bizon_M				{ quality = 1; price = 120; };
	class CUP_64Rnd_Red_Tracer_9x19_Bizon_M					{ quality = 1; price = 120; };
	class CUP_64Rnd_White_Tracer_9x19_Bizon_M				{ quality = 1; price = 120; };
	class CUP_64Rnd_Yellow_Tracer_9x19_Bizon_M				{ quality = 1; price = 120; };
	///////////////////////////////////////////////////////////////////////////////
	// RHS
	///////////////////////////////////////////////////////////////////////////////
	class rhsusf_mag_7x45acp_MHP                    		{ quality = 1; price = 60; };
	class rhs_mag_9x18_12_57N181S                   		{ quality = 1; price = 60; };
	class rhs_mag_9x19_17                         			{ quality = 1; price = 60; };
	//US
	class rhs_mag_30Rnd_556x45_Mk318_Stanag					{ quality = 1; price = 135; };
	class rhs_mag_30Rnd_556x45_Mk262_Stanag					{ quality = 1; price = 140; };
	class rhs_mag_30Rnd_556x45_M855A1_Stanag				{ quality = 1; price = 130; };
	class rhs_mag_30Rnd_556x45_M855A1_Stanag_No_Tracer		{ quality = 1; price = 130; };
	class rhs_mag_30Rnd_556x45_M855A1_Stanag_Tracer_Red		{ quality = 1; price = 130; };
	class rhs_mag_30Rnd_556x45_M855A1_Stanag_Tracer_Green	{ quality = 1; price = 130; };
	class rhs_mag_30Rnd_556x45_M855A1_Stanag_Tracer_Yellow	{ quality = 1; price = 130; };
	class rhs_200rnd_556x45_M_SAW							{ quality = 1; price = 220; };
	class rhs_200rnd_556x45_B_SAW							{ quality = 1; price = 220; };
	class rhs_200rnd_556x45_T_SAW							{ quality = 1; price = 220; };
	class rhsusf_50Rnd_762x51								{ quality = 1; price = 150; };
	class rhsusf_50Rnd_762x51_m993							{ quality = 1; price = 150; };
	class rhsusf_50Rnd_762x51_m80a1epr						{ quality = 1; price = 195; };
	class rhsusf_100Rnd_762x51								{ quality = 1; price = 195; };
	class rhsusf_100Rnd_762x51_m993							{ quality = 1; price = 195; };
	class rhsusf_100Rnd_762x51_m80a1epr						{ quality = 1; price = 195; };
	class rhsusf_8Rnd_00Buck								{ quality = 1; price = 140; };
	class rhsusf_8Rnd_Slug									{ quality = 1; price = 150; };
	class rhsusf_20Rnd_762x51_m993_Mag						{ quality = 1; price = 145; };
	class rhsusf_5Rnd_300winmag_xm2010						{ quality = 1; price = 5155; };
	//Russian                                                                      1
	class rhs_30Rnd_762x39mm								{ quality = 1; price = 120; };
	class rhs_30Rnd_762x39mm_tracer							{ quality = 1; price = 120; };
	class rhs_30Rnd_762x39mm_89								{ quality = 1; price = 120; };
	class rhs_30Rnd_545x39_AK								{ quality = 1; price = 120; };
	class rhs_30Rnd_545x39_AK_no_tracers					{ quality = 1; price = 120; };
	class rhs_30Rnd_545x39_7N10_AK							{ quality = 1; price = 120; };
	class rhs_30Rnd_545x39_7N22_AK							{ quality = 1; price = 120; };
	class rhs_30Rnd_545x39_AK_green							{ quality = 1; price = 120; };
	class rhs_45Rnd_545X39_AK								{ quality = 1; price = 140; };
	class rhs_45Rnd_545X39_7N10_AK							{ quality = 1; price = 140; };
	class rhs_45Rnd_545X39_7N22_AK							{ quality = 1; price = 140; };
	class rhs_45Rnd_545X39_AK_Green							{ quality = 1; price = 140; };
	class rhs_100Rnd_762x54mmR								{ quality = 1; price = 195; };
	class rhs_100Rnd_762x54mmR_green						{ quality = 1; price = 195; };
	class rhs_10Rnd_762x54mmR_7N1							{ quality = 1; price = 150; };
	//50 Cal
	class rhsusf_mag_10Rnd_STD_50BMG_M33				    { quality = 1; price = 6200; };
	class rhsusf_mag_10Rnd_STD_50BMG_mk211				    { quality = 1; price = 6500; };
	//MP7                                                   
	class rhsusf_mag_40Rnd_46x30_AP 					    { quality = 1; price = 60; };
	class rhsusf_mag_40Rnd_46x30_FMJ 					    { quality = 1; price = 60; };
	class rhsusf_mag_40Rnd_46x30_JHP 					    { quality = 1; price = 60; };
	//T-5000                                                
	class rhs_5Rnd_338lapua_t5000 						    { quality = 1; price = 80; };
	//M590                                                  
	class rhsusf_5Rnd_00Buck 							    { quality = 1; price = 40; };
	class rhsusf_5Rnd_FRAG 								    { quality = 1; price = 70; };
	class rhsusf_5Rnd_HE 								    { quality = 1; price = 70; };
	class rhsusf_5Rnd_Slug 								    { quality = 1; price = 50; };
	class rhsusf_8Rnd_doomsday_Buck 					    { quality = 1; price = 100; };
	//M24 SWS                                               
	class rhsusf_5Rnd_762x51_m118_special_Mag 			    { quality = 1; price = 60; };
	class rhsusf_5Rnd_762x51_m993_Mag 					    { quality = 1; price = 60; };
	class rhsusf_5Rnd_762x51_m62_Mag 					    { quality = 1; price = 60; };
	//M40A5                                                 
	class rhsusf_10Rnd_762x51_m62_Mag 					    { quality = 1; price = 60; };
	class rhsusf_10Rnd_762x51_m993_Mag 					    { quality = 1; price = 60; };
	class rhsusf_10Rnd_762x51_m118_special_Mag 			    { quality = 1; price = 60; };
	//M9                                                    
	class rhsusf_mag_15Rnd_9x19_FMJ						    { quality = 1; price = 20; };
	class rhsusf_mag_15Rnd_9x19_JHP						    { quality = 1; price = 20; };
	// Glock                                                
	class rhsusf_mag_17Rnd_9x19_JHP 					    { quality = 1; price = 20; };
	class rhsusf_mag_17Rnd_9x19_FMJ 					    { quality = 1; price = 20; };
	// PM                                                   
	class rhs_mag_9x18_8_57N181S 						    { quality = 1; price = 20; };
	//PP2000                                                
	class rhs_mag_9x19mm_7n31_44 						    { quality = 1; price = 50; };
	class rhs_mag_9x19mm_7n21_44 						    { quality = 1; price = 50; };
	class rhs_mag_9x19mm_7n31_20 						    { quality = 1; price = 20; };
	class rhs_mag_9x19mm_7n21_20 						    { quality = 1; price = 20; };

	///////////////////////////////////////////////////////////////////////////////
	// Pistols // Пистолеты
	///////////////////////////////////////////////////////////////////////////////
	// Apex
	///////////////////////////////////////////////////////////////////////////////
	class hgun_P07_khk_F              				        { quality = 1; price = 265; };
	class hgun_Pistol_01_F							        { quality = 1; price = 265; };
	///////////////////////////////////////////////////////////////////////////////
	// CUP
	///////////////////////////////////////////////////////////////////////////////
	class CUP_hgun_Colt1911									{ quality = 1; price = 200; };
	class CUP_hgun_Compact									{ quality = 1; price = 200; };
	class CUP_hgun_Duty										{ quality = 1; price = 200; };
	class CUP_hgun_Glock17									{ quality = 1; price = 200; };
	class CUP_hgun_M9										{ quality = 1; price = 200; };
	class CUP_hgun_Makarov									{ quality = 1; price = 200; };
	class CUP_hgun_MicroUzi									{ quality = 1; price = 200; };
	class CUP_hgun_PB6P9									{ quality = 1; price = 200; };
	class CUP_hgun_Phantom									{ quality = 1; price = 200; };
	class CUP_hgun_SA61										{ quality = 1; price = 200; };
	class CUP_hgun_TaurusTracker455							{ quality = 1; price = 200; };
	class CUP_hgun_TaurusTracker455_gold					{ quality = 1; price = 200; };
/*	class CUP_hgun_Colt1911_snds							{ quality = 1; price = 200; }; // Dupe bug
	class CUP_hgun_Duty_M3X									{ quality = 1; price = 200; }; // Dupe bug
	class CUP_hgun_M9_snds									{ quality = 1; price = 200; }; // Dupe bug
	class CUP_hgun_MicroUzi_snds							{ quality = 1; price = 200; }; // Dupe bug
	class CUP_hgun_PB6P9_snds								{ quality = 1; price = 200; }; // Dupe bug
	class CUP_hgun_Phantom_Flashlight						{ quality = 1; price = 200; }; // Dupe bug
	class CUP_hgun_Phantom_Flashlight_snds					{ quality = 1; price = 200; }; // Dupe bug
	class CUP_hgun_glock17_flashlight						{ quality = 1; price = 200; }; // Dupe bug
	class CUP_hgun_glock17_flashlight_snds					{ quality = 1; price = 200; }; // Dupe bug
	class CUP_hgun_glock17_snds								{ quality = 1; price = 200; }; // Dupe bug */
	///////////////////////////////////////////////////////////////////////////////
	// Exile
	///////////////////////////////////////////////////////////////////////////////
	class hgun_ACPC2_F 								        { quality = 1; price = 250; };
	class hgun_P07_F 								        { quality = 1; price = 250; };
	class hgun_Pistol_Signal_F 						        { quality = 1; price = 300; };
	class hgun_Pistol_heavy_01_F 					        { quality = 2; price = 280; };
	class hgun_Pistol_heavy_02_F 					        { quality = 2; price = 280; };
	class hgun_Rook40_F 							        { quality = 1; price = 250; };
	///////////////////////////////////////////////////////////////////////////////
	// RHS
	///////////////////////////////////////////////////////////////////////////////
	class rhs_weap_pya 							            { quality = 1; price = 150; };
	class rhs_weap_makarov_pm 					            { quality = 1; price = 150; };
	// Added by ElShotte                                    
	class rhsusf_weap_glock17g4 				            { quality = 3; price = 250; };
	class rhsusf_weap_m9 						            { quality = 3; price = 250; };
	class rhsusf_weap_m1911a1 					            { quality = 3; price = 250; };
	class rhs_weap_pp2000_folded 				            { quality = 2; price = 350; };

	///////////////////////////////////////////////////////////////////////////////
	// Assault Rifles // Штурмовые винтовки
	///////////////////////////////////////////////////////////////////////////////
	// Apex
	///////////////////////////////////////////////////////////////////////////////
	class arifle_AK12_F               				        { quality = 3; price = 850; };
	class arifle_AK12_GL_F            				        { quality = 3; price = 850; };
	class arifle_AKM_F                				        { quality = 3; price = 800; };
	class arifle_AKM_FL_F             				        { quality = 3; price = 800; };
	class arifle_AKS_F                				        { quality = 3; price = 950; };
	class arifle_ARX_blk_F            				        { quality = 5; price = 900; };
	class arifle_ARX_ghex_F           				        { quality = 5; price = 900; };
	class arifle_ARX_hex_F            				        { quality = 5; price = 900; };
	class arifle_CTARS_blk_F          				        { quality = 2; price = 850; };
	class arifle_CTARS_ghex_F         				        { quality = 2; price = 850; };
	class arifle_CTARS_hex_F          				        { quality = 2; price = 850; };
	class arifle_CTAR_GL_blk_F        				        { quality = 2; price = 850; };
	class arifle_CTAR_blk_F           				        { quality = 2; price = 850; };
	class arifle_CTAR_ghex_F          				        { quality = 2; price = 850; };
	class arifle_CTAR_hex_F           				        { quality = 2; price = 850; };
	class arifle_MXC_khk_F            				        { quality = 2; price = 750; };
	class arifle_MXM_khk_F            				        { quality = 2; price = 800; };
	class arifle_MX_GL_khk_F          				        { quality = 2; price = 800; };
	class arifle_MX_khk_F             				        { quality = 2; price = 750; };
	class arifle_SPAR_01_GL_blk_F     				        { quality = 1; price = 1000; };
	class arifle_SPAR_01_GL_khk_F     				        { quality = 1; price = 1000; };
	class arifle_SPAR_01_GL_snd_F     				        { quality = 1; price = 1000; };
	class arifle_SPAR_01_blk_F        				        { quality = 1; price = 800; };
	class arifle_SPAR_01_khk_F        				        { quality = 1; price = 800; };
	class arifle_SPAR_01_snd_F        				        { quality = 1; price = 800; };
	class arifle_SPAR_02_blk_F        				        { quality = 2; price = 850; };
	class arifle_SPAR_02_khk_F        				        { quality = 2; price = 850; };
	class arifle_SPAR_02_snd_F        				        { quality = 2; price = 850; };
	class arifle_SPAR_03_blk_F        				        { quality = 3; price = 800; };
	class arifle_SPAR_03_khk_F        				        { quality = 3; price = 800; };
	class arifle_SPAR_03_snd_F        				        { quality = 3; price = 800; };
	///////////////////////////////////////////////////////////////////////////////
	// CUP
	///////////////////////////////////////////////////////////////////////////////
	class CUP_arifle_AK107									{ quality = 2; price = 800; };
	class CUP_arifle_AK107_GL								{ quality = 2; price = 800; };
	class CUP_arifle_AK74									{ quality = 2; price = 800; };
	class CUP_arifle_AK74_GL								{ quality = 2; price = 800; };
	class CUP_arifle_AKM									{ quality = 2; price = 800; };
	class CUP_arifle_AKS									{ quality = 2; price = 800; };
	class CUP_arifle_AKS74									{ quality = 2; price = 800; };
	class CUP_arifle_AKS74U									{ quality = 2; price = 800; };
	class CUP_arifle_AKS_Gold								{ quality = 2; price = 800; };
	class CUP_arifle_CZ805_A1								{ quality = 2; price = 800; };
	class CUP_arifle_CZ805_A2								{ quality = 2; price = 800; };
	class CUP_arifle_CZ805_B								{ quality = 2; price = 800; };
	class CUP_arifle_CZ805_B_GL								{ quality = 2; price = 800; };
	class CUP_arifle_CZ805_GL								{ quality = 2; price = 800; };
	class CUP_arifle_FNFAL									{ quality = 2; price = 800; };
	class CUP_arifle_FNFAL_railed							{ quality = 2; price = 800; };
	class CUP_arifle_G36A									{ quality = 2; price = 800; };
	class CUP_arifle_G36A_camo								{ quality = 2; price = 800; };
	class CUP_arifle_G36C									{ quality = 2; price = 800; };
	class CUP_arifle_G36C_camo								{ quality = 2; price = 800; };
	class CUP_arifle_G36K									{ quality = 2; price = 800; };
	class CUP_arifle_G36K_camo								{ quality = 2; price = 800; };
	class CUP_arifle_L85A2									{ quality = 2; price = 800; };
	class CUP_arifle_L85A2_GL								{ quality = 2; price = 800; };
	class CUP_arifle_L86A2									{ quality = 2; price = 800; };
	class CUP_arifle_M16A2									{ quality = 2; price = 800; };
	class CUP_arifle_M16A2_GL								{ quality = 2; price = 800; };
	class CUP_arifle_M16A4GL								{ quality = 2; price = 800; };
	class CUP_arifle_M16A4_Base								{ quality = 2; price = 800; };
	class CUP_arifle_M16A4_GL								{ quality = 2; price = 800; };
	class CUP_arifle_M4A1									{ quality = 2; price = 800; };
	class CUP_arifle_M4A1_BUIS_GL							{ quality = 2; price = 800; };
	class CUP_arifle_M4A1_BUIS_camo_GL						{ quality = 2; price = 800; };
	class CUP_arifle_M4A1_BUIS_desert_GL					{ quality = 2; price = 800; };
	class CUP_arifle_M4A1_black								{ quality = 2; price = 800; };
	class CUP_arifle_M4A1_camo								{ quality = 2; price = 800; };
	class CUP_arifle_M4A1_desert							{ quality = 2; price = 800; };
	class CUP_arifle_MG36									{ quality = 2; price = 800; };
	class CUP_arifle_MG36_camo								{ quality = 2; price = 800; };
	class CUP_arifle_Mk16_CQC								{ quality = 2; price = 800; };
	class CUP_arifle_Mk16_CQC_EGLM							{ quality = 2; price = 800; };
	class CUP_arifle_Mk16_CQC_FG							{ quality = 2; price = 800; };
	class CUP_arifle_Mk16_CQC_SFG							{ quality = 2; price = 800; };
	class CUP_arifle_Mk16_STD								{ quality = 2; price = 800; };
	class CUP_arifle_Mk16_STD_EGLM							{ quality = 2; price = 800; };
	class CUP_arifle_Mk16_STD_FG							{ quality = 2; price = 800; };
	class CUP_arifle_Mk16_STD_SFG							{ quality = 2; price = 800; };
	class CUP_arifle_Mk16_SV								{ quality = 2; price = 800; };
	class CUP_arifle_Mk17_CQC								{ quality = 2; price = 800; };
	class CUP_arifle_Mk17_CQC_EGLM							{ quality = 2; price = 800; };
	class CUP_arifle_Mk17_CQC_FG							{ quality = 2; price = 800; };
	class CUP_arifle_Mk17_CQC_SFG							{ quality = 2; price = 800; };
	class CUP_arifle_Mk17_STD								{ quality = 2; price = 800; };
	class CUP_arifle_Mk17_STD_EGLM							{ quality = 2; price = 800; };
	class CUP_arifle_Mk17_STD_FG							{ quality = 2; price = 800; };
	class CUP_arifle_Mk17_STD_SFG							{ quality = 2; price = 800; };
	class CUP_arifle_Mk20									{ quality = 2; price = 800; };
	class CUP_arifle_RPK74									{ quality = 2; price = 800; };
	class CUP_arifle_Sa58P									{ quality = 2; price = 800; };
	class CUP_arifle_Sa58P_des								{ quality = 2; price = 800; };
	class CUP_arifle_Sa58RIS1								{ quality = 2; price = 800; };
	class CUP_arifle_Sa58RIS2								{ quality = 2; price = 800; };
	class CUP_arifle_Sa58RIS2_camo							{ quality = 2; price = 800; };
	class CUP_arifle_Sa58V									{ quality = 2; price = 800; };
	class CUP_arifle_Sa58V_camo								{ quality = 2; price = 800; };
	class CUP_arifle_XM8_Carbine							{ quality = 2; price = 800; };
	class CUP_arifle_XM8_Carbine_FG							{ quality = 2; price = 800; };
	class CUP_arifle_XM8_Carbine_GL							{ quality = 2; price = 800; };
	class CUP_arifle_XM8_Compact							{ quality = 2; price = 800; };
	class CUP_arifle_XM8_Compact_Rail						{ quality = 2; price = 800; };
	class CUP_arifle_XM8_Railed								{ quality = 2; price = 800; };
	class CUP_arifle_xm8_SAW								{ quality = 2; price = 800; };
	class CUP_arifle_xm8_sharpshooter						{ quality = 2; price = 800; };
	class CUP_sgun_AA12										{ quality = 2; price = 800; };
	class CUP_sgun_M1014									{ quality = 2; price = 800; };
	class CUP_sgun_Saiga12K									{ quality = 2; price = 800; };
/*	class CUP_arifle_AK107_GL_kobra							{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_AK107_GL_pso							{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_AK107_kobra							{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_AK107_pso								{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_AK74_GL_kobra							{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_AKS74UN_kobra_snds						{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_AKS74_Goshawk							{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_AKS74_NSPU								{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_CZ805B_GL_ACOG_Laser					{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_CZ805_A1_Aco_Laser						{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_CZ805_A1_Holo_Laser					{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_CZ805_A1_MRCO_Laser					{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_CZ805_A1_ZDDot_Laser					{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_CZ805_A2_Aco_Laser						{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_CZ805_A2_Holo_Laser					{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_CZ805_A2_MRCO_Laser					{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_CZ805_A2_ZDDot_Flashlight_Snds			{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_CZ805_GL_Hamr_Laser					{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_CZ805_GL_ZDDot_Laser					{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_FNFAL_ANPVS4							{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_G36C_camo_holo_snds					{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_G36C_holo_snds							{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_L85A2_ACOG_Laser						{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_L85A2_CWS_Laser						{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_L85A2_GL_ACOG_Laser					{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_L85A2_GL_Holo_laser					{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_L85A2_GL_SUSAT_Laser					{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_L85A2_Holo_laser						{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_L85A2_SUSAT_Laser						{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_L86A2_ACOG								{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_M16A4_ACOG_Laser						{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_M16A4_Aim_Laser						{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_M16A4_GL_ACOG_Laser					{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_M4A1_Aim								{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_M4A1_GL_ACOG_Flashlight				{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_M4A1_GL_Holo_Flashlight				{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_M4A1_camo_AIM_snds						{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_M4A1_camo_Aim							{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_M4A1_camo_GL_Holo_Flashlight			{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_M4A1_camo_GL_Holo_Flashlight_Snds		{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_M4A3_desert_Aim_Flashlight				{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_M4A3_desert_GL_ACOG_Laser				{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_Mk16_CQC_EGLM_Holo_Laser_mfsup			{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_Mk16_CQC_FG_Aim_Laser_snds				{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_Mk16_CQC_SFG_Holo						{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_Mk16_STD_EGLM_ACOG_Laser				{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_Mk16_STD_EGLM_ANPAS13c1_Laser_mfsup    { quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_Mk16_STD_FG_Holo_Laser					{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_Mk16_STD_FG_LeupoldMk4CQT_Laser		{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_Mk17_CQC_SFG_Aim_mfsup					{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_Mk17_STD_EGL_ElcanSpecter_Laser		{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_Mk17_STD_FG_ANPAS13c1_Laser_Snds		{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_Mk17_STD_FG_Aim_Laser_snds				{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_Mk20_LeupoldMk4MRT						{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_Mk20_SB11420_snds						{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_Sa58RIS1_Aco_Laser						{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_Sa58RIS1_camo_Aco_Laser				{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_Sa58RIS1_des							{ quality = 2; price = 800; };	//may be broken
	class CUP_arifle_Sa58RIS2_Arco_Laser					{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_Sa58RIS2_camo_Arco_Laser				{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_Sa58V_ACOG_Laser						{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_Sa58V_Aim_Laser						{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_XM8_Compact_Holo_Flashlight			{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_XM8_Railed_ANPAS13c1_Laser				{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_XM8_Railed_ANPAS13c1_Laser_snds		{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_XM8_Railed_Holo_Laser_snds				{ quality = 2; price = 800; }; // Dupe bug
	class CUP_arifle_ksvk_PSO3								{ quality = 2; price = 800; }; // Dupe bug */
	///////////////////////////////////////////////////////////////////////////////
	// Exile
	///////////////////////////////////////////////////////////////////////////////
	class arifle_Katiba_C_F							{ quality = 2; price = 850; };
	class arifle_Katiba_F							{ quality = 2; price = 850; };
	class arifle_Katiba_GL_F						{ quality = 2; price = 900; };
	class arifle_Mk20_F								{ quality = 1; price = 850; };
	class arifle_Mk20_GL_F							{ quality = 1; price = 900; };
	class arifle_Mk20_GL_plain_F					{ quality = 1; price = 900; };
	class arifle_Mk20_plain_F						{ quality = 1; price = 850; };
	class arifle_Mk20C_F							{ quality = 1; price = 850; };
	class arifle_Mk20C_plain_F						{ quality = 1; price = 850; };
	class arifle_MX_Black_F							{ quality = 2; price = 950; };
	class arifle_MX_F								{ quality = 2; price = 950; };
	class arifle_MX_GL_Black_F						{ quality = 2; price = 950; };
	class arifle_MX_GL_F							{ quality = 2; price = 950; };
	class arifle_MXC_Black_F						{ quality = 2; price = 850; };
	class arifle_MXC_F								{ quality = 2; price = 850; };
	class arifle_SDAR_F								{ quality = 1; price = 2000; };
	class arifle_TRG20_F							{ quality = 1; price = 850; };
	class arifle_TRG21_F							{ quality = 1; price = 850; };
	class arifle_TRG21_GL_F							{ quality = 1; price = 950; };
	///////////////////////////////////////////////////////////////////////////////
	// Exile ArmA 2
	///////////////////////////////////////////////////////////////////////////////
    class Exile_Weapon_AK107						{ quality = 1; price = 800; };
	class Exile_Weapon_AK107_GL						{ quality = 2; price = 900; };
	class Exile_Weapon_AK74							{ quality = 2; price = 850; };
	class Exile_Weapon_AK74_GL						{ quality = 2; price = 950; };
	class Exile_Weapon_AK47							{ quality = 3; price = 800; };
	class Exile_Weapon_AKM							{ quality = 3; price = 800; };
	class Exile_Weapon_AKS							{ quality = 3; price = 800; };
	class Exile_Weapon_AKS_Gold						{ quality = 3; price = 1200; };
	class Exile_Weapon_DMR							{ quality = 3; price = 950; };
	class Exile_Weapon_LeeEnfield					{ quality = 1; price = 850; };
	class Exile_Weapon_CZ550						{ quality = 2; price = 500; };
	class Exile_Weapon_SVD							{ quality = 4; price = 11500; };
	class Exile_Weapon_SVDCamo						{ quality = 4; price = 11500; };
	class Exile_Weapon_VSSVintorez					{ quality = 3; price = 11200; };
	class Exile_Weapon_RPK							{ quality = 2; price = 11200; };
	class Exile_Weapon_PK							{ quality = 3; price = 1200; };
	class Exile_Weapon_PKP							{ quality = 3; price = 11250; };
	class Exile_Weapon_Colt1911						{ quality = 1; price = 300; };
	class Exile_Weapon_Makarov						{ quality = 1; price = 300; };
	class Exile_Weapon_Taurus						{ quality = 1; price = 300; };
	class Exile_Weapon_TaurusGold					{ quality = 1; price = 350; };
	class Exile_Weapon_M1014						{ quality = 2; price = 300; };
	class Exile_Weapon_SA61							{ quality = 1; price = 350; };
	class Exile_Weapon_m107							{ quality = 5; price = 212400; };
	class Exile_Weapon_ksvk							{ quality = 5; price = 102600; };
	//class ksvk									{ quality = 5; price = 2500; };
	class Exile_Weapon_M4							{ quality = 2; price = 850; };
	class Exile_Weapon_M16A4						{ quality = 2; price = 850; };
	class Exile_Weapon_M16A2						{ quality = 1; price = 800; };

	///////////////////////////////////////////////////////////////////////////////
	// RHS
	///////////////////////////////////////////////////////////////////////////////
	/*	// Exile Dupe issue items un comment at your own risk
	class rhs_weap_ak103							        { quality = 1; price = 450; };
	class rhs_weap_ak103_1							        { quality = 1; price = 450; };
	class rhs_weap_ak103_npz						        { quality = 1; price = 450; };
	class rhs_weap_ak74m							        { quality = 1; price = 450; };
	class rhs_weap_ak74m_2mag						        { quality = 1; price = 450; };
	class rhs_weap_ak74m_2mag_camo					        { quality = 2; price = 400; };
	class rhs_weap_ak74m_2mag_npz					        { quality = 1; price = 400; };
	class rhs_weap_ak74m_camo						        { quality = 2; price = 400; };
	class rhs_weap_ak74m_camo_folded				        { quality = 1; price = 450; };
	class rhs_weap_ak74m_desert						        { quality = 2; price = 400; };
	class rhs_weap_ak74m_desert_folded				        { quality = 1; price = 450; };
	class rhs_weap_ak74m_desert_npz					        { quality = 2; price = 450; };
	class rhs_weap_ak74m_folded						        { quality = 1; price = 450; };
	class rhs_weap_ak74m_gp25						        { quality = 2; price = 600; };
	class rhs_weap_ak74m_gp25_npz					        { quality = 2; price = 600; };
	class rhs_weap_ak74m_npz						        { quality = 1; price = 400; };
	class rhs_weap_ak74m_plummag					        { quality = 2; price = 450; };
	class rhs_weap_ak74m_plummag_folded				        { quality = 1; price = 450; };
	class rhs_weap_ak74m_plummag_npz				        { quality = 2; price = 400; };
	class rhs_weap_ak74mr 							        { quality = 3; price = 550; };
	class rhs_weap_ak74mr_gp25						        { quality = 3; price = 700; };
	class rhs_weap_akm								        { quality = 1; price = 450; };
	class rhs_weap_akm_gp25							        { quality = 1; price = 650; };
	class rhs_weap_akms								        { quality = 1; price = 450; };
	class rhs_weap_akms_gp25						        { quality = 1; price = 600; };
	class rhs_weap_aks74 							        { quality = 1; price = 400; };
	class rhs_weap_m16a4_carryhandle_grip			        { quality = 2; price = 400; };
	class rhs_weap_m16a4_carryhandle_grip_pmag		        { quality = 2; price = 400; };
	class rhs_weap_m16a4_grip						        { quality = 1; price = 350; };
	class rhs_weap_m4								        { quality = 1; price = 350; };
	class rhs_weap_m4_grip2							        { quality = 2; price = 400; };
	class rhs_weap_m4a1_blockII_grip2				        { quality = 3; price = 500; };
	class rhs_weap_m4a1_blockII_grip2_KAC			        { quality = 3; price = 500; };
	class rhs_weap_m4a1_carryhandle_grip2			        { quality = 2; price = 400; };
	class rhs_weap_m4a1_grip						        { quality = 2; price = 400; };
	class rhs_weap_m4a1_grip2						        { quality = 2; price = 400; };
	class rhs_weap_mk18_grip2						        { quality = 3; price = 500; };
	class rhs_weap_mk18_grip2_KAC					        { quality = 3; price = 500; };
	class rhs_weap_aks74_gp25 						        { quality = 1; price = 550; };
	class rhs_weap_aks74n							        { quality = 1; price = 500; };
	class rhs_weap_aks74n_gp25						        { quality = 1; price = 600; };
	class rhs_weap_m4_grip							        { quality = 2; price = 400; };
	*/
	class rhs_weap_ak103_zenitco01					        { quality = 3; price = 500; };
	class rhs_weap_ak103_zenitco01_b33				        { quality = 4; price = 600; };
	class rhs_weap_ak104_zenitco01					        { quality = 3; price = 500; };
	class rhs_weap_ak104_zenitco01_b33				        { quality = 4; price = 600; };
	class rhs_weap_ak105_zenitco01					        { quality = 3; price = 500; };
	class rhs_weap_ak105_zenitco01_b33				        { quality = 4; price = 600; };
	class rhs_weap_ak74m_zenitco01					        { quality = 3; price = 500; };
	class rhs_weap_ak74m_zenitco01_b33				        { quality = 4; price = 500; };
	class rhs_weap_akm_zenitco01_b33				        { quality = 4; price = 600; };	
	class rhs_weap_hk416d10 						        { quality = 3; price = 850; };
	class rhs_weap_hk416d10_LMT 					        { quality = 3; price = 850; };
	class rhs_weap_hk416d10_m320 					        { quality = 4; price = 950; };
	class rhs_weap_hk416d145 						        { quality = 3; price = 850; };
	class rhs_weap_hk416d145_m320 					        { quality = 4; price = 950; };
	class rhs_weap_m16a4							        { quality = 1; price = 750; };
	class rhs_weap_m16a4_carryhandle				        { quality = 1; price = 750; };
	class rhs_weap_m16a4_carryhandle_M203			        { quality = 2; price = 800; };
	class rhs_weap_m16a4_carryhandle_pmag			        { quality = 2; price = 800; };
	class rhs_weap_m27iar 							        { quality = 3; price = 900; };
	class rhs_weap_m4_carryhandle					        { quality = 1; price = 750; };
	class rhs_weap_m4_carryhandle_pmag				        { quality = 1; price = 750; };
	class rhs_weap_m4_m203							        { quality = 3; price = 850; };
	class rhs_weap_m4_m320							        { quality = 3; price = 850; };
	class rhs_weap_m4a1								        { quality = 1; price = 750; };
	class rhs_weap_m4a1_blockII						        { quality = 3; price = 800; };
	class rhs_weap_m4a1_blockII_KAC					        { quality = 3; price = 800; };
	class rhs_weap_m4a1_blockII_KAC_bk 				        { quality = 3; price = 850; };
	class rhs_weap_m4a1_blockII_KAC_d 				        { quality = 3; price = 850; };
	class rhs_weap_m4a1_blockII_KAC_wd 				        { quality = 3; price = 850; };
	class rhs_weap_m4a1_blockII_M203				        { quality = 3; price = 800; };
	class rhs_weap_m4a1_blockII_M203_bk 			        { quality = 4; price = 950; };
	class rhs_weap_m4a1_blockII_M203_d 				        { quality = 4; price = 950; };
	class rhs_weap_m4a1_blockII_M203_wd 			        { quality = 4; price = 950; };
	class rhs_weap_m4a1_blockII_bk 					        { quality = 3; price = 800; };
	class rhs_weap_m4a1_blockII_d 					        { quality = 3; price = 800; };
	class rhs_weap_m4a1_blockII_wd 					        { quality = 3; price = 800; };
	class rhs_weap_m4a1_carryhandle					        { quality = 1; price = 750; };
	class rhs_weap_m4a1_carryhandle_m203			        { quality = 3; price = 850; };
	class rhs_weap_m4a1_carryhandle_pmag			        { quality = 1; price = 750; };
	class rhs_weap_m4a1_m203						        { quality = 3; price = 850; };
	class rhs_weap_m4a1_m320						        { quality = 3; price = 850; };
	class rhs_weap_mk18								        { quality = 3; price = 800; };
	class rhs_weap_mk18_KAC							        { quality = 3; price = 800; };
	class rhs_weap_mk18_KAC_bk 						        { quality = 3; price = 850; };
	class rhs_weap_mk18_KAC_d 						        { quality = 3; price = 850; };
	class rhs_weap_mk18_KAC_wd 						        { quality = 3; price = 850; };
	class rhs_weap_mk18_bk 							        { quality = 3; price = 800; };
	class rhs_weap_mk18_d 							        { quality = 3; price = 800; };
	class rhs_weap_mk18_m320						        { quality = 3; price = 800; };
	class rhs_weap_mk18_wd 							        { quality = 3; price = 800; };

	///////////////////////////////////////////////////////////////////////////////
	// Light Machine Gun // Легкий пулемет
	///////////////////////////////////////////////////////////////////////////////
	// Apex
	////////////////////////////////////////////////////////////////////////////////
    class LMG_03_F					  				        { quality = 2; price = 1500; };
	///////////////////////////////////////////////////////////////////////////////
	// CUP
	///////////////////////////////////////////////////////////////////////////////
	class CUP_lmg_L110A1									{ quality = 3; price = 1000; };
	class CUP_lmg_L7A2										{ quality = 3; price = 1000; };
	class CUP_lmg_M240										{ quality = 3; price = 11000; };
	class CUP_lmg_M249										{ quality = 3; price = 12000; };
	class CUP_lmg_M249_para									{ quality = 3; price = 12000; };
	class CUP_lmg_Mk48_des									{ quality = 3; price = 7000; };
	class CUP_lmg_Mk48_wdl									{ quality = 3; price = 7000; };
	class CUP_lmg_PKM										{ quality = 3; price = 11000; };
	class CUP_lmg_Pecheneg									{ quality = 3; price = 10000; };
	class CUP_lmg_UK59										{ quality = 3; price = 13000; };
/*	class CUP_lmg_L110A1_Aim_Laser							{ quality = 3; price = 1000; }; // Dupe bug
	class CUP_lmg_M240_ElcanM143							{ quality = 3; price = 1000; }; // Dupe bug
	class CUP_lmg_M249_ANPAS13c2_Laser						{ quality = 3; price = 1000; }; // Dupe bug
	class CUP_lmg_M249_ElcanM145_Laser						{ quality = 3; price = 1000; }; // Dupe bug
	class CUP_lmg_M249_Laser								{ quality = 3; price = 1000; }; // Dupe bug
	class CUP_lmg_M60A4										{ quality = 3; price = 1000; }; // Dupe bug
	class CUP_lmg_Mk48_des_Aim_Laser						{ quality = 3; price = 1000; }; // Dupe bug
	class CUP_lmg_Mk48_wdl_Aim_Laser						{ quality = 3; price = 1000; }; // Dupe bug
	class CUP_lmg_Pecheneg_PScope							{ quality = 3; price = 1000; }; // Dupe bug */
	///////////////////////////////////////////////////////////////////////////////
	// Exile
	///////////////////////////////////////////////////////////////////////////////
	class LMG_Mk200_F								        { quality = 2; price = 6800; };
	class LMG_Zafir_F								        { quality = 3; price = 7850; };
	class MMG_01_hex_F								        { quality = 6; price = 58550; };
	class MMG_01_tan_F								        { quality = 6; price = 58550; };
	class MMG_02_black_F							        { quality = 6; price = 58550; };
	class MMG_02_camo_F								        { quality = 6; price = 58500; };
	class MMG_02_sand_F								        { quality = 6; price = 58500; };
	class arifle_MX_SW_Black_F						        { quality = 2; price = 3750; };
	class arifle_MX_SW_F							        { quality = 2; price = 3750; };
	///////////////////////////////////////////////////////////////////////////////
	// RHS
	///////////////////////////////////////////////////////////////////////////////
	//US
	class rhs_weap_m249_pip_L						        { quality = 3; price = 11050; };
	class rhs_weap_m249_pip_L_para					        { quality = 3; price = 11050; };
	class rhs_weap_m249_pip_L_vfg					        { quality = 3; price = 11050; };
	class rhs_weap_m249_pip_S						        { quality = 3; price = 11050; };
	class rhs_weap_m249_pip_S_para					        { quality = 3; price = 12050; };
	class rhs_weap_m249_pip_S_vfg					        { quality = 3; price = 11050; };
	class rhs_weap_m240B							        { quality = 3; price = 11100; };
	class rhs_weap_m240B_CAP						        { quality = 3; price = 11100; };
	class rhs_weap_m240G							        { quality = 3; price = 11100; };
	//Russian                                                           3           1
	class rhs_weap_pkm								        { quality = 3; price = 11100; };
	class rhs_weap_pkp								        { quality = 3; price = 11100; };

	///////////////////////////////////////////////////////////////////////////////
	// Sub Machine Gun // Пистолет-пулемет
	///////////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////////
	// Apex
	/////////////////////////////////////////////////////////////////////////////////
	class SMG_05_F					  				        { quality = 3; price = 1500; };
	///////////////////////////////////////////////////////////////////////////////
	// CUP
	///////////////////////////////////////////////////////////////////////////////
	class CUP_smg_EVO										{ quality = 3; price = 850; };
	class CUP_smg_MP5A5										{ quality = 3; price = 800; };
	class CUP_smg_MP5SD6									{ quality = 3; price = 850; };
	class CUP_smg_bizon										{ quality = 3; price = 800; };
/*	class CUP_smg_EVO_MRad_Flashlight						{ quality = 3; price = 850; }; // Dupe bug
	class CUP_smg_EVO_MRad_Flashlight_Snds					{ quality = 3; price = 850; }; // Dupe bug
	class CUP_smg_bizon_snds								{ quality = 3; price = 800; }; // Dupe bug */
	///////////////////////////////////////////////////////////////////////////////
	// Exile
	///////////////////////////////////////////////////////////////////////////////
	class SMG_01_F 									        { quality = 1; price = 350; };
	class SMG_02_F 									        { quality = 1; price = 350; };
	class hgun_PDW2000_F 							        { quality = 1; price = 300; };
	///////////////////////////////////////////////////////////////////////////////
	// RHS
	///////////////////////////////////////////////////////////////////////////////
	class rhsusf_weap_MP7A2                			        { quality = 2; price = 1200; };
	class rhsusf_weap_MP7A2_desert         			        { quality = 2; price = 1200; };
	class rhsusf_weap_MP7A2_aor1           			        { quality = 2; price = 1200; };
	class rhsusf_weap_MP7A2_winter         			        { quality = 2; price = 1200; };
	
	///////////////////////////////////////////////////////////////////////////////
	// Sniper Rifles // Снайперские винтовки
	///////////////////////////////////////////////////////////////////////////////
	// Apex
	///////////////////////////////////////////////////////////////////////////////
	class srifle_DMR_07_blk_F         				        { quality = 4; price = 1800; };
	class srifle_DMR_07_ghex_F        				        { quality = 4; price = 1800; };
	class srifle_DMR_07_hex_F         				        { quality = 4; price = 1800; };
	class srifle_GM6_ghex_F           				        { quality = 6; price = 2500; };
	class srifle_LRR_tna_F            				        { quality = 6; price = 102500; };
	///////////////////////////////////////////////////////////////////////////////
	//	CUP
	///////////////////////////////////////////////////////////////////////////////
	class CUP_srifle_AS50									{ quality = 3; price = 17800; };
	class CUP_srifle_AWM_des								{ quality = 3; price = 1800; };
	class CUP_srifle_AWM_wdl								{ quality = 3; price = 1800; };
	class CUP_srifle_CZ550									{ quality = 3; price = 1800; };
	class CUP_srifle_CZ750									{ quality = 3; price = 1800; };
	class CUP_srifle_DMR									{ quality = 3; price = 1800; };
	class CUP_srifle_LeeEnfield								{ quality = 3; price = 1800; };
	class CUP_srifle_M107_Base								{ quality = 5; price = 2400; };
	class CUP_srifle_M110									{ quality = 3; price = 1800; };
	class CUP_srifle_M14									{ quality = 3; price = 1800; };
	class CUP_srifle_M24_des								{ quality = 3; price = 1800; };
	class CUP_srifle_M24_wdl								{ quality = 3; price = 1800; };
	class CUP_srifle_M40A3									{ quality = 3; price = 1800; };
	class CUP_srifle_Mk12SPR								{ quality = 3; price = 1800; };
	class CUP_srifle_SVD									{ quality = 3; price = 11800; };
	class CUP_srifle_SVD_des								{ quality = 3; price = 11800; };
	class CUP_srifle_VSSVintorez							{ quality = 3; price = 15800; };
/*	class CUP_srifle_ksvk									{ quality = 3; price = 1800; };
	class CUP_srifle_AS50_AMPAS13c2							{ quality = 1; price = 1500; }; // Dupe bug
	class CUP_srifle_AS50_SBPMII							{ quality = 1; price = 1500; }; // Dupe bug
	class CUP_srifle_AWM_des_SBPMII							{ quality = 1; price = 1500; }; // Dupe bug
	class CUP_srifle_AWM_wdl_SBPMII							{ quality = 1; price = 1500; }; // Dupe bug
	class CUP_srifle_CZ750_SOS_bipod						{ quality = 1; price = 1500; }; // Dupe bug
	class CUP_srifle_DMR_LeupoldMk4							{ quality = 1; price = 1500; }; // Dupe bug
	class CUP_srifle_M107_ANPAS13c2							{ quality = 1; price = 1500; }; // Dupe bug
	class CUP_srifle_M107_LeupoldVX3						{ quality = 1; price = 1500; }; // Dupe bug
	class CUP_srifle_M110_ANPAS13c2							{ quality = 1; price = 1500; }; // Dupe bug
	class CUP_srifle_M110_ANPVS10							{ quality = 1; price = 1500; }; // Dupe bug
	class CUP_srifle_M15_Aim								{ quality = 1; price = 1500; }; // Dupe bug
	class CUP_srifle_M24_des_LeupoldMk4LRT					{ quality = 1; price = 1500; }; // Dupe bug
	class CUP_srifle_M24_ghillie							{ quality = 1; price = 1500; }; // Dupe bug
	class CUP_srifle_M24_wdl_LeupoldMk4LRT					{ quality = 1; price = 1500; }; // Dupe bug
	class CUP_srifle_Mk12SPR_LeupoldM3LR					{ quality = 1; price = 1500; }; // Dupe bug
	class CUP_srifle_SVD_Des_pso							{ quality = 1; price = 1500; }; // Dupe bug
	class CUP_srifle_SVD_NSPU								{ quality = 1; price = 1500; }; // Dupe bug
	class CUP_srifle_SVD_des_ghillie_pso					{ quality = 1; price = 1500; }; // Dupe bug
	class CUP_srifle_SVD_pso								{ quality = 1; price = 1500; }; // Dupe bug
	class CUP_srifle_SVD_wdl_ghillie						{ quality = 1; price = 1500; }; // Dupe bug
	class CUP_srifle_VSSVintorez_pso						{ quality = 1; price = 1500; }; // Dupe bug */
	///////////////////////////////////////////////////////////////////////////////
	// Exile
	///////////////////////////////////////////////////////////////////////////////
	class arifle_MXM_Black_F 						        { quality = 2; price = 1450; };
	class arifle_MXM_F 								        { quality = 2; price = 1450; };
	class srifle_DMR_01_F 							        { quality = 3; price = 1500; };
	class srifle_DMR_02_F 							        { quality = 3; price = 1500; };
	class srifle_DMR_02_camo_F 						        { quality = 3; price = 1500; };
	class srifle_DMR_02_sniper_F 					        { quality = 3; price = 1500; };
	class srifle_DMR_03_F 							        { quality = 3; price = 1500; };
	class srifle_DMR_03_khaki_F 					        { quality = 3; price = 1500; };
	class srifle_DMR_03_multicam_F 					        { quality = 3; price = 1500; };
	class srifle_DMR_03_tan_F 						        { quality = 3; price = 1500; };
	class srifle_DMR_03_woodland_F 					        { quality = 3; price = 1500; };
	class srifle_DMR_04_F 							        { quality = 4; price = 1550; };
	class srifle_DMR_04_Tan_F 						        { quality = 4; price = 1550; };
	class srifle_DMR_05_blk_F 						        { quality = 4; price = 1550; };
	class srifle_DMR_05_hex_F 						        { quality = 4; price = 1550; };
	class srifle_DMR_05_tan_f 						        { quality = 4; price = 1550; };
	class srifle_DMR_06_camo_F 						        { quality = 5; price = 1600; };
	class srifle_DMR_06_olive_F 					        { quality = 5; price = 1600; };
	class srifle_EBR_F 								        { quality = 3; price = 1300; };
	class srifle_GM6_F 								        { quality = 6; price = 2500; };
	class srifle_GM6_camo_F 						        { quality = 6; price = 2500; };
	class srifle_LRR_F 								        { quality = 6; price = 102500; };
	class srifle_LRR_camo_F 						        { quality = 6; price = 102500; }
	///////////////////////////////////////////////////////////////////////////////
	// RHS
	///////////////////////////////////////////////////////////////////////////////
	//US
	class rhs_weap_sr25								        { quality = 2; price = 1800; };
	class rhs_weap_sr25_ec							        { quality = 2; price = 1800; };
	class rhs_weap_m14ebrri							        { quality = 3; price = 1800; };
	class rhs_weap_XM2010							        { quality = 3; price = 1950; };
	class rhs_weap_XM2010_wd						        { quality = 3; price = 1950; };
	class rhs_weap_XM2010_d							        { quality = 3; price = 1950; };
	class rhs_weap_XM2010_sa						        { quality = 3; price = 1950; };
	//Russian                                               
	class rhs_weap_svd								        { quality = 2; price = 11800; };
	class rhs_weap_svdp_wd							        { quality = 2; price = 11800; };
	class rhs_weap_svdp_wd_npz						        { quality = 2; price = 11800; };
	class rhs_weap_svdp_npz							        { quality = 2; price = 11800; };
	class rhs_weap_svds								        { quality = 2; price = 11800; };
	class rhs_weap_svds_npz							        { quality = 2; price = 11800; };
	// Added by ElShotte                                    
	class rhs_weap_M107   							        { quality = 5; price = 232400; };
	class rhs_weap_M107_d   						        { quality = 5; price = 232400; };
	class rhs_weap_M107_w   						        { quality = 5; price = 232400; };
	class rhs_weap_t5000   							        { quality = 3; price = 122500; };
	class rhs_weap_m24sws   						        { quality = 3; price = 1750; };
	class rhs_weap_m24sws_blk   					        { quality = 3; price = 1750; };
	class rhs_weap_m24sws_ghillie   				        { quality = 3; price = 1750; };
	class rhs_weap_m40a5   							        { quality = 3; price = 1750; };
	class rhs_weap_m40a5_d   						        { quality = 3; price = 1750; };
	class rhs_weap_sr25_d 							        { quality = 3; price = 1900; };
	class rhs_weap_sr25_wd 							        { quality = 3; price = 1900; };
	class rhs_weap_sr25_ec_d 						        { quality = 3; price = 1900; };
	class rhs_weap_sr25_ec_wd 						        { quality = 3; price = 1900; };
	
	///////////////////////////////////////////////////////////////////////////////
	//	Grenade Launchers // Гранатометы
	///////////////////////////////////////////////////////////////////////////////
	//	CUP
	///////////////////////////////////////////////////////////////////////////////
	//class CUP_glaunch_6G30								{ quality = 5; price = 2500; };
	class CUP_glaunch_M32									{ quality = 5; price = 2500; };
	class CUP_glaunch_M79									{ quality = 5; price = 2500; };
	class CUP_glaunch_Mk13									{ quality = 5; price = 2500; };
	
	
	class Exile_Uniform_BambiOverall				{ quality = 1; price = 1; sellPrice = 1; };
    ///////////////////////////////////////////////////////////////////////////////
	// Civillian Clothing
	///////////////////////////////////////////////////////////////////////////////
	class U_C_Journalist 							{ quality = 1; price = 20; };
	class U_C_Poloshirt_blue 						{ quality = 1; price = 20; };
	class U_C_Poloshirt_burgundy 					{ quality = 1; price = 20; };
	class U_C_Poloshirt_salmon 						{ quality = 1; price = 20; };
	class U_C_Poloshirt_stripped 					{ quality = 1; price = 20; };
	class U_C_Poloshirt_tricolour 					{ quality = 1; price = 20; };
	class U_C_Poor_1 								{ quality = 1; price = 20; };
	class U_C_Poor_2 								{ quality = 1; price = 20; };
	class U_C_Poor_shorts_1 						{ quality = 1; price = 20; };
	class U_C_Scientist 							{ quality = 1; price = 20; };
	class U_OrestesBody 							{ quality = 1; price = 40; };
	class U_Rangemaster 							{ quality = 1; price = 40; };
	class U_NikosAgedBody 							{ quality = 1; price = 40; };
	class U_NikosBody 								{ quality = 1; price = 40; };
	class U_Competitor 								{ quality = 1; price = 40; };

	///////////////////////////////////////////////////////////////////////////////
	// Soldier Uniforms
	///////////////////////////////////////////////////////////////////////////////
	class U_B_CombatUniform_mcam 					{ quality = 3; price = 40; };
	class U_B_CombatUniform_mcam_tshirt 			{ quality = 3; price = 40; };
	class U_B_CombatUniform_mcam_vest 				{ quality = 3; price = 40; };
	class U_B_CombatUniform_mcam_worn 				{ quality = 3; price = 40; };
	class U_B_CTRG_1 								{ quality = 3; price = 40; };
	class U_B_CTRG_2 								{ quality = 3; price = 40; };
	class U_B_CTRG_3								{ quality = 3; price = 40; };
	class U_I_CombatUniform 						{ quality = 3; price = 40; };
	class U_I_CombatUniform_shortsleeve				{ quality = 3; price = 40; };
	class U_I_CombatUniform_tshirt					{ quality = 3; price = 40; };
	class U_I_OfficerUniform						{ quality = 3; price = 40; };
	class U_O_CombatUniform_ocamo 					{ quality = 3; price = 40; };
	class U_O_CombatUniform_oucamo 					{ quality = 3; price = 40; };
	class U_O_OfficerUniform_ocamo 					{ quality = 4; price = 80; };
	class U_B_SpecopsUniform_sgg 					{ quality = 4; price = 80; };
	class U_O_SpecopsUniform_blk 					{ quality = 4; price = 80; };
	class U_O_SpecopsUniform_ocamo 					{ quality = 4; price = 80; };
	class U_I_G_Story_Protagonist_F 				{ quality = 4; price = 100; };
	class Exile_Uniform_Woodland 					{ quality = 4; price = 150; };

	///////////////////////////////////////////////////////////////////////////////
	// Guerilla Uniforms
	///////////////////////////////////////////////////////////////////////////////
	class U_C_HunterBody_grn						{ quality = 3; price = 40; };
	class U_IG_Guerilla1_1							{ quality = 3; price = 40; };
	class U_IG_Guerilla2_1							{ quality = 3; price = 60; };
	class U_IG_Guerilla2_2							{ quality = 3; price = 40; };
	class U_IG_Guerilla2_3							{ quality = 3; price = 40; };
	class U_IG_Guerilla3_1							{ quality = 3; price = 40; };
	class U_BG_Guerilla2_1							{ quality = 3; price = 40; };
	class U_IG_Guerilla3_2							{ quality = 3; price = 40; };
	class U_BG_Guerrilla_6_1						{ quality = 3; price = 60; };
	class U_BG_Guerilla1_1							{ quality = 3; price = 40; };
	class U_BG_Guerilla2_2							{ quality = 3; price = 40; };
	class U_BG_Guerilla2_3							{ quality = 3; price = 40; };
	class U_BG_Guerilla3_1							{ quality = 3; price = 40; };
	class U_BG_leader								{ quality = 4; price = 40; };
	class U_IG_leader								{ quality = 4; price = 40; };
	class U_I_G_resistanceLeader_F					{ quality = 4; price = 100; };

	///////////////////////////////////////////////////////////////////////////////
	// Ghillie Suits
	///////////////////////////////////////////////////////////////////////////////
	class U_B_FullGhillie_ard						{ quality = 7; price = 9150; };
	class U_B_FullGhillie_lsh						{ quality = 7; price = 9150; };
	class U_B_FullGhillie_sard						{ quality = 7; price = 9150; };
	class U_B_GhillieSuit							{ quality = 7; price = 9100; };
	class U_I_FullGhillie_ard						{ quality = 7; price = 9150; };
	class U_I_FullGhillie_lsh						{ quality = 7; price = 9150; };
	class U_I_FullGhillie_sard						{ quality = 7; price = 9150; };
	class U_I_GhillieSuit							{ quality = 7; price = 9100; };
	class U_O_FullGhillie_ard						{ quality = 7; price = 9150; };
	class U_O_FullGhillie_lsh						{ quality = 7; price = 9150; };
	class U_O_FullGhillie_sard						{ quality = 7; price = 9150; };
	class U_O_GhillieSuit							{ quality = 7; price = 9100; };

	///////////////////////////////////////////////////////////////////////////////
	// Wet Suits
	///////////////////////////////////////////////////////////////////////////////
	//class U_I_Wetsuit								{ quality = 4; price = 35000; };
	//class U_O_Wetsuit								{ quality = 4; price = 35000; };
	//class U_B_Wetsuit								{ quality = 4; price = 35000; };
	class U_B_survival_uniform						{ quality = 4; price = 200; };

	///////////////////////////////////////////////////////////////////////////////
	// Bandolliers
	///////////////////////////////////////////////////////////////////////////////
	class V_BandollierB_blk							{ quality = 1; price = 20; };
	class V_BandollierB_cbr							{ quality = 1; price = 20; };
	class V_BandollierB_khk							{ quality = 1; price = 20; };
	class V_BandollierB_oli							{ quality = 1; price = 20; };
	class V_BandollierB_rgr							{ quality = 1; price = 20; };

	///////////////////////////////////////////////////////////////////////////////
	// Chestrigs
	///////////////////////////////////////////////////////////////////////////////
	class V_Chestrig_blk 							{ quality = 1; price = 30; };
	class V_Chestrig_khk 							{ quality = 1; price = 30; };
	class V_Chestrig_oli 							{ quality = 1; price = 30; };
	class V_Chestrig_rgr 							{ quality = 1; price = 30; };

	///////////////////////////////////////////////////////////////////////////////
	// Vests
	///////////////////////////////////////////////////////////////////////////////
	class V_Press_F									{ quality = 1; price = 10; };
	class V_Rangemaster_belt						{ quality = 1; price = 6; };
	class V_TacVest_blk								{ quality = 2; price = 50; };
	class V_TacVest_blk_POLICE						{ quality = 3; price = 50; };
	class V_TacVest_brn								{ quality = 2; price = 50; };
	class V_TacVest_camo							{ quality = 2; price = 50; };
	class V_TacVest_khk								{ quality = 2; price = 50; };
	class V_TacVest_oli								{ quality = 2; price = 50; };
	class V_TacVestCamo_khk							{ quality = 2; price = 50; };
	class V_TacVestIR_blk							{ quality = 2; price = 50; };
	class V_I_G_resistanceLeader_F					{ quality = 2; price = 50; };

	///////////////////////////////////////////////////////////////////////////////
	// Harnesses
	///////////////////////////////////////////////////////////////////////////////
	class V_HarnessO_brn							{ quality = 1; price = 40; };
	class V_HarnessO_gry							{ quality = 1; price = 40; };
	class V_HarnessOGL_brn							{ quality = 1; price = 30; };
	class V_HarnessOGL_gry							{ quality = 1; price = 30; };
	class V_HarnessOSpec_brn						{ quality = 1; price = 40; };
	class V_HarnessOSpec_gry						{ quality = 1; price = 40; };

	///////////////////////////////////////////////////////////////////////////////
	// Plate Carriers
	///////////////////////////////////////////////////////////////////////////////
	class V_PlateCarrier1_blk 						{ quality = 1; price = 80; };
	class V_PlateCarrier1_rgr 						{ quality = 1; price = 80; };
	class V_PlateCarrier2_rgr 						{ quality = 2; price = 100; };
	class V_PlateCarrier3_rgr 						{ quality = 2; price = 100; };
	class V_PlateCarrierGL_blk 						{ quality = 6; price = 500; };
	class V_PlateCarrierGL_mtp 						{ quality = 6; price = 500; };
	class V_PlateCarrierGL_rgr 						{ quality = 6; price = 500; };
	class V_PlateCarrierH_CTRG 						{ quality = 2; price = 100; };
	class V_PlateCarrierIA1_dgtl 					{ quality = 2; price = 80; };
	class V_PlateCarrierIA2_dgtl 					{ quality = 2; price = 100; };
	class V_PlateCarrierIAGL_dgtl 					{ quality = 3; price = 400; };
	class V_PlateCarrierIAGL_oli 					{ quality = 3; price = 400; };
	class V_PlateCarrierL_CTRG 						{ quality = 2; price = 100; };
	class V_PlateCarrierSpec_blk 					{ quality = 5; price = 200; };
	class V_PlateCarrierSpec_mtp 					{ quality = 5; price = 200; };
	class V_PlateCarrierSpec_rgr 					{ quality = 5; price = 200; };

	///////////////////////////////////////////////////////////////////////////////
	// Caps
	///////////////////////////////////////////////////////////////////////////////
	class H_Cap_blk 								{ quality = 1; price = 6; };
	class H_Cap_blk_Raven 							{ quality = 1; price = 6; };
	class H_Cap_blu 								{ quality = 1; price = 6; };
	class H_Cap_brn_SPECOPS 						{ quality = 1; price = 6; };
	class H_Cap_grn 								{ quality = 1; price = 6; };
	class H_Cap_headphones 							{ quality = 1; price = 6; };
	class H_Cap_khaki_specops_UK 					{ quality = 1; price = 6; };
	class H_Cap_oli 								{ quality = 1; price = 6; };
	class H_Cap_press 								{ quality = 1; price = 6; };
	class H_Cap_red 								{ quality = 1; price = 6; };
	class H_Cap_tan 								{ quality = 1; price = 6; };
	class H_Cap_tan_specops_US 						{ quality = 1; price = 6; };

	///////////////////////////////////////////////////////////////////////////////
	// Glasses
	///////////////////////////////////////////////////////////////////////////////
	class G_Spectacles			 	                { quality = 1; price = 6; };
	class G_Spectacles_Tinted		                { quality = 1; price = 6; };
	class G_Combat			 		                { quality = 1; price = 6; };
	class G_Lowprofile			 	                { quality = 1; price = 6; };
	class G_Shades_Black			                { quality = 1; price = 6; };
	class G_Shades_Green			                { quality = 1; price = 6; };
	class G_Shades_Red			 	                { quality = 1; price = 6; };
	class G_Squares			 		                { quality = 1; price = 6; };
	class G_Squares_Tinted			                { quality = 1; price = 6; };
	class G_Sport_BlackWhite		                { quality = 1; price = 6; };
	class G_Sport_Blackyellow		                { quality = 1; price = 6; };
	class G_Sport_Greenblack		                { quality = 1; price = 6; };
	class G_Sport_Checkered			                { quality = 1; price = 6; };
	class G_Sport_Red			 	                { quality = 1; price = 6; };
	class G_Tactical_Black			                { quality = 1; price = 6; };
	class G_Aviator			 		                { quality = 1; price = 6; };
	class G_Lady_Mirror			 	                { quality = 1; price = 6; };
	class G_Lady_Dark			 	                { quality = 1; price = 6; };
	class G_Lady_Red			 	                { quality = 1; price = 6; };
	class G_Lady_Blue			 	                { quality = 1; price = 6; };
	class G_Goggles_VR			 	                { quality = 1; price = 6; };
	class G_Balaclava_blk			                { quality = 2; price = 10; };
	class G_Balaclava_oli			                { quality = 2; price = 10; };
	class G_Balaclava_combat		                { quality = 2; price = 10; };
	class G_Balaclava_lowprofile	                { quality = 2; price = 10; };
	class G_Bandanna_blk			                { quality = 1; price = 6; };
	class G_Bandanna_oli			                { quality = 1; price = 6; };
	class G_Bandanna_khk			                { quality = 1; price = 6; };
	class G_Bandanna_tan			                { quality = 1; price = 6; };
	class G_Bandanna_beast			                { quality = 1; price = 6; };
	class G_Bandanna_shades			                { quality = 1; price = 6; };
	class G_Bandanna_sport			                { quality = 1; price = 6; };
	class G_Bandanna_aviator		                { quality = 1; price = 6; };
	class G_Shades_Blue			 	                { quality = 1; price = 6; };
	class G_Sport_Blackred			                { quality = 1; price = 6; };
	class G_Tactical_Clear			                { quality = 1; price = 6; };
	class G_Balaclava_TI_blk_F		                { quality = 2; price = 15; };
	class G_Balaclava_TI_tna_F		                { quality = 2; price = 15; };
	class G_Balaclava_TI_G_blk_F	                { quality = 2; price = 15; };
	class G_Balaclava_TI_G_tna_F	                { quality = 2; price = 15; };
	class G_Combat_Goggles_tna_F	                { quality = 1; price = 6; };

	///////////////////////////////////////////////////////////////////////////////
	// Military Caps
	///////////////////////////////////////////////////////////////////////////////
	class H_MilCap_blue 							{ quality = 1; price = 8; };
	class H_MilCap_dgtl 							{ quality = 1; price = 8; };
	class H_MilCap_mcamo 							{ quality = 1; price = 8; };
	class H_MilCap_ocamo 							{ quality = 1; price = 8; };
	class H_MilCap_oucamo 							{ quality = 1; price = 8; };
	class H_MilCap_rucamo 							{ quality = 1; price = 8; };

	///////////////////////////////////////////////////////////////////////////////
	// Beanies
	///////////////////////////////////////////////////////////////////////////////
	class H_Watchcap_blk 							{ quality = 1; price = 6; };
	class H_Watchcap_camo 							{ quality = 1; price = 6; };
	class H_Watchcap_khk 							{ quality = 1; price = 6; };
	class H_Watchcap_sgg 							{ quality = 1; price = 6; };

	///////////////////////////////////////////////////////////////////////////////
	// Bandannas
	///////////////////////////////////////////////////////////////////////////////
	class H_Bandanna_camo							{ quality = 1; price = 4; };
	class H_Bandanna_cbr							{ quality = 1; price = 4; };
	class H_Bandanna_gry							{ quality = 1; price = 4; };
	class H_Bandanna_khk							{ quality = 1; price = 4; };
	class H_Bandanna_khk_hs							{ quality = 1; price = 4; };
	class H_Bandanna_mcamo							{ quality = 1; price = 4; };
	class H_Bandanna_sgg							{ quality = 1; price = 4; };
	class H_Bandanna_surfer							{ quality = 1; price = 4; };

	///////////////////////////////////////////////////////////////////////////////
	// Boonie Hats
	///////////////////////////////////////////////////////////////////////////////
	class H_Booniehat_dgtl							{ quality = 1; price = 6; };
	class H_Booniehat_dirty							{ quality = 1; price = 6; };
	class H_Booniehat_grn							{ quality = 1; price = 6; };
	class H_Booniehat_indp							{ quality = 1; price = 6; };
	class H_Booniehat_khk							{ quality = 1; price = 6; };
	class H_Booniehat_khk_hs						{ quality = 1; price = 6; };
	class H_Booniehat_mcamo							{ quality = 1; price = 6; };
	class H_Booniehat_tan							{ quality = 1; price = 6; };

	///////////////////////////////////////////////////////////////////////////////
	// Hats
	///////////////////////////////////////////////////////////////////////////////
	class H_Hat_blue								{ quality = 1; price = 6; };
	class H_Hat_brown								{ quality = 1; price = 6; };
	class H_Hat_camo								{ quality = 1; price = 6; };
	class H_Hat_checker								{ quality = 1; price = 6; };
	class H_Hat_grey								{ quality = 1; price = 6; };
	class H_Hat_tan									{ quality = 1; price = 6; };
	class H_StrawHat								{ quality = 1; price = 6; };
	class H_StrawHat_dark							{ quality = 1; price = 6; };
	class Exile_Headgear_SantaHat					{ quality = 1; price = 10; };
	class Exile_Headgear_SafetyHelmet				{ quality = 1; price = 20; };

	///////////////////////////////////////////////////////////////////////////////
	// Berets
	///////////////////////////////////////////////////////////////////////////////
	class H_Beret_02								{ quality = 2; price = 6; };
	class H_Beret_blk								{ quality = 2; price = 6; };
	class H_Beret_blk_POLICE						{ quality = 2; price = 6; };
	class H_Beret_brn_SF							{ quality = 2; price = 6; };
	class H_Beret_Colonel							{ quality = 3; price = 8; };
	class H_Beret_grn								{ quality = 2; price = 6; };
	class H_Beret_grn_SF							{ quality = 2; price = 6; };
	class H_Beret_ocamo								{ quality = 2; price = 6; };
	class H_Beret_red								{ quality = 2; price = 6; };

	///////////////////////////////////////////////////////////////////////////////
	// Shemags
	///////////////////////////////////////////////////////////////////////////////
	class H_Shemag_khk								{ quality = 1; price = 10; };
	class H_Shemag_olive							{ quality = 1; price = 10; };
	class H_Shemag_olive_hs							{ quality = 1; price = 10; };
	class H_Shemag_tan								{ quality = 1; price = 10; };
	class H_ShemagOpen_khk							{ quality = 1; price = 10; };
	class H_ShemagOpen_tan							{ quality = 1; price = 10; };
	class H_TurbanO_blk								{ quality = 1; price = 10; };

	///////////////////////////////////////////////////////////////////////////////
	// Light Helmets
	///////////////////////////////////////////////////////////////////////////////
	class H_HelmetB_light							{ quality = 2; price = 20; };
	class H_HelmetB_light_black						{ quality = 2; price = 20; };
	class H_HelmetB_light_desert					{ quality = 2; price = 20; };
	class H_HelmetB_light_grass						{ quality = 2; price = 20; };
	class H_HelmetB_light_sand						{ quality = 2; price = 20; };
	class H_HelmetB_light_snakeskin					{ quality = 2; price = 20; };

	///////////////////////////////////////////////////////////////////////////////
	// Helmets
	///////////////////////////////////////////////////////////////////////////////
	class H_HelmetIA								{ quality = 3; price = 40; };
	class H_HelmetIA_camo							{ quality = 3; price = 40; };
	class H_HelmetIA_net							{ quality = 3; price = 40; };
	class H_HelmetB									{ quality = 3; price = 60; };
	class H_HelmetB_black							{ quality = 3; price = 60; };
	class H_HelmetB_camo							{ quality = 3; price = 80; }; // This one is awesome!
	class H_HelmetB_desert							{ quality = 3; price = 60; };
	class H_HelmetB_grass							{ quality = 3; price = 60; };
	class H_HelmetB_paint							{ quality = 3; price = 60; };
	class H_HelmetB_plain_blk						{ quality = 3; price = 60; };
	class H_HelmetB_sand							{ quality = 3; price = 60; };
	class H_HelmetB_snakeskin						{ quality = 3; price = 60; };

	///////////////////////////////////////////////////////////////////////////////
	// Spec Ops Helmets
	///////////////////////////////////////////////////////////////////////////////
	class H_HelmetSpecB								{ quality = 4; price = 80; };
	class H_HelmetSpecB_blk							{ quality = 4; price = 80; };
	class H_HelmetSpecB_paint1						{ quality = 4; price = 80; };
	class H_HelmetSpecB_paint2						{ quality = 4; price = 80; };

	///////////////////////////////////////////////////////////////////////////////
	// Super Helmets
	///////////////////////////////////////////////////////////////////////////////
	class H_HelmetO_ocamo							{ quality = 5; price = 150; };
	class H_HelmetO_oucamo							{ quality = 5; price = 150; };
	class H_HelmetSpecO_blk							{ quality = 5; price = 100; };
	class H_HelmetSpecO_ocamo						{ quality = 5; price = 100; };
	class H_HelmetLeaderO_ocamo						{ quality = 5; price = 200; };
	class H_HelmetLeaderO_oucamo					{ quality = 5; price = 200; };

	///////////////////////////////////////////////////////////////////////////////
	// UAVS
	///////////////////////////////////////////////////////////////////////////////
	class I_UavTerminal								{ quality = 2; price = 750; };
	class I_UAV_01_backpack_F						{ quality = 2; price = 3000; };
	class I_UGV_01_F								{ quality = 2; price = 20000; };
	
	///////////////////////////////////////////////////////////////////////////////
	//LOW UAVs
	///////////////////////////////////////////////////////////////////////////////
	class I_UAV_06_medical_backpack_F				{ quality = 2; price = 5000; };
	class I_UAV_06_backpack_F						{ quality = 2; price = 5000; };

	///////////////////////////////////////////////////////////////////////////////
	// Hardware
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Item_Rope							{ quality = 1; price = 1000; };
	class Exile_Item_DuctTape						{ quality = 1; price = 1300; };
	class Exile_Item_ExtensionCord					{ quality = 1; price = 1800; };
	class Exile_Item_FuelCanisterEmpty				{ quality = 1; price = 1800; };
	class Exile_Item_WaterCanisterEmpty             { quality = 1; price = 1800; };
	class Exile_Item_JunkMetal						{ quality = 1; price = 1800; };
	class Exile_Item_LightBulb						{ quality = 1; price = 1600; };
	class Exile_Item_MetalBoard						{ quality = 1; price = 1900; };
	class Exile_Item_MetalHedgehogKit				{ quality = 1; price = 1200; };
	class Exile_Item_SafeKit						{ quality = 3; price = 30000; };
	class Exile_Item_SafeSmallKit					{ quality = 2; price = 15000; };
	class Exile_Item_CodeLock						{ quality = 1; price = 15000; };
	class Exile_Item_Laptop						    { quality = 2; price = 9000; };
	class Exile_Item_BaseCameraKit				    { quality = 2; price = 5000; };
	class Exile_Item_CamoTentKit					{ quality = 1; price = 2500; };
	class Exile_Item_MetalPole						{ quality = 1; price = 1500; };
	class Exile_Item_MetalScrews					{ quality = 1; price = 1000; };
	class Exile_Item_MetalWire					    { quality = 1; price = 1000; };
	class Exile_Item_Cement						    { quality = 1; price = 1100; };
	class Exile_Item_Sand							{ quality = 1; price = 1100; };
	class Exile_Item_CarWheel						{ quality = 1; price = 1000; };
	class Exile_Item_MobilePhone                    { quality = 5; price = 15000; }; 
	// Added in 1.0.3, but not used
	//class Exile_Item_SprayCan_Black				{ quality = 2; price = 20; };
	//class Exile_Item_SprayCan_Red					{ quality = 2; price = 20; };
	//class Exile_Item_SprayCan_Green				{ quality = 2; price = 20; };
	//class Exile_Item_SprayCan_White				{ quality = 2; price = 20; };
	//class Exile_Item_SprayCan_Blue				{ quality = 2; price = 20; };
	//class Exile_Item_BurlapSack					{ quality = 2; price = 5; };
	//class Exile_Item_Bullets_556					{ quality = 2; price = 5; };
	//class Exile_Item_Bullets_762					{ quality = 2; price = 5; };
	//class Exile_Item_WeaponParts					{ quality = 2; price = 20; };
	

	///////////////////////////////////////////////////////////////////////////////
	// Food
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Item_SheepSteak_Cooked				{ quality = 4; price = 300; sellPrice = 100; }; //100, 30
	class Exile_Item_AlsatianSteak_Cooked			{ quality = 4; price = 300; sellPrice = 100; }; //100, 30
	class Exile_Item_CatSharkFilet_Cooked			{ quality = 4; price = 5001; sellPrice = 5100; }; //100, 30
	class Exile_Item_FinSteak_Cooked				{ quality = 4; price = 300; sellPrice = 100; }; //100, 30
	class Exile_Item_GoatSteak_Cooked				{ quality = 4; price = 300; sellPrice = 100; }; //100, 30
	class Exile_Item_TurtleFilet_Cooked				{ quality = 4; price = 5300; sellPrice = 5300; }; //100, 30
	class Exile_Item_TunaFilet_Cooked				{ quality = 3; price = 5200; sellPrice = 5200; }; //90, 30
	class Exile_Item_RabbitSteak_Cooked				{ quality = 3; price = 280; sellPrice = 80; }; //80, 30
	class Exile_Item_EMRE							{ quality = 3; price = 54; }; //75, 60
	class Exile_Item_ChickenFilet_Cooked			{ quality = 3; price = 270; sellPrice = 100; }; //70, 30
	class Exile_Item_RoosterFilet_Cooked			{ quality = 3; price = 270; sellPrice = 100; }; //70, 30
	class Exile_Item_MulletFilet_Cooked				{ quality = 3; price = 5020; sellPrice = 5020; };
	class Exile_Item_SalemaFilet_Cooked				{ quality = 3; price = 5000; sellPrice = 5000; };
	class Exile_Item_GloriousKnakworst				{ quality = 3; price = 40; }; //60, 30
	class Exile_Item_MackerelFilet_Cooked			{ quality = 3; price = 5000; sellPrice = 5000; };
	class Exile_Item_Surstromming					{ quality = 3; price = 34; }; //55, 25
	class Exile_Item_SausageGravy					{ quality = 3; price = 30; }; //50, 25
	class Exile_Item_OrnateFilet_Cooked				{ quality = 3; price = 5400; sellPrice = 5400; };
	class Exile_Item_SnakeFilet_Cooked				{ quality = 3; price = 5000; sellPrice = 5000; };
	class Exile_Item_Catfood						{ quality = 1; price = 24; }; //40, 40
	class Exile_Item_ChristmasTinner				{ quality = 3; price = 20; }; //40, 60
	class Exile_Item_BBQSandwich					{ quality = 3; price = 20; }; //40, 60
	class Exile_Item_MacasCheese					{ quality = 3; price = 20; }; //40, 60
	class Exile_Item_Dogfood						{ quality = 1; price = 18; }; //30, 30
	class Exile_Item_BeefParts						{ quality = 1; price = 50000; }; //30, 30
	class Exile_Item_Cheathas						{ quality = 1; price = 18; }; //30, 30
	class Exile_Item_CatSharkFilet_Raw				{ quality = 1; price = 125; }; //25, 30
	class Exile_Item_Noodles						{ quality = 1; price = 14; }; //25, 50
	class Exile_Item_SeedAstics						{ quality = 1; price = 12; }; //20, 40
	class Exile_Item_TunaFilet_Raw					{ quality = 1; price = 1008; }; //20, 30
	class Exile_Item_AlsatianSteak_Raw				{ quality = 1; price = 115; };	//15, 30
	class Exile_Item_TurtleFilet_Raw				{ quality = 1; price = 115; }; //15, 30
	class Exile_Item_SheepSteak_Raw					{ quality = 1; price = 115; }; //15, 30
	class Exile_Item_FinSteak_Raw					{ quality = 1; price = 115; }; //15, 30
	class Exile_Item_GoatSteak_Raw					{ quality = 1; price = 115; }; //15, 30
	class Exile_Item_Raisins						{ quality = 1; price = 10; }; //15, 30
	class Exile_Item_ChickenFilet_Raw				{ quality = 1; price = 110; }; //10, 30
	class Exile_Item_RoosterFilet_Raw				{ quality = 1; price = 110; }; //10, 30
	class Exile_Item_Moobar							{ quality = 1; price = 8; }; //10, 30
	class Exile_Item_InstantCoffee					{ quality = 1; price = 20; }; //5, 10
	class Exile_Item_MackerelFilet_Raw				{ quality = 1; price = 1008; };
	class Exile_Item_MulletFilet_Raw				{ quality = 1; price = 1008; };
	class Exile_Item_OrnateFilet_Raw				{ quality = 1; price = 1008; };
	class Exile_Item_RabbitSteak_Raw				{ quality = 1; price = 1008; };
	class Exile_Item_SalemaFilet_Raw				{ quality = 1; price = 1008; };
	class Exile_Item_SnakeFilet_Raw					{ quality = 1; price = 1008; };
	class Exile_Item_Can_Empty						{ quality = 0; price = 100; sellPrice = 1; };	
    class Exile_Item_BurlapSack                     { quality = 0; price = 100; sellPrice = 1; }; 
	///////////////////////////////////////////////////////////////////////////////
	// Drinks
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Item_PlasticBottleCoffee	 		{ quality = 1; price = 70; sellPrice = 10; };//100, 60
	class Exile_Item_PowerDrink						{ quality = 1; price = 60; }; //95, 10
	class Exile_Item_PlasticBottleFreshWater 		{ quality = 1; price = 50; sellPrice = 4; }; //80, 15
	class Exile_Item_Beer 							{ quality = 1; price = 50; }; //75, 30
	class Exile_Item_EnergyDrink					{ quality = 1; price = 40; }; //75, 20
	class Exile_Item_ChocolateMilk					{ quality = 1; price = 25; }; //75, 20
	class Exile_Item_MountainDupe					{ quality = 1; price = 30; }; //50, 20
	class Exile_Item_PlasticBottleEmpty				{ quality = 1; price = 4; };

	///////////////////////////////////////////////////////////////////////////////
	// First Aid
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Item_InstaDoc                       { quality = 3; price = 11250; };
	class Exile_Item_Vishpirin						{ quality = 1; price = 1400; };
	class Exile_Item_Bandage	                    { quality = 1; price = 1200; };
	class Exile_Item_Heatpack	                    { quality = 1; price = 1150; };
    class Exile_Item_Defibrillator				    { quality = 5; price = 70000;};

	///////////////////////////////////////////////////////////////////////////////
	// Tools
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Melee_SledgeHammer				    { quality = 1; price = 600; };
	class Exile_Item_Matches 						{ quality = 1; price = 2500; };
	class Exile_Item_CookingPot						{ quality = 1; price = 2000; };
	class Exile_Melee_Axe							{ quality = 1; price = 500; };
	class Exile_Magazine_Swing						{ quality = 1; price = 100; };
	class Exile_Item_CanOpener						{ quality = 1; price = 350; };
	class Exile_Item_Handsaw						{ quality = 1; price = 3000; };
	class Exile_Item_Pliers							{ quality = 1; price = 4500; };
	class Exile_Item_Grinder						{ quality = 1; price = 8000; };
	class Exile_Item_Foolbox						{ quality = 1; price = 7000; };
	class Exile_Item_CordlessScrewdriver			{ quality = 1; price = 5000; };
	class Exile_Item_FireExtinguisher				{ quality = 1; price = 5000; };
	class Exile_Item_Hammer						    { quality = 1; price = 3000; };
	class Exile_Item_OilCanister					{ quality = 1; price = 4700; };
	class Exile_Item_Screwdriver					{ quality = 1; price = 7000; };
	class Exile_Item_Wrench						    { quality = 1; price = 4500; };
	class Exile_Item_SleepingMat					{ quality = 1; price = 3000; };
	class Exile_Item_ToiletPaper					{ quality = 1; price = 100; };
	class Exile_Item_ZipTie						    { quality = 1; price = 400; };
	class Exile_Item_Knife							{ quality = 1; price = 700; };	
	
	///////////////////////////////////////////////////////////////////////////////
	// Navigation
	///////////////////////////////////////////////////////////////////////////////
	class ItemWatch									{ quality = 1; price = 2; };
	class ItemGPS									{ quality = 1; price = 40; };
	class ItemMap									{ quality = 1; price = 6; };
	class ItemCompass								{ quality = 1; price = 6; };
	class ItemRadio									{ quality = 1; price = 40; };
	class Binocular									{ quality = 1; price = 340; };
	class Rangefinder								{ quality = 3; price = 5200; };
	class Laserdesignator							{ quality = 6; price = 5750; };
	class Laserdesignator_02						{ quality = 6; price = 5750; };
	class Laserdesignator_03						{ quality = 6; price = 5750; };
	class NVGoggles									{ quality = 2; price = 5100; };
	class NVGoggles_INDEP							{ quality = 2; price = 5100; };
	class NVGoggles_OPFOR							{ quality = 2; price = 5100; };
	class Exile_Item_XM8							{ quality = 1; price = 20; };
	
	///////////////////////////////////////////////////////////////////////////////
	// Pilot Stuff
	///////////////////////////////////////////////////////////////////////////////
	class B_Parachute								{ quality = 3; price = 150; };
	class H_CrewHelmetHeli_B						{ quality = 3; price = 150; };
	class H_CrewHelmetHeli_I						{ quality = 3; price = 150; };
	class H_CrewHelmetHeli_O						{ quality = 3; price = 150; };
	class H_HelmetCrew_I							{ quality = 3; price = 100; };
	class H_HelmetCrew_B							{ quality = 3; price = 100; };
	class H_HelmetCrew_O							{ quality = 3; price = 100; };
	class H_PilotHelmetHeli_B						{ quality = 4; price = 100; };
	class H_PilotHelmetHeli_I						{ quality = 4; price = 100; };
	class H_PilotHelmetHeli_O						{ quality = 4; price = 100; };
	class U_B_HeliPilotCoveralls					{ quality = 4; price = 80; };
	class U_B_PilotCoveralls						{ quality = 2; price = 60; };
	class U_I_HeliPilotCoveralls					{ quality = 2; price = 60; };
	class U_I_pilotCoveralls						{ quality = 2; price = 60; };
	class U_O_PilotCoveralls						{ quality = 2; price = 60; };
	class H_PilotHelmetFighter_B					{ quality = 5; price = 150; };
	class H_PilotHelmetFighter_I					{ quality = 5; price = 150; };
	class H_PilotHelmetFighter_O					{ quality = 5; price = 150; };

	///////////////////////////////////////////////////////////////////////////////
	// Backpacks
	///////////////////////////////////////////////////////////////////////////////
	class B_HuntingBackpack							{ quality = 3; price = 70; };
	class B_OutdoorPack_blk							{ quality = 1; price = 80; };
	class B_OutdoorPack_blu							{ quality = 1; price = 80; };
	class B_OutdoorPack_tan							{ quality = 1; price = 80; };
	class B_AssaultPack_blk							{ quality = 1; price = 90; };
	class B_AssaultPack_cbr							{ quality = 1; price = 90; };
	class B_AssaultPack_dgtl						{ quality = 1; price = 90; };
	class B_AssaultPack_khk							{ quality = 1; price = 90; };
	class B_AssaultPack_mcamo						{ quality = 1; price = 90; };
	class B_AssaultPack_rgr							{ quality = 1; price = 90; };
	class B_AssaultPack_sgg							{ quality = 1; price = 90; };
	class B_FieldPack_blk							{ quality = 2; price = 120; };
	class B_FieldPack_cbr							{ quality = 2; price = 120; };
	class B_FieldPack_ocamo							{ quality = 2; price = 120; };
	class B_FieldPack_oucamo						{ quality = 2; price = 120; };
	class B_TacticalPack_blk						{ quality = 2; price = 150; };
	class B_TacticalPack_rgr						{ quality = 2; price = 150; };
	class B_TacticalPack_ocamo						{ quality = 2; price = 150; };
	class B_TacticalPack_mcamo						{ quality = 2; price = 150; };
	class B_TacticalPack_oli						{ quality = 2; price = 150; };
	class B_Kitbag_cbr								{ quality = 3; price = 200; };
	class B_Kitbag_mcamo							{ quality = 3; price = 200; };
	class B_Kitbag_sgg								{ quality = 3; price = 200; };
	class B_Bergen_blk								{ quality = 3; price = 200; };
	class B_Bergen_mcamo							{ quality = 3; price = 200; };
	class B_Bergen_rgr								{ quality = 3; price = 200; };
	class B_Bergen_sgg								{ quality = 3; price = 200; };
	class B_Carryall_cbr							{ quality = 4; price = 300; };
	class B_Carryall_khk							{ quality = 4; price = 300; };
	class B_Carryall_mcamo							{ quality = 4; price = 300; };
	class B_Carryall_ocamo							{ quality = 4; price = 300; };
	class B_Carryall_oli							{ quality = 4; price = 300; };
	class B_Carryall_oucamo							{ quality = 4; price = 300; };

	///////////////////////////////////////////////////////////////////////////////
	// Flares
	///////////////////////////////////////////////////////////////////////////////
	class Chemlight_blue							{ quality = 1; price = 2; };
	class Chemlight_green							{ quality = 1; price = 2; };
	class Chemlight_red								{ quality = 1; price = 2; };
	class FlareGreen_F								{ quality = 1; price = 6; };
	class FlareRed_F								{ quality = 1; price = 6; };
	class FlareWhite_F								{ quality = 1; price = 6; };
	class FlareYellow_F								{ quality = 1; price = 6; };
	class UGL_FlareGreen_F							{ quality = 2; price = 8; };
	class UGL_FlareRed_F							{ quality = 2; price = 8; };
	class UGL_FlareWhite_F							{ quality = 2; price = 8; };
	class UGL_FlareYellow_F							{ quality = 2; price = 8; };
	class 3Rnd_UGL_FlareGreen_F						{ quality = 3; price = 8*3; };
	class 3Rnd_UGL_FlareRed_F						{ quality = 3; price = 8*3; };
	class 3Rnd_UGL_FlareWhite_F						{ quality = 3; price = 8*3; };
	class 3Rnd_UGL_FlareYellow_F					{ quality = 3; price = 8*3; };

	///////////////////////////////////////////////////////////////////////////////
	// Smokes
	///////////////////////////////////////////////////////////////////////////////
	class SmokeShell								{ quality = 1; price = 6; };
	class SmokeShellBlue							{ quality = 1; price = 6; };
	class SmokeShellGreen							{ quality = 1; price = 6; };
	class SmokeShellOrange							{ quality = 1; price = 6; };
	class SmokeShellPurple							{ quality = 1; price = 6; };
	class SmokeShellRed								{ quality = 1; price = 6; };
	class SmokeShellYellow							{ quality = 1; price = 6; };
	class 1Rnd_Smoke_Grenade_shell					{ quality = 2; price = 8; };
	class 1Rnd_SmokeBlue_Grenade_shell				{ quality = 2; price = 8; };
	class 1Rnd_SmokeGreen_Grenade_shell				{ quality = 2; price = 8; };
	class 1Rnd_SmokeOrange_Grenade_shell			{ quality = 2; price = 8; };
	class 1Rnd_SmokePurple_Grenade_shell			{ quality = 2; price = 8; };
	class 1Rnd_SmokeRed_Grenade_shell				{ quality = 2; price = 8; };
	class 1Rnd_SmokeYellow_Grenade_shell			{ quality = 2; price = 8; };
	class 3Rnd_Smoke_Grenade_shell					{ quality = 3; price = 8*3; };
	class 3Rnd_SmokeBlue_Grenade_shell				{ quality = 3; price = 8*3; };
	class 3Rnd_SmokeGreen_Grenade_shell				{ quality = 3; price = 8*3; };
	class 3Rnd_SmokeOrange_Grenade_shell			{ quality = 3; price = 8*3; };
	class 3Rnd_SmokePurple_Grenade_shell			{ quality = 3; price = 8*3; };
	class 3Rnd_SmokeRed_Grenade_shell				{ quality = 3; price = 8*3; };
	class 3Rnd_SmokeYellow_Grenade_shell			{ quality = 3; price = 8*3; };

	///////////////////////////////////////////////////////////////////////////////
	// Explosives
	///////////////////////////////////////////////////////////////////////////////
	class HandGrenade								{ quality = 3; price = 140; };
	class MiniGrenade								{ quality = 2; price = 130; };
	class B_IR_Grenade								{ quality = 1; price = 150; };
	class O_IR_Grenade								{ quality = 1; price = 150; };
	class I_IR_Grenade								{ quality = 1; price = 150; };
	class 1Rnd_HE_Grenade_shell						{ quality = 2; price = 170; };
	class 3Rnd_HE_Grenade_shell						{ quality = 3; price = 170*3; };
	class APERSBoundingMine_Range_Mag				{ quality = 3; price = 600; };
	class APERSMine_Range_Mag						{ quality = 3; price = 700; };
	class APERSTripMine_Wire_Mag					{ quality = 3; price = 400; };
	class ClaymoreDirectionalMine_Remote_Mag		{ quality = 3; price = 450; };
	class DemoCharge_Remote_Mag						{ quality = 4; price = 800; };
	class IEDLandBig_Remote_Mag						{ quality = 3; price = 700; };
	class IEDLandSmall_Remote_Mag					{ quality = 3; price = 400; };
	class IEDUrbanBig_Remote_Mag					{ quality = 3; price = 900; };
	class IEDUrbanSmall_Remote_Mag					{ quality = 3; price = 500; };
	class SatchelCharge_Remote_Mag					{ quality = 5; price = 1000; };
	class SLAMDirectionalMine_Wire_Mag				{ quality = 3; price = 800; };



	class U_B_T_Soldier_F                               { quality = 2; price = 40; };
	class U_B_T_Soldier_AR_F                            { quality = 2; price = 40; };
	class U_B_T_Soldier_SL_F                            { quality = 2; price = 40; };
	class U_B_T_Sniper_F                                { quality = 3; price = 100; };
	class U_B_T_FullGhillie_tna_F                       { quality = 4; price = 150; };
	class U_B_CTRG_Soldier_F                            { quality = 2; price = 40; };
	class U_B_CTRG_Soldier_2_F                          { quality = 2; price = 40; };
	class U_B_CTRG_Soldier_3_F                          { quality = 2; price = 40; };
	class U_B_GEN_Soldier_F                             { quality = 2; price = 35; };
	class U_B_GEN_Commander_F                           { quality = 2; price = 35; };
	class U_O_T_Soldier_F                               { quality = 2; price = 40; };
	class U_O_T_Officer_F                               { quality = 3; price = 40; };
	class U_O_T_Sniper_F                                { quality = 3; price = 100; };
	class U_O_T_FullGhillie_tna_F                       { quality = 4; price = 150; };
	class U_O_V_Soldier_Viper_F                         { quality = 4; price = 150; };
	class U_O_V_Soldier_Viper_hex_F                     { quality = 4; price = 150; };
	class U_I_C_Soldier_Para_1_F                        { quality = 2; price = 30; };
	class U_I_C_Soldier_Para_2_F                        { quality = 2; price = 30; };
	class U_I_C_Soldier_Para_3_F                        { quality = 2; price = 30; };
	class U_I_C_Soldier_Para_4_F                        { quality = 2; price = 30; };
	class U_I_C_Soldier_Para_5_F                        { quality = 2; price = 30; };
	class U_I_C_Soldier_Bandit_1_F                      { quality = 1; price = 15; };
	class U_I_C_Soldier_Bandit_2_F                      { quality = 1; price = 15; };
	class U_I_C_Soldier_Bandit_3_F                      { quality = 1; price = 15; };
	class U_I_C_Soldier_Bandit_4_F                      { quality = 1; price = 15; };
	class U_I_C_Soldier_Bandit_5_F                      { quality = 1; price = 15; };
	class U_I_C_Soldier_Camo_F                          { quality = 2; price = 30; };
	class U_C_man_sport_1_F                             { quality = 1; price = 10; };
	class U_C_man_sport_2_F                             { quality = 1; price = 10; };
	class U_C_man_sport_3_F                             { quality = 1; price = 10; };
	class U_C_Man_casual_1_F                            { quality = 1; price = 10; };
	class U_C_Man_casual_2_F                            { quality = 1; price = 10; };
	class U_C_Man_casual_3_F                            { quality = 1; price = 10; };
	class U_C_Man_casual_4_F                            { quality = 1; price = 10; };
	class U_C_Man_casual_5_F                            { quality = 1; price = 10; };
	class U_C_Man_casual_6_F                            { quality = 1; price = 10; };
	class U_B_CTRG_Soldier_urb_1_F                      { quality = 2; price = 40; };
	class U_B_CTRG_Soldier_urb_2_F                      { quality = 2; price = 40; };
	class U_B_CTRG_Soldier_urb_3_F                      { quality = 2; price = 40; };
	class H_Helmet_Skate                                { quality = 2; price = 20; };
	class H_HelmetB_TI_tna_F                            { quality = 4; price = 100; };
	class H_HelmetB_tna_F                               { quality = 3; price = 50; };
	class H_HelmetB_Enh_tna_F                           { quality = 4; price = 100; };
	class H_HelmetB_Light_tna_F                         { quality = 2; price = 20; };
	class H_HelmetSpecO_ghex_F                          { quality = 5; price = 100; };
	class H_HelmetLeaderO_ghex_F                        { quality = 5; price = 175; };
	class H_HelmetO_ghex_F                              { quality = 5; price = 75; };
	class H_HelmetCrew_O_ghex_F                         { quality = 3; price = 75; };
	class H_MilCap_tna_F                                { quality = 1; price = 8; };
	class H_MilCap_ghex_F                               { quality = 1; price = 8; };
	class H_Booniehat_tna_F                             { quality = 1; price = 4; };
	class H_Beret_gen_F                                 { quality = 2; price = 12; };
	class H_MilCap_gen_F                                { quality = 1; price = 10; };
	class H_Cap_oli_Syndikat_F                          { quality = 1; price = 6; };
	class H_Cap_tan_Syndikat_F                          { quality = 1; price = 6; };
	class H_Cap_blk_Syndikat_F                          { quality = 1; price = 6; };
	class H_Cap_grn_Syndikat_F                          { quality = 1; price = 6; };
	class H_FakeHeadgear_Syndikat_F                     { quality = 1; price = 6; };
	class V_TacChestrig_grn_F                           { quality = 1; price = 15; };
	class V_TacChestrig_oli_F                           { quality = 1; price = 15; };
	class V_TacChestrig_cbr_F                           { quality = 1; price = 15; };
	class V_PlateCarrier1_tna_F                         { quality = 3; price = 50; };
	class V_PlateCarrier2_tna_F                         { quality = 3; price = 60; };
	class V_PlateCarrierSpec_tna_F                      { quality = 5; price = 100; };
	class V_PlateCarrierGL_tna_F                        { quality = 6; price = 500; };
	class V_HarnessO_ghex_F                             { quality = 2; price = 50; };
	class V_HarnessOGL_ghex_F                           { quality = 1; price = 30; };
	class V_BandollierB_ghex_F                          { quality = 1; price = 10; };
	class V_TacVest_gen_F                               { quality = 1; price = 25; };
	class V_PlateCarrier1_rgr_noflag_F		            { quality = 2; price = 50; };
	class V_PlateCarrier2_rgr_noflag_F		            { quality = 2; price = 60; };
	class B_Bergen_Base_F					            { quality = 5; price = 400; };
	class B_Bergen_mcamo_F                              { quality = 5; price = 400; };
	class B_Bergen_dgtl_F                               { quality = 5; price = 400; };
	class B_Bergen_hex_F                                { quality = 5; price = 400; };
	class B_Bergen_tna_F                                { quality = 5; price = 400; };
	class B_AssaultPack_tna_F                           { quality = 1; price = 90; };
	class B_Carryall_ghex_F                             { quality = 4; price = 300; };
	class B_FieldPack_ghex_F                            { quality = 2; price = 120; };
	class B_ViperHarness_base_F                         { quality = 3; price = 250; };
	class B_ViperHarness_blk_F                          { quality = 3; price = 250; };
	class B_ViperHarness_ghex_F                         { quality = 3; price = 250; };
	class B_ViperHarness_hex_F                          { quality = 3; price = 250; };
	class B_ViperHarness_khk_F                          { quality = 3; price = 250; };
	class B_ViperHarness_oli_F                          { quality = 3; price = 250; };
	class B_ViperLightHarness_base_F                    { quality = 2; price = 200; };
	class B_ViperLightHarness_blk_F                     { quality = 2; price = 200; };
	class B_ViperLightHarness_ghex_F                    { quality = 2; price = 200; };
	class B_ViperLightHarness_hex_F                     { quality = 2; price = 200; };
	class B_ViperLightHarness_khk_F                     { quality = 2; price = 200; };
	class B_ViperLightHarness_oli_F                     { quality = 2; price = 200; };

	// Jets DLC items
	class V_DeckCrew_yellow_F						{ quality = 2; price = 30; };
	class V_DeckCrew_blue_F							{ quality = 2; price = 30; };
	class V_DeckCrew_green_F						{ quality = 2; price = 30; };
	class V_DeckCrew_red_F							{ quality = 2; price = 30; };
	class V_DeckCrew_white_F						{ quality = 2; price = 30; };
	class V_DeckCrew_brown_F						{ quality = 2; price = 30; };
	class V_DeckCrew_violet_F						{ quality = 2; price = 30; };

	

	///////////////////////////////////////////////////////////////////////////////
	// QUAD BIKES
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Bike_QuadBike_Black					{ quality = 1; price = 2500; sellprice = 10; };
	class Exile_Bike_QuadBike_Blue					{ quality = 1; price = 2500; sellprice = 10; };
	class Exile_Bike_QuadBike_Red					{ quality = 1; price = 2500; sellprice = 10; };
	class Exile_Bike_QuadBike_White					{ quality = 1; price = 2500; sellprice = 10; };
	class Exile_Bike_QuadBike_Nato					{ quality = 1; price = 2500; sellprice = 10; };
	class Exile_Bike_QuadBike_Csat					{ quality = 1; price = 2500; sellprice = 10; };
	class Exile_Bike_QuadBike_Fia					{ quality = 1; price = 2500; sellprice = 10; };
	class Exile_Bike_QuadBike_Guerilla01			{ quality = 1; price = 2500; sellprice = 10; };
	class Exile_Bike_QuadBike_Guerilla02			{ quality = 1; price = 2500; sellprice = 10; };

	///////////////////////////////////////////////////////////////////////////////
	// KARTS
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_Kart_BluKing					{ quality = 1; price = 1100; };
	class Exile_Car_Kart_RedStone					{ quality = 1; price = 1100; };
	class Exile_Car_Kart_Vrana						{ quality = 1; price = 1100; };
	class Exile_Car_Kart_Green						{ quality = 1; price = 1100; };
	class Exile_Car_Kart_Blue						{ quality = 1; price = 1100; };
	class Exile_Car_Kart_Orange						{ quality = 1; price = 1100; };
	class Exile_Car_Kart_White						{ quality = 1; price = 1100; };
	class Exile_Car_Kart_Yellow						{ quality = 1; price = 1100; };
	class Exile_Car_Kart_Black						{ quality = 1; price = 1400000; };

	///////////////////////////////////////////////////////////////////////////////
	// MOTOR BOATS
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Boat_MotorBoat_Police				{ quality = 1; price = 20000; };

	///////////////////////////////////////////////////////////////////////////////
	// RUBBER DUCKS
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Boat_RubberDuck_CSAT				{ quality = 1; price = 12000; };
	class Exile_Boat_RubberDuck_Digital				{ quality = 1; price = 12000; };
	class Exile_Boat_RubberDuck_Orange				{ quality = 1; price = 12000; sellprice = 1000; };
	class Exile_Boat_RubberDuck_Blue				{ quality = 1; price = 12000; };
	class Exile_Boat_RubberDuck_Black				{ quality = 1; price = 12000; };

	///////////////////////////////////////////////////////////////////////////////
	// SDV
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Boat_SDV_CSAT						{ quality = 7; price = 120000; };
	class Exile_Boat_SDV_Digital					{ quality = 7; price = 120000; };
	class Exile_Boat_SDV_Grey						{ quality = 7; price = 120000; };
	///////////////////////////////////////////////////////////////////////////////
	///////////////////////////////////////////////////////////////////////////////
	// UH-1H Huey
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Chopper_Huey_Green 					{ quality = 4; price = 600000; };
	//class Exile_Chopper_Huey_Desert				{ quality = 4; price = 60000; };
	class Exile_Chopper_Huey_Armed_Green			{ quality = 4; price = 600000; };
	//class Exile_Chopper_Huey_Armed_Desert			{ quality = 4; price = 60000; };
	///////////////////////////////////////////////////////////////////////////////
	class B_Heli_Transport_03_unarmed_F             { quality = 5; price = 2500000; };																									 
	///////////////////////////////////////////////////////////////////////////////
	// Hellcat
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Chopper_Hellcat_Green				{ quality = 4; price = 275000; };
	class Exile_Chopper_Hellcat_FIA					{ quality = 4; price = 275000; };

	///////////////////////////////////////////////////////////////////////////////
	// Hummingbird (Civillian)
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Chopper_Hummingbird_Civillian_Blue				{ quality = 1; price = 17000; };
	class Exile_Chopper_Hummingbird_Civillian_Red				{ quality = 1; price = 17000; };
	class Exile_Chopper_Hummingbird_Civillian_ION				{ quality = 1; price = 17000; };
	class Exile_Chopper_Hummingbird_Civillian_BlueLine			{ quality = 1; price = 17000; };
	class Exile_Chopper_Hummingbird_Civillian_Digital			{ quality = 1; price = 17000; };
	class Exile_Chopper_Hummingbird_Civillian_Elliptical		{ quality = 1; price = 17000; };
	class Exile_Chopper_Hummingbird_Civillian_Furious			{ quality = 1; price = 17000; };
	class Exile_Chopper_Hummingbird_Civillian_GrayWatcher		{ quality = 1; price = 17000; };
	class Exile_Chopper_Hummingbird_Civillian_Jeans				{ quality = 1; price = 17000; };
	class Exile_Chopper_Hummingbird_Civillian_Light				{ quality = 1; price = 17000; };
	class Exile_Chopper_Hummingbird_Civillian_Shadow			{ quality = 1; price = 17000; };
	class Exile_Chopper_Hummingbird_Civillian_Sheriff			{ quality = 1; price = 17000; };
	class Exile_Chopper_Hummingbird_Civillian_Speedy			{ quality = 1; price = 17000; };
	class Exile_Chopper_Hummingbird_Civillian_Sunset			{ quality = 1; price = 100; sellPrice = 1; };
	class Exile_Chopper_Hummingbird_Civillian_Vrana				{ quality = 1; price = 17000; };
	class Exile_Chopper_Hummingbird_Civillian_Wasp				{ quality = 1; price = 17000; };
	class Exile_Chopper_Hummingbird_Civillian_Wave				{ quality = 1; price = 17000; };

	///////////////////////////////////////////////////////////////////////////////
	// Orca
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Chopper_Orca_CSAT								{ quality = 5; price = 850000; };
	class Exile_Chopper_Orca_Black								{ quality = 5; price = 850000; };
	class Exile_Chopper_Orca_BlackCustom						{ quality = 5; price = 850000; };

	///////////////////////////////////////////////////////////////////////////////
	// An-2
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Plane_AN2_Green									{ quality = 2; price = 170000; };
	class Exile_Plane_AN2_White									{ quality = 2; price = 170000; };
	class Exile_Plane_AN2_Stripe								{ quality = 2; price = 170000; };
	
	///////////////////////////////////////////////////////////////////////////////
	// Hatchback
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_Hatchback_Beige						{ quality = 1; price = 12000; };
	class Exile_Car_Hatchback_Green						{ quality = 1; price = 12000; };
	class Exile_Car_Hatchback_Blue						{ quality = 1; price = 12000; };
	class Exile_Car_Hatchback_BlueCustom				{ quality = 1; price = 12000; };
	class Exile_Car_Hatchback_BeigeCustom				{ quality = 1; price = 12000; };
	class Exile_Car_Hatchback_Yellow					{ quality = 1; price = 12000; };
	class Exile_Car_Hatchback_Grey						{ quality = 1; price = 12000; };
	class Exile_Car_Hatchback_Black						{ quality = 1; price = 12000; };
	class Exile_Car_Hatchback_Dark						{ quality = 1; price = 12000; };
	class Exile_Car_Hatchback_Rusty1					{ quality = 1; price = 12000; sellPrice = 10000; };
	class Exile_Car_Hatchback_Rusty2					{ quality = 1; price = 12000; sellPrice = 10000; };
	class Exile_Car_Hatchback_Rusty3					{ quality = 1; price = 12000; sellPrice = 10000; };

	///////////////////////////////////////////////////////////////////////////////
	// Golf
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_Golf_Red							{ quality = 1; price = 8000; };
	class Exile_Car_Golf_Black							{ quality = 1; price = 8000; };

	///////////////////////////////////////////////////////////////////////////////
	// Ural (Open)
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_Ural_Open_Blue			            { quality = 1; price = 25000; };
	class Exile_Car_Ural_Open_Yellow		            { quality = 1; price = 25000; };
	class Exile_Car_Ural_Open_Worker		            { quality = 1; price = 25000; };

	///////////////////////////////////////////////////////////////////////////////
	// Ural (Covered)
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_Ural_Covered_Blue			        { quality = 1; price = 28000; };
	class Exile_Car_Ural_Covered_Worker			        { quality = 1; price = 28000; };	

	///////////////////////////////////////////////////////////////////////////////
	// SUVXL
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_SUVXL_Black 				{ quality = 1; price = 25000; };

	///////////////////////////////////////////////////////////////////////////////
	// Tractor
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_Tractor_Red 				{ quality = 1; price = 2000; };

	///////////////////////////////////////////////////////////////////////////////
	// Tractor (Old)
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_OldTractor_Red 				{ quality = 1; price = 1200; };

	///////////////////////////////////////////////////////////////////////////////
	// Tow Tractor
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_TowTractor_White			{ quality = 1; price = 1800; };

	///////////////////////////////////////////////////////////////////////////////
	// Octavius
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_Octavius_White				{ quality = 1; price = 16000; };
	class Exile_Car_Octavius_Black				{ quality = 1; price = 16000; };

	///////////////////////////////////////////////////////////////////////////////
	// UAZ
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_UAZ_Green				{ quality = 1; price = 12000; };

	///////////////////////////////////////////////////////////////////////////////
	// UAZ (Open)
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_UAZ_Open_Green			{ quality = 1; price = 9000; };

	///////////////////////////////////////////////////////////////////////////////
	// Land Rover
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_LandRover_Red 				{ quality = 1; price = 11000; };
	class Exile_Car_LandRover_Urban 			{ quality = 1; price = 11000; };
	class Exile_Car_LandRover_Green 			{ quality = 1; price = 11000; };
	class Exile_Car_LandRover_Sand 				{ quality = 1; price = 11000; };
	class Exile_Car_LandRover_Desert 			{ quality = 1; price = 11000; };

	///////////////////////////////////////////////////////////////////////////////
	// Land Rover (Ambulance)
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_LandRover_Ambulance_Green		{ quality = 1; price = 12000; };
	class Exile_Car_LandRover_Ambulance_Desert		{ quality = 1; price = 12000; };
	class Exile_Car_LandRover_Ambulance_Sand		{ quality = 1; price = 12000; };

	///////////////////////////////////////////////////////////////////////////////
	// Lada
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_Lada_Green 				{ quality = 1; price = 6000; };
	class Exile_Car_Lada_Taxi 				{ quality = 1; price = 6000; };
	class Exile_Car_Lada_Red 				{ quality = 1; price = 6000; };
	class Exile_Car_Lada_White 				{ quality = 1; price = 6000; };
	class Exile_Car_Lada_Hipster 			{ quality = 1; price = 6000; };

	///////////////////////////////////////////////////////////////////////////////
	// Volha
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_Volha_Blue				{ quality = 1; price = 6000; };
	class Exile_Car_Volha_White				{ quality = 1; price = 6000; };
	class Exile_Car_Volha_Black				{ quality = 1; price = 6000; };

	///////////////////////////////////////////////////////////////////////////////
	// Hatchback (Sport)
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_Hatchback_Sport_Red					{ quality = 1; price = 14000; };
	class Exile_Car_Hatchback_Sport_Blue				{ quality = 1; price = 14000; };
	class Exile_Car_Hatchback_Sport_Orange				{ quality = 1; price = 14000; };
	class Exile_Car_Hatchback_Sport_White				{ quality = 1; price = 14000; };
	class Exile_Car_Hatchback_Sport_Beige				{ quality = 1; price = 14000; };
	class Exile_Car_Hatchback_Sport_Green				{ quality = 1; price = 14000; };

	///////////////////////////////////////////////////////////////////////////////
	// HEMMT
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_HEMMT 								{ quality = 1; price = 48000; };

	///////////////////////////////////////////////////////////////////////////////
	// Hunter
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_Hunter 								{ quality = 4; price = 65000; };

	///////////////////////////////////////////////////////////////////////////////
	// Ifrit
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_Ifrit 								{ quality = 4; price = 70000; };

	///////////////////////////////////////////////////////////////////////////////
	// Offroad
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_Offroad_Red							{ quality = 1; price = 16000; };
	class Exile_Car_Offroad_Beige						{ quality = 1; price = 16000; };
	class Exile_Car_Offroad_White						{ quality = 1; price = 16000; };
	class Exile_Car_Offroad_Blue						{ quality = 1; price = 16000; };
	class Exile_Car_Offroad_DarkRed						{ quality = 1; price = 16000; };
	class Exile_Car_Offroad_BlueCustom					{ quality = 1; price = 16000; };
	class Exile_Car_Offroad_Guerilla01					{ quality = 1; price = 16000; };
	class Exile_Car_Offroad_Guerilla02					{ quality = 1; price = 16000; };
	class Exile_Car_Offroad_Guerilla03					{ quality = 1; price = 16000; };
	class Exile_Car_Offroad_Guerilla04					{ quality = 1; price = 16000; };
	class Exile_Car_Offroad_Guerilla05					{ quality = 1; price = 16000; };
	class Exile_Car_Offroad_Guerilla06					{ quality = 1; price = 16000; };
	class Exile_Car_Offroad_Guerilla07					{ quality = 1; price = 16000; };
	class Exile_Car_Offroad_Guerilla08					{ quality = 1; price = 16000; };
	class Exile_Car_Offroad_Guerilla09					{ quality = 1; price = 16000; };
	class Exile_Car_Offroad_Guerilla10					{ quality = 1; price = 16000; };
	class Exile_Car_Offroad_Guerilla11					{ quality = 1; price = 16000; };
	class Exile_Car_Offroad_Guerilla12					{ quality = 1; price = 16000; };
	class Exile_Car_Offroad_Rusty1						{ quality = 1; price = 16000; };
	class Exile_Car_Offroad_Rusty2						{ quality = 1; price = 16000; };
	class Exile_Car_Offroad_Rusty3						{ quality = 1; price = 16000; };

	///////////////////////////////////////////////////////////////////////////////
	// Offroad (Armed)
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_Offroad_Armed_Guerilla01 			{ quality = 3; price = 25000; };
	class Exile_Car_Offroad_Armed_Guerilla02 			{ quality = 3; price = 25000; };
	class Exile_Car_Offroad_Armed_Guerilla03 			{ quality = 3; price = 25000; };
	class Exile_Car_Offroad_Armed_Guerilla04 			{ quality = 3; price = 25000; };
	class Exile_Car_Offroad_Armed_Guerilla05 			{ quality = 3; price = 25000; };
	class Exile_Car_Offroad_Armed_Guerilla06 			{ quality = 3; price = 25000; };
	class Exile_Car_Offroad_Armed_Guerilla07 			{ quality = 3; price = 25000; };
	class Exile_Car_Offroad_Armed_Guerilla08 			{ quality = 3; price = 25000; };
	class Exile_Car_Offroad_Armed_Guerilla09 			{ quality = 3; price = 25000; };
	class Exile_Car_Offroad_Armed_Guerilla10 			{ quality = 3; price = 25000; };
	class Exile_Car_Offroad_Armed_Guerilla11 			{ quality = 3; price = 25000; };
	class Exile_Car_Offroad_Armed_Guerilla12 			{ quality = 3; price = 25000; };

	///////////////////////////////////////////////////////////////////////////////
	// Offroad (Repair)
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_Offroad_Repair_Civillian 			{ quality = 1; price = 12500; };
	class Exile_Car_Offroad_Repair_Red 					{ quality = 1; price = 12500; };
	class Exile_Car_Offroad_Repair_Beige 				{ quality = 1; price = 12500; };
	class Exile_Car_Offroad_Repair_White 				{ quality = 1; price = 12500; };
	class Exile_Car_Offroad_Repair_Blue 				{ quality = 1; price = 12500; };
	class Exile_Car_Offroad_Repair_DarkRed 				{ quality = 1; price = 12500; };
	class Exile_Car_Offroad_Repair_BlueCustom 			{ quality = 1; price = 12500; };
	class Exile_Car_Offroad_Repair_Guerilla01 			{ quality = 1; price = 12500; };
	class Exile_Car_Offroad_Repair_Guerilla02 			{ quality = 1; price = 12500; };
	class Exile_Car_Offroad_Repair_Guerilla03 			{ quality = 1; price = 12500; };
	class Exile_Car_Offroad_Repair_Guerilla04 			{ quality = 1; price = 12500; };
	class Exile_Car_Offroad_Repair_Guerilla05 			{ quality = 1; price = 12500; };
	class Exile_Car_Offroad_Repair_Guerilla06 			{ quality = 1; price = 12500; };
	class Exile_Car_Offroad_Repair_Guerilla07 			{ quality = 1; price = 12500; };
	class Exile_Car_Offroad_Repair_Guerilla08 			{ quality = 1; price = 12500; };
	class Exile_Car_Offroad_Repair_Guerilla09 			{ quality = 1; price = 12500; };
	class Exile_Car_Offroad_Repair_Guerilla10 			{ quality = 1; price = 12500; };
	class Exile_Car_Offroad_Repair_Guerilla11 			{ quality = 1; price = 12500; };
	class Exile_Car_Offroad_Repair_Guerilla12 			{ quality = 1; price = 12500; };

	///////////////////////////////////////////////////////////////////////////////
	// Strider
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_Strider 							{ quality = 3; price = 90000; };

	///////////////////////////////////////////////////////////////////////////////
	// SUV
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_SUV_Red 							{ quality = 1; price = 25000; };
	class Exile_Car_SUV_Black 							{ quality = 1; price = 25000;  };
	class Exile_Car_SUV_Grey 							{ quality = 1; price = 25000;  };
	class Exile_Car_SUV_Orange 							{ quality = 1; price = 25000;  };

	///////////////////////////////////////////////////////////////////////////////
	// BRDM2
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_BRDM2_HQ 							{ quality = 3; price = 25000; };

	///////////////////////////////////////////////////////////////////////////////
	// BTR40
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_BTR40_MG_Green 						{ quality = 2; price = 50000; };
	class Exile_Car_BTR40_MG_Camo 						{ quality = 2; price = 50000; };
	class Exile_Car_BTR40_Green 						{ quality = 1; price = 30000; };
	class Exile_Car_BTR40_Camo 							{ quality = 1; price = 30000; sellPrice = 0; };

	///////////////////////////////////////////////////////////////////////////////
	// HMMWV
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_HMMWV_M134_Green 					{ quality = 3; price = 33000; sellPrice = 20000; };
	class Exile_Car_HMMWV_M134_Desert 					{ quality = 3; price = 33000; sellPrice = 20000; };
	class Exile_Car_HMMWV_MEV_Green 					{ quality = 1; price = 21000; sellPrice = 12000; };
	class Exile_Car_HMMWV_MEV_Desert 					{ quality = 1; price = 21000; sellPrice = 12000; };
	class Exile_Car_HMMWV_UNA_Green 					{ quality = 1; price = 21000; sellPrice = 12000; };
	class Exile_Car_HMMWV_UNA_Desert 					{ quality = 1; price = 21000; sellPrice = 12000; };

	///////////////////////////////////////////////////////////////////////////////
	// Tempest
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_Tempest 							{ quality = 1; price = 48300; sellprice = 20000; };

	///////////////////////////////////////////////////////////////////////////////
	// Van
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_Van_Black 							{ quality = 1; price = 12000; };
	class Exile_Car_Van_Red 							{ quality = 1; price = 12000; };
	class Exile_Car_Van_Guerilla01 						{ quality = 1; price = 12000; };
	class Exile_Car_Van_Guerilla02 						{ quality = 1; price = 12000; };
	class Exile_Car_Van_Guerilla03 						{ quality = 1; price = 12000; };
	class Exile_Car_Van_Guerilla04 						{ quality = 1; price = 12000; };
	class Exile_Car_Van_Guerilla05 						{ quality = 1; price = 12000; };
	class Exile_Car_Van_Guerilla06 						{ quality = 1; price = 12000; };
	class Exile_Car_Van_Guerilla07 						{ quality = 1; price = 12000; };
	class Exile_Car_Van_Guerilla08 						{ quality = 1; price = 12000; };

	///////////////////////////////////////////////////////////////////////////////
	// Van (Box)
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_Van_Box_Black 						{ quality = 1; price = 17000; };
	class Exile_Car_Van_Box_White 						{ quality = 1; price = 17000; };
	class Exile_Car_Van_Box_Red 						{ quality = 1; price = 17000; };
	class Exile_Car_Van_Box_Guerilla01 					{ quality = 1; price = 17000; };
	class Exile_Car_Van_Box_Guerilla02 					{ quality = 1; price = 17000; };
	class Exile_Car_Van_Box_Guerilla04 					{ quality = 1; price = 17000; };
	class Exile_Car_Van_Box_Guerilla05 					{ quality = 1; price = 17000; };
	class Exile_Car_Van_Box_Guerilla06 					{ quality = 1; price = 17000; };
	class Exile_Car_Van_Box_Guerilla07 					{ quality = 1; price = 17000; };
	class Exile_Car_Van_Box_Guerilla08 					{ quality = 1; price = 17000; };

	///////////////////////////////////////////////////////////////////////////////
	// Van (Fuel)
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_Van_Fuel_Black 						{ quality = 1; price = 15000; };
	class Exile_Car_Van_Fuel_White 						{ quality = 1; price = 15000; };
	class Exile_Car_Van_Fuel_Guerilla01 				{ quality = 1; price = 15000; };
	class Exile_Car_Van_Fuel_Guerilla02 				{ quality = 1; price = 15000; };
	class Exile_Car_Van_Fuel_Guerilla03 				{ quality = 1; price = 15000; };

	///////////////////////////////////////////////////////////////////////////////
	// Zamak
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_Zamak 								{ quality = 1; price = 43000; };

	///////////////////////////////////////////////////////////////////////////////
	// Ceaser BTT
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Plane_Ceasar							{ quality = 2; price = 15000; };


	///////////////////////////////////////////////////////////////////////////////
	// Prowler
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_ProwlerLight						{ quality = 3; price = 22000; };
	class Exile_Car_ProwlerUnarmed						{ quality = 3; price = 22000; sellPrice = 100; };


	///////////////////////////////////////////////////////////////////////////////
	// MB 4WD
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Car_MB4WD							    { quality = 1; price = 15000; };
	class Exile_Car_MB4WDOpen							{ quality = 1; price = 15000; };

	///////////////////////////////////////////////////////////////////////////////
	// Flags
	///////////////////////////////////////////////////////////////////////////////
	class Exile_Item_FlagStolen1						{ quality = 1; price = 50000;  sellPrice = 5000;  };
	class Exile_Item_FlagStolen2						{ quality = 1; price = 100000; sellPrice = 10000; };
	class Exile_Item_FlagStolen3						{ quality = 1; price = 150000; sellPrice = 15000; };
	class Exile_Item_FlagStolen4						{ quality = 1; price = 200000; sellPrice = 20000; };
	class Exile_Item_FlagStolen5						{ quality = 1; price = 250000; sellPrice = 25000; };
	class Exile_Item_FlagStolen6						{ quality = 1; price = 300000; sellPrice = 30000; };
	class Exile_Item_FlagStolen7						{ quality = 1; price = 350000; sellPrice = 35000; };
	class Exile_Item_FlagStolen8						{ quality = 1; price = 400000; sellPrice = 40000; };
	class Exile_Item_FlagStolen9						{ quality = 1; price = 450000; sellPrice = 45000; };
	class Exile_Item_FlagStolen10						{ quality = 1; price = 500000; sellPrice = 50000; };
	
	//строительные материалы
	class Exile_Item_WoodDrawBridgeKit					{ quality = 4; price = 7500; sellprice = 50;};
	class Exile_Item_WoodFloorPortSmallKit				{ quality = 4; price = 7000; sellprice = 50;};
	class Exile_Item_WoodLadderKit						{ quality = 4; price = 6500; sellprice = 50;};
	class Exile_Item_RepairKitConcrete					{ quality = 4; price = 7000; sellprice = 50;};
	class Exile_Item_WoodDoorKit						{ quality = 4; price = 6500; sellprice = 50;}; 
	class Exile_Item_WoodDoorwayKit						{ quality = 4; price = 7500; sellprice = 50;};
	class Exile_Item_WoodFloorKit						{ quality = 4; price = 7500; sellprice = 50;};
	class Exile_Item_WoodFloorPortKit					{ quality = 4; price = 7500; sellprice = 50;};
	class Exile_Item_WoodGateKit						{ quality = 4; price = 10000; sellprice = 50;};
	class Exile_Item_WoodStairsKit						{ quality = 4; price = 6000 ;sellprice = 50;};
	class Exile_Item_WoodSupportKit						{ quality = 4; price = 6000 ; sellprice = 50; };
	class Exile_Item_WoodWallKit						{ quality = 4; price = 7500; sellprice = 50; };
	class Exile_Item_WoodWallHalfKit					{ quality = 4; price = 5000; sellprice = 50; };
	class Exile_Item_WoodWindowKit						{ quality = 4; price = 7500; sellprice = 50;};
	class Exile_Item_WorkBenchKit						{ quality = 4; price = 8500; sellprice = 50;};
	class Exile_Item_ConcreteDoorKit					{ quality = 6; price = 16000; sellprice = 50;};
	class Exile_Item_ConcreteDoorwayKit					{ quality = 6; price = 15500; sellprice = 50;};
	class Exile_Item_ConcreteFloorKit					{ quality = 6; price = 15000; sellprice = 50;};
	class Exile_Item_ConcreteFloorPortKit				{ quality = 6; price = 15500; sellprice = 50;};
	class Exile_Item_ConcreteGateKit					{ quality = 6; price = 18000; sellprice = 50;};
	class Exile_Item_ConcreteWindowKit					{ quality = 6; price = 16000; sellprice = 50;};
	class Exile_Item_ConcreteStairsKit					{ quality = 6; price = 15000; sellprice = 50;};
	class Exile_Item_ConcreteSupportKit					{ quality = 6; price = 10000; sellprice = 50;};
	class Exile_Item_ConcreteWallKit					{ quality = 6; price = 15000; sellprice = 50;};
	//1.0.4 build	
	class Exile_Item_ConcreteDrawBridgeKit		        { quality = 6; price = 20000; sellPrice = 50; };
	class Exile_Item_ConcreteFloorPortSmallKit	        { quality = 6; price = 14500; sellPrice = 50;};
	class Exile_Item_ConcreteLadderHatchKit		        { quality = 6; price = 18500; sellPrice = 50;};
	class Exile_Item_WoodLadderHatchKit			        { quality = 6; price = 10000; sellPrice = 50;};
	class Exile_Item_OldChestKit				        { quality = 6; price = 10000; sellPrice = 50;};
    class Exile_Item_MetalLadderKit						{ quality = 6; price = 12000; sellPrice = 50;};
    class Exile_Item_MetalLadderDoubleKit				{ quality = 6; price = 14000; sellPrice = 50;};
	class Exile_Item_CampFireKit						{ quality = 1; price = 9000; sellPrice = 50;};
	class Exile_Item_FloodLightKit						{ quality = 1; price = 6800; sellPrice = 50;};
	class Exile_Item_PortableGeneratorKit				{ quality = 1; price = 6000; sellPrice = 50;};
	class Exile_Container_StoragecrateKit				{ quality = 1; price = 9000; sellPrice = 50;};
	class Exile_Item_FortificationUpgrade			    { quality = 1; price = 10000; sellPrice = 50;};
	class Exile_Item_SandBagsKit_Long					{ quality = 6; price = 3500; sellPrice = 50;};
	//class Exile_Melee_SledgeHammmer						{ quality = 6; price = 500; };
	class Exile_Item_SandBagsKit_Corner					{ quality = 6; price = 5800; sellPrice = 50;};
	class Exile_Item_HBarrier5Kit						{ quality = 6; price = 7000; sellPrice = 50;};
	class Exile_Item_WireFenceKit 					    { quality = 6; price = 5000; sellPrice = 50;};
	class Exile_Item_Shovel						        { quality = 6; price = 3700; sellPrice = 50;};
	
	
	class O_Plane_CAS_02_F  							{ quality = 6; price = 470000; };
	class I_Plane_Fighter_03_CAS_F  					{ quality = 6; price = 480000; };

	//мои ст. минометы
	class I_Mortar_01_support_F							{ quality = 4; price = 2500; };
	class I_Mortar_01_weapon_F							{ quality = 4; price = 3000000; sellprice = 300000; };
	//стац.пулеметы
	class B_HMG_01_A_weapon_F							{ quality = 4; price = 2500; };
	class B_HMG_01_support_high_F						{ quality = 4; price = 15000; };
	//ВСЕ ТРУБЫ
	
	class launch_RPG32_F								{ quality = 4; price = 6500; sellprice = 600; };
	class RPG32_F										{ quality = 4; price = 800; sellprice = 300; };
	class RPG32_HE_F									{ quality = 4; price = 800; sellprice = 300; };
	class Titan_AA										{ quality = 4; price = 60800; sellprice = 5300; };
	class launch_O_Titan_F								{ quality = 4; price = 60500; sellprice = 5600; };
	class launch_B_Titan_F								{ quality = 4; price = 60500; sellprice = 5600; };
	class launch_I_Titan_F								{ quality = 4; price = 60500; sellprice = 5600; };
	class launch_O_Titan_short_F						{ quality = 4; price = 60500; sellprice = 5600; };
	class launch_I_Titan_short_F						{ quality = 4; price = 60500; sellprice = 5600; };
	class launch_B_Titan_short_F						{ quality = 4; price = 60500; sellprice = 5600; };
	class Titan_AT										{ quality = 4; price = 50800; sellprice = 5300; };
	class Titan_AP										{ quality = 4; price = 50800; sellprice = 300; };
	class NLAW_F										{ quality = 4; price = 800; sellprice = 300; };
	class launch_NLAW_F									{ quality = 4; price = 6500; sellprice = 600; };
	class I_Heli_light_03_F								{ quality = 3; price = 110000; };

	class Ural_RU										{ quality = 4; price = 70000; };

    //VR костюмы			
	class U_I_Protagonist_VR						    { quality = 7; price = 400000; };
	class U_O_Protagonist_VR						    { quality = 7; price = 400000; };
	class U_B_Protagonist_VR						    { quality = 7; price = 400000; }; 
	
	//class UH1H_M240									    { quality = 1; price = 60000; sellPrice = 20000; };
	
	///////////////////////////////////////////////////////////////////////////////
    // CUP Units Price List
    ///////////////////////////////////////////////////////////////////////////////

	///// Uniforms
	class CUP_U_O_RUS_Ratnik_Summer   	                             { quality = 5; price = 1000; };
   	class CUP_O_TKI_Khet_Partug_01                                   { quality = 2; price = 80; };
	class CUP_O_TKI_Khet_Partug_02                                   { quality = 2; price = 80; };
	class CUP_O_TKI_Khet_Partug_03                                   { quality = 2; price = 80; };
	class CUP_O_TKI_Khet_Partug_04                                   { quality = 2; price = 80; };
	class CUP_O_TKI_Khet_Partug_05                                   { quality = 2; price = 80; };
	class CUP_O_TKI_Khet_Partug_06                                   { quality = 2; price = 80; };
	class CUP_O_TKI_Khet_Partug_07                                   { quality = 2; price = 80; };
	class CUP_O_TKI_Khet_Partug_08                                   { quality = 2; price = 80; };
	class CUP_O_TKI_Khet_Jeans_01                                    { quality = 2; price = 80; };
	class CUP_O_TKI_Khet_Jeans_02                                    { quality = 2; price = 80; };
	class CUP_O_TKI_Khet_Jeans_03                                    { quality = 2; price = 80; };
	class CUP_O_TKI_Khet_Jeans_04                                    { quality = 2; price = 80; };
	class CUP_U_C_Pilot_01                                           { quality = 2; price = 80; };
	class CUP_U_C_Citizen_01                                         { quality = 2; price = 80; };
	class CUP_U_C_Citizen_02                                         { quality = 2; price = 80; };
	class CUP_U_C_Citizen_03                                         { quality = 2; price = 80; };
	class CUP_U_C_Citizen_04                                         { quality = 2; price = 80; };
	class CUP_U_C_Worker_01                                          { quality = 2; price = 80; };
	class CUP_U_C_Worker_02                                          { quality = 2; price = 80; };
	class CUP_U_C_Worker_03                                          { quality = 2; price = 80; };
	class CUP_U_C_Worker_04                                          { quality = 2; price = 80; };
	class CUP_U_C_Profiteer_01                                       { quality = 2; price = 80; };
	class CUP_U_C_Profiteer_02                                       { quality = 2; price = 80; };
	class CUP_U_C_Profiteer_03                                       { quality = 2; price = 80; };
	class CUP_U_C_Profiteer_04                                       { quality = 2; price = 80; };
	class CUP_U_C_Woodlander_01                                      { quality = 2; price = 80; };
	class CUP_U_C_Woodlander_02                                      { quality = 2; price = 80; };
	class CUP_U_C_Woodlander_03                                      { quality = 2; price = 80; };
	class CUP_U_C_Woodlander_04                                      { quality = 2; price = 80; };
	class CUP_U_C_Villager_01                                        { quality = 2; price = 80; };
	class CUP_U_C_Villager_02                                        { quality = 2; price = 80; };
	class CUP_U_C_Villager_03                                        { quality = 2; price = 80; };
	class CUP_U_C_Villager_04                                        { quality = 2; price = 80; };
	class CUP_U_B_CZ_WDL_TShirt                                      { quality = 2; price = 80; };
	class CUP_U_B_GER_Tropentarn_1                                   { quality = 2; price = 80; };
	class CUP_U_B_GER_Tropentarn_2                                   { quality = 2; price = 80; };
	class CUP_U_B_GER_Ghillie                                        { quality = 2; price = 80; };
	class CUP_U_B_GER_Flecktarn_1                                    { quality = 2; price = 80; };
	class CUP_U_B_GER_Flecktarn_2                                    { quality = 2; price = 80; };
	class CUP_U_B_GER_Fleck_Ghillie                                  { quality = 2; price = 80; };
	class CUP_U_B_USMC_Officer                                       { quality = 2; price = 80; };
	class CUP_U_B_USMC_PilotOverall                                  { quality = 2; price = 80; };
	class CUP_U_B_USMC_Ghillie_WDL                                   { quality = 2; price = 80; };
	class CUP_U_B_USMC_MARPAT_WDL_Sleeves                            { quality = 2; price = 80; };
	class CUP_U_B_USMC_MARPAT_WDL_RolledUp                           { quality = 2; price = 80; };
	class CUP_U_B_USMC_MARPAT_WDL_Kneepad                            { quality = 2; price = 80; };
	class CUP_U_B_USMC_MARPAT_WDL_TwoKneepads                        { quality = 2; price = 80; };
	class CUP_U_B_USMC_MARPAT_WDL_RollUpKneepad                      { quality = 2; price = 80; };
	class CUP_U_B_FR_SpecOps                                         { quality = 2; price = 80; };
	class CUP_U_B_FR_Scout                                           { quality = 2; price = 80; };
	class CUP_U_B_FR_Scout1                                          { quality = 2; price = 80; };
	class CUP_U_B_FR_Scout2                                          { quality = 2; price = 80; };
	class CUP_U_B_FR_Scout3                                          { quality = 2; price = 80; };
	class CUP_U_B_FR_Officer                                         { quality = 2; price = 80; };
	class CUP_U_B_FR_Corpsman                                        { quality = 2; price = 80; };
	class CUP_U_B_FR_DirAction                                       { quality = 2; price = 80; };
	class CUP_U_B_FR_DirAction2                                      { quality = 2; price = 80; };
	class CUP_U_B_FR_Light                                           { quality = 2; price = 80; };
	class CUP_U_I_GUE_Flecktarn                                      { quality = 2; price = 80; };
	class CUP_U_I_GUE_Flecktarn2                                     { quality = 2; price = 80; };
	class CUP_U_I_GUE_Flecktarn3                                     { quality = 2; price = 80; };
	class CUP_U_I_GUE_Woodland1                                      { quality = 2; price = 80; };
	class CUP_U_I_Ghillie_Top                                        { quality = 2; price = 80; };
	class CUP_U_I_RACS_PilotOverall                                  { quality = 2; price = 80; };
	class CUP_U_I_RACS_Desert_1                                      { quality = 2; price = 80; };
	class CUP_U_I_RACS_Desert_2                                      { quality = 2; price = 80; };
	class CUP_U_I_RACS_Urban_1                                       { quality = 2; price = 80; };
	class CUP_U_I_RACS_Urban_2                                       { quality = 2; price = 80; };
	class CUP_U_O_SLA_Officer                                        { quality = 2; price = 80; };
	class CUP_U_O_SLA_Officer_Suit                                   { quality = 2; price = 80; };
	class CUP_U_O_SLA_MixedCamo                                      { quality = 2; price = 80; };
	class CUP_U_O_SLA_Green                                          { quality = 2; price = 80; };
	class CUP_U_O_SLA_Urban                                          { quality = 2; price = 80; };
	class CUP_U_O_SLA_Desert                                         { quality = 2; price = 80; };
	class CUP_U_O_SLA_Overalls_Pilot                                 { quality = 2; price = 80; };
	class CUP_U_O_SLA_Overalls_Tank                                  { quality = 2; price = 80; };
	class CUP_U_O_Partisan_TTsKO                                     { quality = 2; price = 80; };
	class CUP_U_O_Partisan_TTsKO_Mixed                               { quality = 2; price = 80; };
	class CUP_U_O_Partisan_VSR_Mixed1                                { quality = 2; price = 80; };
	class CUP_U_O_Partisan_VSR_Mixed2                                { quality = 2; price = 80; };
	class CUP_U_O_TK_Officer                                         { quality = 2; price = 80; };
	class CUP_U_O_TK_MixedCamo                                       { quality = 2; price = 80; };
	class CUP_U_O_TK_Green                                           { quality = 2; price = 80; };
	class CUP_U_O_TK_Ghillie                                         { quality = 2; price = 80; };
	class CUP_U_O_TK_Ghillie_Top                                     { quality = 2; price = 80; };
	class CUP_U_B_BAF_DDPM_S1_RolledUp                               { quality = 2; price = 80; };
	class CUP_U_B_BAF_DDPM_Tshirt                                    { quality = 2; price = 80; };
	class CUP_U_B_BAF_DPM_S1_RolledUp                                { quality = 2; price = 80; };
	class CUP_U_B_BAF_DPM_S2_UnRolled                                { quality = 2; price = 80; };
	class CUP_U_B_BAF_DPM_Tshirt                                     { quality = 2; price = 80; };
	class CUP_U_B_BAF_MTP_S1_RolledUp                                { quality = 2; price = 80; };
	class CUP_U_B_BAF_MTP_S2_UnRolled                                { quality = 2; price = 80; };
	class CUP_U_B_BAF_MTP_Tshirt                                     { quality = 2; price = 80; };
	class CUP_U_B_BAF_MTP_S3_RolledUp                                { quality = 2; price = 80; };
	class CUP_U_B_BAF_MTP_S4_UnRolled                                { quality = 2; price = 80; };
	class CUP_U_B_BAF_MTP_S5_UnRolled                                { quality = 2; price = 80; };
	class CUP_U_B_BAF_MTP_S6_UnRolled                                { quality = 2; price = 80; };
	//// Backpacks
	class CUP_O_RUS_Patrol_bag_Green                                 { quality = 5; price = 800; };
	class CUP_B_Bergen_BAF											 { quality = 2; price = 200; };
	class CUP_B_GER_Pack_Tropentarn                                  { quality = 2; price = 200; };
	class CUP_B_GER_Pack_Flecktarn                                   { quality = 2; price = 200; };
	class CUP_B_HikingPack_Civ                                       { quality = 2; price = 200; };
	class CUP_B_RUS_Backpack                                         { quality = 2; price = 200; };
	class CUP_B_CivPack_WDL                                          { quality = 2; price = 200; };
	class CUP_B_USPack_Coyote                                        { quality = 2; price = 200; };
	class CUP_B_AssaultPack_ACU                                      { quality = 2; price = 200; };
	class CUP_B_AssaultPack_Coyote                                   { quality = 2; price = 200; };
	class CUP_B_USMC_AssaultPack                                     { quality = 2; price = 200; };
	class CUP_B_USMC_MOLLE                                           { quality = 2; price = 200; };
	//class CUP_B_MOLLE_WDL                                            { quality = 2; price = 200; };
	class CUP_B_USPack_Black                                         { quality = 2; price = 200; };
	class CUP_B_ACRPara_m95                                          { quality = 2; price = 200; };
	class CUP_B_AssaultPack_Black                                    { quality = 2; price = 200; };
	//// Headgear
	class CUP_H_RUS_Balaclava_Ratnik_Headphones                      { quality = 5; price = 200; };
	class CUP_H_C_Ushanka_01                                         { quality = 2; price = 60; };
	class CUP_H_C_Ushanka_02                                         { quality = 2; price = 60; };
	class CUP_H_C_Ushanka_03                                         { quality = 2; price = 60; };
	class CUP_H_C_Ushanka_04                                         { quality = 2; price = 60; };
	class CUP_H_C_Beanie_01                                          { quality = 2; price = 60; };
	class CUP_H_C_Beanie_02                                          { quality = 2; price = 60; };
	class CUP_H_C_Beanie_03                                          { quality = 2; price = 60; };
	class CUP_H_C_Beanie_04                                          { quality = 2; price = 60; };
	class CUP_H_C_Beret_01                                           { quality = 2; price = 60; };
	class CUP_H_C_Beret_02                                           { quality = 2; price = 60; };
	class CUP_H_C_Beret_03                                           { quality = 2; price = 60; };
	class CUP_H_C_Beret_04                                           { quality = 2; price = 60; };
	class CUP_H_GER_Boonie_desert                                    { quality = 2; price = 60; };
	class CUP_H_GER_Boonie_Flecktarn                                 { quality = 2; price = 60; };
	class CUP_H_NAPA_Fedora                                          { quality = 2; price = 60; };
	class CUP_H_PMC_PRR_Headset                                      { quality = 2; price = 60; };
	class CUP_H_PMC_EP_Headset                                       { quality = 2; price = 60; };
	class CUP_H_PMC_Cap_Tan                                          { quality = 2; price = 60; };
	class CUP_H_PMC_Cap_Grey                                         { quality = 2; price = 60; };
	class CUP_H_PMC_Cap_PRR_Tan                                      { quality = 2; price = 60; };
	class CUP_H_PMC_Cap_PRR_Grey                                     { quality = 2; price = 60; };
	class CUP_H_RACS_Beret_Blue                                      { quality = 2; price = 60; };
	class CUP_H_RACS_Helmet_Des                                      { quality = 2; price = 60; };
	class CUP_H_RACS_Helmet_Goggles_Des                              { quality = 2; price = 60; };
	class CUP_H_RACS_Helmet_Headset_Des                              { quality = 2; price = 60; };
	class CUP_H_RACS_Helmet_DPAT                                     { quality = 2; price = 60; };
	class CUP_H_RACS_Helmet_Goggles_DPAT                             { quality = 2; price = 60; };
	class CUP_H_RACS_Helmet_Headset_DPAT                             { quality = 2; price = 60; };
	class CUP_H_SLA_TankerHelmet                                     { quality = 2; price = 60; };
	class CUP_H_SLA_Helmet                                           { quality = 2; price = 60; };
	class CUP_H_SLA_Pilot_Helmet                                     { quality = 2; price = 60; };
	class CUP_H_SLA_OfficerCap                                       { quality = 2; price = 60; };
	class CUP_H_SLA_SLCap                                            { quality = 2; price = 60; };
	class CUP_H_SLA_Boonie                                           { quality = 2; price = 60; };
	class CUP_H_SLA_Beret                                            { quality = 2; price = 60; };
	class CUP_H_SLA_BeretRed                                         { quality = 2; price = 60; };
	class CUP_H_TK_TankerHelmet                                      { quality = 2; price = 60; };
	class CUP_H_TK_PilotHelmet                                       { quality = 2; price = 60; };
	class CUP_H_TK_Helmet                                            { quality = 2; price = 60; };
	class CUP_H_TK_Lungee                                            { quality = 2; price = 60; };
	class CUP_H_TK_Beret                                             { quality = 2; price = 60; };
	class CUP_H_TKI_SkullCap_01                                      { quality = 2; price = 60; };
	class CUP_H_TKI_SkullCap_02                                      { quality = 2; price = 60; };
	class CUP_H_TKI_SkullCap_03                                      { quality = 2; price = 60; };
	class CUP_H_TKI_SkullCap_04                                      { quality = 2; price = 60; };
	class CUP_H_TKI_SkullCap_05                                      { quality = 2; price = 60; };
	class CUP_H_TKI_SkullCap_06                                      { quality = 2; price = 60; };
	class CUP_H_TKI_Lungee_01                                        { quality = 2; price = 60; };
	class CUP_H_TKI_Lungee_03                                        { quality = 2; price = 60; };
	class CUP_H_TKI_Lungee_04                                        { quality = 2; price = 60; };
	class CUP_H_TKI_Lungee_05                                        { quality = 2; price = 60; };
	class CUP_H_TKI_Lungee_06                                        { quality = 2; price = 60; };
	class CUP_H_TKI_Lungee_Open_01                                   { quality = 2; price = 60; };
	class CUP_H_TKI_Lungee_Open_02                                   { quality = 2; price = 60; };
	class CUP_H_TKI_Lungee_Open_03                                   { quality = 2; price = 60; };
	class CUP_H_TKI_Lungee_Open_04                                   { quality = 2; price = 60; };
	class CUP_H_TKI_Lungee_Open_05                                   { quality = 2; price = 60; };
	class CUP_H_TKI_Lungee_Open_06                                   { quality = 2; price = 60; };
	class CUP_H_TKI_Pakol_1_01                                       { quality = 2; price = 60; };
	class CUP_H_TKI_Pakol_1_02                                       { quality = 2; price = 60; };
	class CUP_H_TKI_Pakol_1_03                                       { quality = 2; price = 60; };
	class CUP_H_TKI_Pakol_1_04                                       { quality = 2; price = 60; };
	class CUP_H_TKI_Pakol_1_05                                       { quality = 2; price = 60; };
	class CUP_H_TKI_Pakol_1_06                                       { quality = 2; price = 60; };
	class CUP_H_TKI_Pakol_2_01                                       { quality = 2; price = 60; };
	class CUP_H_TKI_Pakol_2_02                                       { quality = 2; price = 60; };
	class CUP_H_TKI_Pakol_2_03                                       { quality = 2; price = 60; };
	class CUP_H_TKI_Pakol_2_04                                       { quality = 2; price = 60; };
	class CUP_H_TKI_Pakol_2_05                                       { quality = 2; price = 60; };
	class CUP_H_TKI_Pakol_2_06                                       { quality = 2; price = 60; };
	class CUP_H_USMC_Officer_Cap                                     { quality = 2; price = 60; };
	class CUP_H_USMC_HelmetWDL                                       { quality = 2; price = 60; };
	class CUP_H_USMC_HeadSet_HelmetWDL                               { quality = 2; price = 60; };
	class CUP_H_USMC_HeadSet_GoggleW_HelmetWDL                       { quality = 2; price = 60; };
	class CUP_H_USMC_Crew_Helmet                                     { quality = 2; price = 60; };
	class CUP_H_USMC_Goggles_HelmetWDL                               { quality = 2; price = 60; };
	class CUP_H_USMC_Helmet_Pilot                                    { quality = 2; price = 60; };
	class CUP_H_FR_Headset                                           { quality = 2; price = 60; };
	class CUP_H_FR_Cap_Headset_Green                                 { quality = 2; price = 60; };
	class CUP_H_FR_Cap_Officer_Headset                               { quality = 2; price = 60; };
	class CUP_H_FR_BandanaGreen                                      { quality = 2; price = 60; };
	class CUP_H_FR_BandanaWdl                                        { quality = 2; price = 60; };
	class CUP_H_FR_Bandana_Headset                                   { quality = 2; price = 60; };
	class CUP_H_FR_Headband_Headset                                  { quality = 2; price = 60; };
	class CUP_H_FR_ECH                                               { quality = 2; price = 60; };
	class CUP_H_FR_BoonieMARPAT                                      { quality = 2; price = 60; };
	class CUP_H_FR_BoonieWDL                                         { quality = 2; price = 60; };
	class CUP_H_FR_BeanieGreen                                       { quality = 2; price = 60; };
	class CUP_H_FR_PRR_BoonieWDL                                     { quality = 2; price = 60; };
	class CUP_H_Navy_CrewHelmet_Blue                                 { quality = 2; price = 60; };
	class CUP_H_Navy_CrewHelmet_Brown                                { quality = 2; price = 60; };
	class CUP_H_Navy_CrewHelmet_Green                                { quality = 2; price = 60; };
	class CUP_H_Navy_CrewHelmet_Red                                  { quality = 2; price = 60; };
	class CUP_H_Navy_CrewHelmet_Violet                               { quality = 2; price = 60; };
	class CUP_H_Navy_CrewHelmet_White                                { quality = 2; price = 60; };
	class CUP_H_Navy_CrewHelmet_Yellow                               { quality = 2; price = 60; };    
    class CUP_H_BAF_Officer_Beret_PRR_O								 { quality = 2; price = 60; };   
	class CUP_H_BAF_Helmet_1_DDPM								     { quality = 2; price = 60; };   	
	class CUP_H_BAF_Helmet_2_DDPM								     { quality = 2; price = 60; }; 
	class CUP_H_BAF_Helmet_3_DDPM								     { quality = 2; price = 60; }; 
	class CUP_H_BAF_Helmet_4_DDPM								     { quality = 2; price = 60; }; 
	class CUP_H_BAF_Helmet_1_DPM								     { quality = 2; price = 60; }; 
	class CUP_H_BAF_Helmet_2_DPM								     { quality = 2; price = 60; }; 
	class CUP_H_BAF_Helmet_3_DPM								     { quality = 2; price = 60; }; 
	class CUP_H_BAF_Helmet_4_DPM								     { quality = 2; price = 60; }; 
	class CUP_H_BAF_Helmet_1_MTP								     { quality = 2; price = 60; }; 
	class CUP_H_BAF_Helmet_2_MTP								     { quality = 2; price = 60; }; 
	class CUP_H_BAF_Helmet_3_MTP								     { quality = 2; price = 60; }; 
	class CUP_H_BAF_Helmet_4_MTP								     { quality = 2; price = 60; }; 
	

	///// Rigs
	class CUP_V_B_GER_Carrier_Rig                                    { quality = 2; price = 70; };
	class CUP_V_B_GER_Carrier_Rig_2                                  { quality = 2; price = 70; };
	class CUP_V_B_GER_Carrier_Vest                                   { quality = 2; price = 70; };
	class CUP_V_B_GER_Carrier_Vest_2                                 { quality = 2; price = 70; };
	class CUP_V_B_GER_Carrier_Vest_3                                 { quality = 2; price = 70; };
	class CUP_V_B_GER_Vest_1                                         { quality = 2; price = 70; };
	class CUP_V_B_GER_Vest_2                                         { quality = 2; price = 70; };
	class CUP_V_B_MTV                                                { quality = 2; price = 70; };
	class CUP_V_B_MTV_Patrol                                         { quality = 2; price = 70; };
	class CUP_V_B_MTV_Pouches                                        { quality = 2; price = 70; };
	class CUP_V_B_MTV_noCB                                           { quality = 2; price = 70; };
	class CUP_V_B_MTV_Marksman                                       { quality = 2; price = 70; };
	class CUP_V_B_MTV_PistolBlack                                    { quality = 2; price = 70; };
	class CUP_V_B_MTV_LegPouch                                       { quality = 2; price = 70; };
	class CUP_V_B_MTV_MG                                             { quality = 2; price = 70; };
	class CUP_V_B_MTV_Mine                                           { quality = 2; price = 70; };
	class CUP_V_B_MTV_TL                                             { quality = 2; price = 70; };
	class CUP_V_B_PilotVest                                          { quality = 2; price = 70; };
	class CUP_V_B_RRV_TL                                             { quality = 2; price = 70; };
	class CUP_V_B_RRV_Officer                                        { quality = 2; price = 70; };
	class CUP_V_B_RRV_Medic                                          { quality = 2; price = 70; };
	class CUP_V_B_RRV_DA1                                            { quality = 2; price = 70; };
	class CUP_V_B_RRV_DA2                                            { quality = 2; price = 70; };
	class CUP_V_B_RRV_MG                                             { quality = 2; price = 70; };
	class CUP_V_B_RRV_Light                                          { quality = 2; price = 70; };
	class CUP_V_B_RRV_Scout                                          { quality = 2; price = 70; };
	class CUP_V_B_RRV_Scout2                                         { quality = 2; price = 70; };
	class CUP_V_B_RRV_Scout3                                         { quality = 2; price = 70; };
	class CUP_V_B_LHDVest_Blue                                       { quality = 2; price = 70; };
	class CUP_V_B_LHDVest_Brown                                      { quality = 2; price = 70; };
	class CUP_V_B_LHDVest_Green                                      { quality = 2; price = 70; };
	class CUP_V_B_LHDVest_Red                                        { quality = 2; price = 70; };
	class CUP_V_B_LHDVest_Violet                                     { quality = 2; price = 70; };
	class CUP_V_B_LHDVest_White                                      { quality = 2; price = 70; };
	class CUP_V_B_LHDVest_Yellow                                     { quality = 2; price = 70; };
	class CUP_V_I_Carrier_Belt                                       { quality = 2; price = 70; };
	class CUP_V_I_Guerilla_Jacket                                    { quality = 2; price = 70; };
	class CUP_V_I_RACS_Carrier_Vest                                  { quality = 2; price = 70; };
	class CUP_V_I_RACS_Carrier_Vest_2                                { quality = 2; price = 70; };
	class CUP_V_I_RACS_Carrier_Vest_3                                { quality = 2; price = 70; };
	class CUP_V_O_SLA_Carrier_Belt                                   { quality = 2; price = 70; };
	class CUP_V_O_SLA_Carrier_Belt02                                 { quality = 2; price = 70; };
	class CUP_V_O_SLA_Carrier_Belt03                                 { quality = 2; price = 70; };
	class CUP_V_O_SLA_Flak_Vest01                                    { quality = 2; price = 70; };
	class CUP_V_O_SLA_Flak_Vest02                                    { quality = 2; price = 70; };
	class CUP_V_O_SLA_Flak_Vest03                                    { quality = 2; price = 70; };
	class CUP_V_O_TK_CrewBelt                                        { quality = 2; price = 70; };
	class CUP_V_O_TK_OfficerBelt                                     { quality = 2; price = 70; };
	class CUP_V_O_TK_OfficerBelt2                                    { quality = 2; price = 70; };
	class CUP_V_O_TK_Vest_1                                          { quality = 2; price = 70; };
	class CUP_V_O_TK_Vest_2                                          { quality = 2; price = 70; };
	class CUP_V_OI_TKI_Jacket1_01                                    { quality = 2; price = 70; };
	class CUP_V_OI_TKI_Jacket1_02                                    { quality = 2; price = 70; };
	class CUP_V_OI_TKI_Jacket1_03                                    { quality = 2; price = 70; };
	class CUP_V_OI_TKI_Jacket1_04                                    { quality = 2; price = 70; };
	class CUP_V_OI_TKI_Jacket1_05                                    { quality = 2; price = 70; };
	class CUP_V_OI_TKI_Jacket1_06                                    { quality = 2; price = 70; };
	class CUP_V_OI_TKI_Jacket2_01                                    { quality = 2; price = 70; };
	class CUP_V_OI_TKI_Jacket2_02                                    { quality = 2; price = 70; };
	class CUP_V_OI_TKI_Jacket2_03                                    { quality = 2; price = 70; };
	class CUP_V_OI_TKI_Jacket2_04                                    { quality = 2; price = 70; };
	class CUP_V_OI_TKI_Jacket2_05                                    { quality = 2; price = 70; };
	class CUP_V_OI_TKI_Jacket2_06                                    { quality = 2; price = 70; };
	class CUP_V_OI_TKI_Jacket3_01                                    { quality = 2; price = 70; };
	class CUP_V_OI_TKI_Jacket3_02                                    { quality = 2; price = 70; };
	class CUP_V_OI_TKI_Jacket3_03                                    { quality = 2; price = 70; };
	class CUP_V_OI_TKI_Jacket3_04                                    { quality = 2; price = 70; };
	class CUP_V_OI_TKI_Jacket3_05                                    { quality = 2; price = 70; };
	class CUP_V_OI_TKI_Jacket3_06                                    { quality = 2; price = 70; };
	class CUP_V_OI_TKI_Jacket4_01                                    { quality = 2; price = 70; };
	class CUP_V_OI_TKI_Jacket4_02                                    { quality = 2; price = 70; };
	class CUP_V_OI_TKI_Jacket4_03                                    { quality = 2; price = 70; };
	class CUP_V_OI_TKI_Jacket4_04                                    { quality = 2; price = 70; };
	class CUP_V_OI_TKI_Jacket4_05                                    { quality = 2; price = 70; };
	class CUP_V_OI_TKI_Jacket4_06                                    { quality = 2; price = 70; };
	class CUP_V_BAF_Osprey_Mk2_DDPM_Scout							 { quality = 2; price = 80; };
	class CUP_V_BAF_Osprey_Mk2_DDPM_Soldier1					     { quality = 2; price = 80; };
	class CUP_V_BAF_Osprey_Mk2_DDPM_Soldier2					     { quality = 2; price = 80; };
	class CUP_V_BAF_Osprey_Mk2_DDPM_Grenadier					     { quality = 2; price = 80; };
	class CUP_V_BAF_Osprey_Mk2_DDPM_Sapper					         { quality = 2; price = 80; };
	class CUP_V_BAF_Osprey_Mk2_DDPM_Medic					         { quality = 2; price = 80; };
	class CUP_V_BAF_Osprey_Mk2_DDPM_Officer					         { quality = 2; price = 80; };
	class CUP_V_BAF_Osprey_Mk2_DPM_Scout							 { quality = 2; price = 80; };
	class CUP_V_BAF_Osprey_Mk2_DPM_Soldier1					         { quality = 2; price = 80; };
	class CUP_V_BAF_Osprey_Mk2_DPM_Soldier2					         { quality = 2; price = 80; };
	class CUP_V_BAF_Osprey_Mk2_DPM_Grenadier					     { quality = 2; price = 80; };
	class CUP_V_BAF_Osprey_Mk2_DPM_Sapper					         { quality = 2; price = 80; };
	class CUP_V_BAF_Osprey_Mk2_DPM_Medic					         { quality = 2; price = 80; };
	class CUP_V_BAF_Osprey_Mk2_DPM_Officer					         { quality = 2; price = 80; };
	class CUP_V_BAF_Osprey_Mk4_MTP_Grenadier				         { quality = 2; price = 80; };
	class CUP_V_BAF_Osprey_Mk4_MTP_MachineGunner				     { quality = 2; price = 80; };
	class CUP_V_BAF_Osprey_Mk4_MTP_Rifleman				             { quality = 2; price = 80; };
	class CUP_V_BAF_Osprey_Mk4_MTP_SquadLeader				         { quality = 2; price = 80; };


	///////////////////////////////////////////////////////////////////////////////
	// CUP VEHICLES 
	///////////////////////////////////////////////////////////////////////////////
	// CUP Unarmed
	///////////////////////////////////////////////////////////////////////////////
	class CUP_C_Datsun	                                { quality = 1; price = 12000; };
	class CUP_C_Datsun_4seat	                        { quality = 1; price = 12000; };
	class CUP_C_Datsun_Plain	                        { quality = 1; price = 12000; };
	class CUP_C_Datsun_Covered	                        { quality = 1; price = 12000; };
	class CUP_C_Datsun_Tubeframe	                    { quality = 1; price = 12000; };
	class CUP_O_Datsun_4seat	                        { quality = 1; price = 12000; };
	class CUP_I_Datsun_4seat                            { quality = 1; price = 12000; };
	class CUP_I_Datsun_4seat_TK                         { quality = 1; price = 12000; };
	class CUP_C_Ural_Civ_01	                            { quality = 1; price = 12500; };
	class CUP_C_Ural_Civ_02	                            { quality = 1; price = 12500; };
	class CUP_C_Ural_Civ_03	                            { quality = 1; price = 12500; };
	class CUP_C_Ural_Open_Civ_01	                    { quality = 1; price = 12500; };
	class CUP_C_Ural_Open_Civ_02	                    { quality = 1; price = 12500; };
	class CUP_C_Ural_Open_Civ_03	                    { quality = 1; price = 12500; };
	class CUP_O_Ural_TKA	                            { quality = 1; price = 12500; };
	class CUP_B_Ural_CDF	                            { quality = 1; price = 12500; };
	class CUP_O_Ural_CHDKZ	                            { quality = 1; price = 12500; };
	class CUP_O_Ural_Open_TKA	                        { quality = 1; price = 12500; };
	class CUP_B_Ural_Open_CDF	                        { quality = 1; price = 12500; };
	class CUP_O_Ural_Open_CHDKZ	                        { quality = 1; price = 12500; };
	class CUP_O_Ural_Open_SLA	                        { quality = 1; price = 12500; };
	class CUP_O_Ural_Empty_SLA	                        { quality = 1; price = 12500; };
	class CUP_B_Ural_Empty_CDF	                        { quality = 1; price = 12500; };
	class CUP_I_Ural_Empty_UN	                        { quality = 1; price = 12500; };
	class CUP_O_Ural_Empty_RU	                        { quality = 1; price = 12500; };
	class CUP_O_Ural_Empty_CHDKZ	                    { quality = 1; price = 12500; };
	class CUP_O_Ural_Empty_TKA	                        { quality = 1; price = 12500; };
	class CUP_O_Ural_Repair_TKA	                        { quality = 2; price = 13000; };
	class CUP_O_Ural_Repair_CHDKZ	                    { quality = 2; price = 13000; };
	class CUP_B_Ural_Repair_CDF	                        { quality = 2; price = 13000; };
	class CUP_B_Ural_Refuel_CDF	                        { quality = 3; price = 15500; };
	class CUP_O_Ural_Refuel_CHDKZ	                    { quality = 3; price = 15500; };
	class CUP_O_Ural_Refuel_TKA	                        { quality = 3; price = 15500; };
    class CUP_B_Ural_Reammo_CDF                         { quality = 4; price = 19500; };
    class CUP_O_Ural_Reammo_CHDKZ                       { quality = 4; price = 19500; };
    class CUP_O_Ural_Reammo_TKA                         { quality = 4; price = 19500; };
	class CUP_C_LR_Transport_CTK	                    { quality = 1; price = 22800; };
	class CUP_O_LR_Transport_TKA	                    { quality = 1; price = 22800; };
	class CUP_O_LR_Transport_TKM	                    { quality = 1; price = 22800; };
	class CUP_B_LR_Transport_CZ_W	                    { quality = 1; price = 22800; };
	class CUP_B_LR_Transport_CZ_D	                    { quality = 1; price = 22800; };
	class CUP_B_LR_Transport_GB_W	                    { quality = 1; price = 22800; };
	class CUP_B_LR_Transport_GB_D	                    { quality = 1; price = 22800; sellPrice = 10000; };
	class CUP_B_LR_Ambulance_CZ_W	                    { quality = 1; price = 22800; };
	class CUP_B_LR_Ambulance_CZ_D	                    { quality = 1; price = 22800; };
	class CUP_B_LR_Ambulance_GB_W	                    { quality = 1; price = 22800; };
	class CUP_B_LR_Ambulance_GB_D	                    { quality = 1; price = 22800; };
	class CUP_O_LR_Ambulance_TKA	                    { quality = 1; price = 22800; };
	class CUP_C_UAZ_Unarmed_TK_CIV	                    { quality = 1; price = 22500; };
	class CUP_O_UAZ_Unarmed_RU	                        { quality = 1; price = 22500; };
	class CUP_I_UAZ_Unarmed_UN	                        { quality = 1; price = 22500; };
	class CUP_O_UAZ_Unarmed_TKA	                        { quality = 1; price = 22500; };
	class CUP_O_UAZ_Unarmed_CHDKZ	                    { quality = 1; price = 22500; };
	class CUP_B_UAZ_Unarmed_ACR	                        { quality = 1; price = 22500; };
	class CUP_B_UAZ_Unarmed_CDF	                        { quality = 1; price = 22500; };
	class CUP_O_UAZ_Open_CHDKZ	                        { quality = 1; price = 22500; };
	class CUP_O_UAZ_Open_RU	                            { quality = 1; price = 22500; };
	class CUP_O_UAZ_Open_TKA	                        { quality = 1; price = 22500; };
	class CUP_I_UAZ_Open_UN	                            { quality = 1; price = 22500; };
	class CUP_B_UAZ_Open_ACR	                        { quality = 1; price = 22500; };
	class CUP_B_UAZ_Open_CDF	                        { quality = 1; price = 22500; };
	class CUP_C_UAZ_Open_TK_CIV	                        { quality = 1; price = 22500; };
	class CUP_B_HMMWV_Unarmed_USA	                    { quality = 1; price = 23000; };
	class CUP_B_HMMWV_Unarmed_USMC	                    { quality = 1; price = 23000; };
	class CUP_B_HMMWV_Ambulance_USMC	                { quality = 1; price = 23000; };
	class CUP_B_HMMWV_Ambulance_USA		                { quality = 1; price = 23000; };
	class CUP_B_HMMWV_Ambulance_ACR	                    { quality = 1; price = 23000; };
	class CUP_B_HMMWV_Transport_USA	                    { quality = 1; price = 23000; sellPrice = 10000; };
	class CUP_B_HMMWV_Terminal_USA                      { quality = 1; price = 23000; };
	class CUP_B_HMMWV_Unarmed_NATO_T                    { quality = 1; price = 23000; };
	class CUP_B_HMMWV_Ambulance_NATO_T                  { quality = 1; price = 23000; };
	class CUP_B_HMMWV_Transport_NATO_T                  { quality = 1; price = 23000; };
	class CUP_B_HMMWV_Terminal_NATO_T                   { quality = 1; price = 23000; };
	class CUP_O_V3S_Open_TKA                            { quality = 1; price = 21500; };
	class CUP_O_V3S_Covered_TKA                         { quality = 1; price = 21500; };
	class CUP_O_V3S_Refuel_TKA                          { quality = 1; price = 21500; }; 
	class CUP_O_V3S_Repair_TKA                          { quality = 1; price = 21500; }; 
	class CUP_O_V3S_Rearm_TKA                           { quality = 1; price = 21500; };
	class CUP_O_V3S_Open_TKM                            { quality = 1; price = 21500; };
	class CUP_O_V3S_Covered_TKM                         { quality = 1; price = 21500; };
	class CUP_O_V3S_Refuel_TKM                          { quality = 1; price = 21500; };
	class CUP_O_V3S_Repair_TKM                          { quality = 1; price = 21500; };
	class CUP_O_V3S_Rearm_TKM                           { quality = 1; price = 21500; };
	class CUP_C_Ikarus_TKC	                            { quality = 1; price = 11500; };
	class CUP_C_Ikarus_Chernarus	                    { quality = 1; price = 11500; };
	class CUP_B_M1151_USA	                            { quality = 1; price = 25500; }; 
	class CUP_B_M1152_USA	                            { quality = 1; price = 25500; };
	class CUP_B_M1151_WDL_USA                           { quality = 1; price = 25500; };
	class CUP_B_M1152_WDL_USA                           { quality = 1; price = 25500; };
	class CUP_B_M1151_USMC                              { quality = 1; price = 25500; };  
	class CUP_B_M1152_USMC                              { quality = 1; price = 25500; };
	class CUP_B_M1151_DSRT_USMC                         { quality = 1; price = 25500; };
	class CUP_B_M1152_DSRT_USMC                         { quality = 1; price = 25500; };
	class CUP_B_M1151_NATO_T                            { quality = 1; price = 25500; };  
	class CUP_B_M1152_NATO_T                            { quality = 1; price = 25500; };
	//class CUP_B_M1133_MEV_Desert                        { quality = 2; price = 65000; };
	class CUP_B_M1133_MEV_Desert_Slat                   { quality = 2; price = 65000; };  
	class CUP_B_M1133_MEV_Woodland                      { quality = 2; price = 65000; };  
	class CUP_B_M1133_MEV_Woodland_Slat                 { quality = 2; price = 65000; };

	///////////////////////////////////////////////////////////////////////////////
	//CUP Armed
	///////////////////////////////////////////////////////////////////////////////
	class CUP_I_FENNEK_ION                              { quality = 3; price = 80000; };
	class CUP_O_LR_MG_TKM	                            { quality = 3; price = 35000; };
	class CUP_O_LR_MG_TKA	                            { quality = 3; price = 35000; };
	class CUP_I_LR_MG_RACS	                            { quality = 3; price = 35000; }; 
	class CUP_B_LR_Special_CZ_W	                        { quality = 3; price = 58500; };
	class CUP_B_LR_MG_CZ_W	                            { quality = 3; price = 44500; };
	class CUP_O_LR_SPG9_TKA	                            { quality = 5; price = 68500; };
	class CUP_O_LR_SPG9_TKM	                            { quality = 5; price = 68500; };
	class CUP_I_Datsun_PK	                            { quality = 3; price = 20500; };
	class CUP_I_Datsun_PK_Random	                    { quality = 3; price = 20500; };
	class CUP_I_Datsun_PK_TK	                        { quality = 3; price = 20500; sellprice = 15000; };
	class CUP_I_Datsun_PK_TK_Random	                    { quality = 3; price = 20500; };
	class CUP_O_Datsun_PK	                            { quality = 3; price = 20500; };
	class CUP_O_Datsun_PK_Random	                    { quality = 3; price = 20500; };
	class CUP_O_UAZ_MG_CHDKZ	                        { quality = 3; price = 32500; };
	class CUP_O_UAZ_MG_TKA	                            { quality = 3; price = 32500; };
	class CUP_I_UAZ_MG_UN	                            { quality = 3; price = 32500; };
	class CUP_B_UAZ_MG_ACR	                            { quality = 3; price = 32500; };
	class CUP_B_UAZ_MG_CDF	                            { quality = 3; price = 32500; };
	class CUP_B_UAZ_AGS30_CDF	                        { quality = 3; price = 36500; };
	class CUP_O_UAZ_AGS30_CHDKZ	                        { quality = 3; price = 36500; };
	class CUP_O_UAZ_AGS30_TKA	                        { quality = 3; price = 36500; };
	class CUP_I_UAZ_AGS30_UN	                        { quality = 3; price = 36500; };
    class CUP_B_UAZ_AGS30_ACR	                        { quality = 3; price = 36500; };
	class CUP_B_UAZ_SPG9_CDF                            { quality = 3; price = 38500; };
	class CUP_O_UAZ_SPG9_CHDKZ                          { quality = 3; price = 38500; };
    class CUP_O_UAZ_SPG9_TKA                            { quality = 3; price = 38500; };
    class CUP_I_UAZ_SPG9_UN                             { quality = 3; price = 38500; };
    class CUP_B_UAZ_SPG9_ACR                            { quality = 3; price = 38500; };
	class CUP_B_UAZ_METIS_CDF                           { quality = 3; price = 39500; };
	class CUP_O_UAZ_METIS_CHDKZ                         { quality = 3; price = 39500; };
    class CUP_O_UAZ_METIS_TKA                           { quality = 3; price = 39500; };
    class CUP_B_UAZ_METIS_ACR                           { quality = 3; price = 39500; }; 
	class CUP_I_M113_RACS		                        { quality = 3; price = 145500; };
	class CUP_O_M113_TKA                                { quality = 3; price = 145500; };
	class CUP_I_M163_RACS                               { quality = 4; price = 185500; };
	class CUP_B_BRDM2_HQ_CDF	                        { quality = 3; price = 40000; };
	class CUP_B_BRDM2_ATGM_CDF				            { quality = 4; price = 75000; };
	class CUP_B_HMMWV_Avenger_USMC			            { quality = 4; price = 75000; sellPrice = 2000; };
	class CUP_O_BRDM2_HQ_SLA	                        { quality = 3; price = 40000; };
	class CUP_I_BRDM2_HQ_UN	            	            { quality = 3; price = 40000; };
	class CUP_I_BRDM2_HQ_NAPA	                        { quality = 3; price = 40000; };
	class CUP_I_BRDM2_HQ_TK_Gue	                        { quality = 3; price = 40000; };
	class CUP_O_BRDM2_HQ_TKA	                        { quality = 3; price = 40000; };
	class CUP_O_BRDM2_HQ_CHDKZ	                        { quality = 3; price = 40000; };
	class CUP_O_BRDM2_CHDKZ	            	            { quality = 3; price = 43000; };
	class CUP_O_BRDM2_TKA	            	            { quality = 3; price = 43000; sellPrice = 10000;};
	class CUP_I_BRDM2_NAPA	            	            { quality = 3; price = 43000; };
	class CUP_B_BRDM2_CDF					            { quality = 3; price = 43000; };
	class CUP_BAF_Jackal2_L2A1_W	                    { quality = 3; price = 60000; };
	class CUP_BAF_Jackal2_L2A1_D	                    { quality = 3; price = 60000; };
	class CUP_BAF_Jackal2_GMG_D		                    { quality = 3; price = 65000; sellPrice = 25000; };
	class CUP_BAF_Jackal2_GMG_W		                    { quality = 3; price = 65000; sellPrice = 25000; };
	class CUP_B_HMMWV_Crows_M2_USA	                    { quality = 3; price = 65000; };
	class CUP_B_HMMWV_M2_USA	                        { quality = 3; price = 66500; };
	class CUP_B_HMMWV_MK19_USA	                        { quality = 3; price = 69500; };
	class CUP_B_HMMWV_Crows_MK19_USA	                { quality = 3; price = 69500; };
	class CUP_B_HMMWV_TOW_USMC                          { quality = 4; price = 73000; };
	class CUP_B_HMMWV_TOW_USA                           { quality = 4; price = 73000; };
	class CUP_B_HMMWV_TOW_NATO_T                        { quality = 4; price = 73000; };
	class CUP_B_HMMWV_Avenger_USA                       { quality = 5; price = 80000; };
	class CUP_B_HMMWV_Avenger_NATO_T                    { quality = 5; price = 80000; };
	class CUP_B_HMMWV_M2_NATO_T                         { quality = 3; price = 66500; };
	class CUP_B_HMMWV_M2_GPK_NATO_T                     { quality = 3; price = 66500; };
	class CUP_B_HMMWV_Crows_M2_NATO_T                   { quality = 3; price = 66500; };
	class CUP_B_HMMWV_MK19_NATO_T                       { quality = 3; price = 69500; };
	class CUP_B_HMMWV_Crows_MK19_NATO_T                 { quality = 3; price = 69500; };
	class CUP_B_Dingo_Wdl                               { quality = 3; price = 67000; };
	class CUP_B_Dingo_Des                               { quality = 3; price = 67000; };  
	class CUP_B_Dingo_GL_Wdl                            { quality = 3; price = 67000; };
	class CUP_B_Dingo_GL_Des                            { quality = 3; price = 67000; };
	class CUP_B_BTR60_CDF                               { quality = 2; price = 250000; };
	class CUP_O_BTR60_TK                                { quality = 2; price = 250000; };
	class CUP_B_LAV25_HQ_USMC				            { quality = 6; price = 140000;  sellPrice = 50000; };
	class CUP_B_LAV25_USMC					            { quality = 6; price = 260000; };
	class CUP_B_LAV25_desert_USMC                       { quality = 6; price = 260000; };  
	class CUP_B_LAV25_HQ_desert_USMC                    { quality = 6; price = 140000; };
	class CUP_O_BTR90_HQ_RU					            { quality = 4; price = 200000; };
	class CUP_I_T34_NAPA					            { quality = 6; price = 400000; };
	class CUP_O_T34_TKA                                 { quality = 6; price = 400000; };
	class CUP_O_T55_TK						            { quality = 7; price = 440000; };
	class CUP_B_T72_CDF						            { quality = 8; price = 650000; sellPrice = 80000; };
	class CUP_B_T72_CZ						            { quality = 8; price = 650000; };
	class CUP_I_T72_RACS	                            { quality = 8; price = 650000; };
	class CUP_I_T72_NAPA	                            { quality = 8; price = 650000; };
	class CUP_O_T72_TKA                                 { quality = 8; price = 650000; };
	class CUP_O_T72_CHDKZ	                            { quality = 8; price = 650000; };
	class CUP_O_Ural_ZU23_RU						    { quality = 7; price = 100000; sellPrice = 40000; };
    class CUP_B_Ural_ZU23_CDF                           { quality = 7; price = 100000; }; 
    class CUP_O_Ural_ZU23_CHDKZ                         { quality = 7; price = 100000; };
	class CUP_O_Ural_ZU23_TKA                           { quality = 7; price = 100000; };
	class CUP_I_Ural_ZU23_TK_Gue                        { quality = 7; price = 100000; };
	class CUP_O_Ural_ZU23_TKM                           { quality = 7; price = 100000; };
    class CUP_O_Ural_ZU23_SLA                           { quality = 7; price = 100000; };
    class CUP_I_Ural_ZU23_NAPA                          { quality = 7; price = 100000; };
    class CUP_O_BM21_RU                                 { quality = 7; price = 1000000; }; // Премиум
    class CUP_B_BM21_CDF                                { quality = 7; price = 1000000; }; // Премиум
    class CUP_O_BM21_CHDKZ                              { quality = 7; price = 1000000; }; // Премиум
    class CUP_O_BM21_TKA                                { quality = 7; price = 1000000; }; // Премиум
    class CUP_O_BM21_SLA                                { quality = 7; price = 1000000; }; // Премиум
    class CUP_B_M1151_Deploy_USA	                    { quality = 4; price = 65000; };
	class CUP_B_M1165_GMV_WDL_USA                       { quality = 4; price = 65000; };
	class CUP_B_M1151_M2_WDL_USA                        { quality = 4; price = 65000; };
	class CUP_B_M1151_Deploy_WDL_USA                    { quality = 4; price = 65000; };
	class CUP_B_M1151_Mk19_WDL_USA                      { quality = 4; price = 65000; };
	class CUP_B_M1167_WDL_USA                           { quality = 4; price = 65000; };
	class CUP_B_M1151_M2_USMC                           { quality = 4; price = 65000; };
	class CUP_B_M1151_Deploy_USMC                       { quality = 4; price = 65000; };
	class CUP_B_M1151_Mk19_USMC                         { quality = 4; price = 65000; };
	class CUP_B_M1165_GMV_DSRT_USMC                     { quality = 4; price = 65000; sellPrice = 10000;};
	class CUP_B_M1151_M2_DSRT_USMC                      { quality = 4; price = 65000; };
	class CUP_B_M1151_Deploy_DSRT_USMC                  { quality = 4; price = 65000; };
	class CUP_B_M1151_Mk19_DSRT_USMC                    { quality = 4; price = 65000; };
	class CUP_B_M1167_DSRT_USMC                         { quality = 4; price = 65000; };
	class CUP_B_M1151_Deploy_NATO_T                     { quality = 4; price = 65000; };
	class CUP_B_M1126_ICV_M2_Desert                     { quality = 4; price = 150000; }; 
	class CUP_B_M1126_ICV_M2_Desert_Slat                { quality = 4; price = 150000; };
	class CUP_B_M1126_ICV_M2_Woodland                   { quality = 4; price = 150000; };
	class CUP_B_M1126_ICV_M2_Woodland_Slat              { quality = 4; price = 150000; };
	class CUP_B_M1129_MC_MK19_Desert                    { quality = 9; price = 800000; };  // Премиум
	class CUP_B_M1129_MC_MK19_Desert_Slat               { quality = 9; price = 800000; };  // Премиум
	class CUP_B_M1129_MC_MK19_Woodland                  { quality = 9; price = 800000; };  // Премиум
	class CUP_B_M1129_MC_MK19_Woodland_Slat             { quality = 9; price = 800000; };  // Премиум
	class CUP_B_M1135_ATGMV_Desert                      { quality = 4; price = 195000; };
	class CUP_B_M1135_ATGMV_Desert_Slat                 { quality = 4; price = 195000; };
	class CUP_B_M1135_ATGMV_Woodland                    { quality = 4; price = 195000; };
	class CUP_B_M1135_ATGMV_Woodland_Slat               { quality = 4; price = 195000; };
	class CUP_RG31_M2                                   { quality = 3; price = 130000; };
	class CUP_RG31_M2_OD	                            { quality = 3; price = 130000; };
	class CUP_RG31_M2_GC	                            { quality = 3; price = 130000; };
	class CUP_RG31E_M2                                  { quality = 3; price = 130000; };
	class CUP_B_RG31_M2_USMC                            { quality = 3; price = 130000; };
	class CUP_B_RG31_M2_OD_USMC                         { quality = 3; price = 130000; };
	class CUP_B_RG31_M2_GC_USMC                         { quality = 3; price = 130000; };
	class CUP_B_RG31_M2_OD_GC_USMC                      { quality = 3; price = 130000; };
	class CUP_B_RG31E_M2_USMC                           { quality = 3; price = 130000; };
	class CUP_RG31_Mk19	                                { quality = 3; price = 150000; };
	class CUP_RG31_Mk19_OD                              { quality = 3; price = 150000; };
	class CUP_B_RG31_Mk19_USMC                          { quality = 3; price = 150000; };
	class CUP_B_RG31_Mk19_OD_USMC                       { quality = 3; price = 150000; };
	class CUP_B_M60A3_USMC                              { quality = 5; price = 500000; }; 
	class CUP_I_M60A3_RACS                              { quality = 5; price = 500000; };
    class CUP_O_ZSU23_Afghan_CSAT                       { quality = 5; price = 575000; };
	class CUP_O_ZSU23_Afghan_SLA                        { quality = 5; price = 575000; };
	class CUP_O_ZSU23_Afghan_TK                         { quality = 5; price = 575000; };
	class CUP_O_ZSU23_Afghan_ChDKZ                      { quality = 5; price = 575000; };
	class CUP_I_ZSU23_Afghan_AAF                        { quality = 5; price = 575000; };
	class CUP_B_ZSU23_Afghan_CDF                        { quality = 5; price = 575000; };
	class CUP_O_ZSU23_TK                                { quality = 5; price = 575000; };
	class CUP_O_ZSU23_ChDKZ                             { quality = 5; price = 575000; };
	class CUP_B_ZSU23_CDF                               { quality = 5; price = 575000; };
	class CUP_O_BMP2_ZU_TKA                             { quality = 6; price = 360000; };
	class CUP_O_BMP2_TKA                                { quality = 6; price = 350000; };
	class CUP_B_BMP2_CDF                                { quality = 6; price = 350000; };
	class CUP_O_BMP2_CHDKZ                              { quality = 6; price = 350000; };
	class CUP_B_BMP2_CZ                                 { quality = 6; price = 350000; };
	class CUP_B_BMP2_CZ_Des                             { quality = 6; price = 350000; };
	class CUP_O_BMP1_TKA                                { quality = 5; price = 320000; };
	class CUP_O_BMP1P_TKA                               { quality = 5; price = 320000; };
	
	///////////////////////////////////////////////////////////////////////////////
	//CUP Helis
	///////////////////////////////////////////////////////////////////////////////
	class CUP_B_Mi35_CZ						            { quality = 6; price = 3500000; };
	class CUP_B_Mi35_CZ_Des					            { quality = 6; price = 3500000; };
	class CUP_B_Mi35_CZ_Ram					            { quality = 6; price = 3500000; };
	class CUP_B_Mi35_CZ_Tiger				            { quality = 6; price = 3500000; };
	class CUP_B_Mi35_CZ_Dark				            { quality = 6; price = 3500000; };
	class CUP_B_Mi24_D_CDF					            { quality = 7; price = 3500000; };
	class CUP_B_Mi24_D_MEV_CDF				            { quality = 7; price = 3500000; };
	class CUP_O_Mi24_D_CSAT_T				            { quality = 7; price = 3500000; };
	class CUP_O_Mi24_D_TK					            { quality = 7; price = 3500000; };
	class CUP_O_Mi24_D_SLA					            { quality = 7; price = 3500000; };
	class CUP_I_Mi24_D_UN					            { quality = 7; price = 3500000; };
	class CUP_I_Mi24_D_AAF					            { quality = 7; price = 3500000; };
	class CUP_I_Mi24_D_ION					            { quality = 7; price = 3500000; };
	class CUP_O_Mi24_P_RU					            { quality = 7; price = 3500000; };
	class CUP_O_Mi24_P_CSAT_T				            { quality = 7; price = 3500000; };
	class CUP_O_Mi24_V_RU					            { quality = 7; price = 3500000; };
	class CUP_O_Mi24_V_CSAT_T				            { quality = 7; price = 3500000; };
	class CUP_B_UH1Y_GUNSHIP_USMC			            { quality = 2; price = 600000; };
	class CUP_B_CH53E_USMC	                            { quality = 1; price = 575000; };
	class CUP_B_CH53E_GER					            { quality = 1; price = 575000; };
	class CUP_B_UH1Y_UNA_F	                            { quality = 1; price = 300000; };
	class CUP_B_UH1Y_MEV_F	                            { quality = 1; price = 300000; };
	class CUP_C_Mi17_Civilian_RU	                    { quality = 1; price = 300000; };
	class CUP_B_Mi17_CDF	                            { quality = 3; price = 400000; };
	class CUP_O_Mi17_TK	                                { quality = 3; price = 400000; };
	class CUP_B_Mi17_medevac_CDF	                    { quality = 1; price = 300000; };
	class CUP_B_Mi171Sh_Unarmed_ACR	                    { quality = 1; price = 2000000; };
	class CUP_O_Mi8_medevac_CHDKZ	                    { quality = 1; price = 300000; };
	class CUP_O_Mi8_medevac_RU	                        { quality = 1; price = 300000; };
	class CUP_B_Mi171Sh_ACR                             { quality = 4; price = 3000000; }; 
	class CUP_Merlin_HC3_FFV	                        { quality = 3; price = 300000; };
	class CUP_Merlin_HC3	                            { quality = 3; price = 300000; };
	class CUP_Merlin_HC3_MED	                        { quality = 3; price = 300000; };
	class CUP_B_MH60S_USMC	                            { quality = 3; price = 500000; };
	class CUP_B_MH60S_FFV_USMC	                        { quality = 3; price = 500000; };
	class CUP_B_AW159_Unarmed_BAF	                    { quality = 3; price = 300000; };
	class CUP_B_CH47F_USA	                            { quality = 1; price = 400000; };
	class CUP_B_CH47F_GB	                            { quality = 1; price = 400000; };
	class CUP_B_UH60L_US	                            { quality = 3; price = 600000; };
	class CUP_B_UH60M_FFV_US	                        { quality = 3; price = 600000; };
	class CUP_B_UH60L_FFV_US	                        { quality = 3; price = 1400000; };
	class CUP_B_UH60M_Unarmed_US	                    { quality = 1; price = 300000; };
	class CUP_B_UH60L_Unarmed_US	                    { quality = 1; price = 300000; };
	class CUP_B_UH60M_Unarmed_FFV_US	                { quality = 1; price = 300000; };
	class CUP_B_UH60L_Unarmed_FFV_US	                { quality = 1; price = 300000; };
	class CUP_B_UH60M_Unarmed_FFV_MEV_US	            { quality = 1; price = 300000; };
	class CUP_B_UH60L_Unarmed_FFV_MEV_US	            { quality = 1; price = 300000; };
	class CUP_I_UH60L_RACS	                            { quality = 4; price = 1400000; };
	class CUP_I_UH60L_FFV_RACS	                        { quality = 4; price = 1400000; };
	class CUP_I_UH60L_Unarmed_RACS	                    { quality = 1; price = 300000; };
	class CUP_I_UH60L_Unarmed_FFV_Racs	                { quality = 1; price = 300000; };
	class CUP_I_UH60L_Unarmed_FFV_MEV_Racs	            { quality = 1; price = 300000; };
	class CUP_B_AH1Z_NoWeapons				            { quality = 3; price = 1000000; };
    class CUP_I_BTR40_TKG					            { quality = 3; price = 28500; sellPrice = 11500; };
	class CUP_B_MI6A_CDF                                { quality = 5; price = 2000000; };
	class CUP_B_AH6J_ESCORT_USA                         { quality = 5; price = 1600000; };
	
	///////////////////////////////////////////////////////////////////////////////
	//CUP Planes
	///////////////////////////////////////////////////////////////////////////////
	class CUP_C_AN2_AEROSCHROT_TK_CIV                   { quality = 2; price = 100000; };
	class CUP_C_AN2_CIV                                 { quality = 2; price = 100000; };
	class CUP_C_AN2_AIRTAK_TK_CIV                       { quality = 2; price = 100000; };
	class CUP_O_AN2_TK                                  { quality = 2; price = 100000; };
	class CUP_B_C130J_GB                                { quality = 3; price = 600000; };
	class CUP_I_C130J_AAF                               { quality = 3; price = 600000; };
	class CUP_I_C130J_RACS                              { quality = 3; price = 600000; };
	class CUP_O_C130J_TKA                               { quality = 3; price = 600000; };
	class CUP_B_C130J_Cargo_GB                          { quality = 3; price = 600000; };
	class CUP_I_C130J_Cargo_AAF                         { quality = 3; price = 600000; };
	class CUP_I_C130J_Cargo_RACS                        { quality = 3; price = 600000; };
	class CUP_O_C130J_Cargo_TKA                         { quality = 3; price = 600000; };
	class CUP_C_C47_CIV                                 { quality = 2; price = 150000; };
	class CUP_C_DC3_CIV                                 { quality = 2; price = 150000; };
	class CUP_B_MV22_USMC                               { quality = 3; price = 1500000; };
	class CUP_B_MV22_USMC_RAMPGUN                       { quality = 3; price = 1600000; };

    //////////////////////////////////////////////////////////////////////////////////////////
    /////////////Boats////
	//////////////////////////////////////////////////////////////////////////////////////////
	class CUP_B_RHIB_USMC                               { quality = 1; price = 20000; sellPrice = 1; };
	class CUP_I_RHIB_RACS                               { quality = 1; price = 20000; };
	class CUP_B_Seafox_USMC                             { quality = 1; price = 10000; };
	class CUP_C_Zodiac_CIV                              { quality = 1; price = 10000; };
	//class CUP_B_Frigate_ANZAC                           { quality = 10; price = 500000; };   // фригат
	class CUP_O_PBX_RU	                                { quality = 1; price = 5000; sellPrice = 1500; };
	
    /////////////////////////////////////////////////////////////////////////////////////////
    //////////Bikes
    /////////////////////////////////////////////////////////////////////////////////////////
    class CUP_B_M1030								    { quality = 1; price = 2000; sellPrice = 100; };

	///////////////////////////////////////////////////////////////////////////////
	//  Launchers
	///////////////////////////////////////////////////////////////////////////////
	class CUP_launch_Igla									{ quality = 4; price = 6000; };
	class CUP_launch_Javelin								{ quality = 4; price = 6000; };
	class CUP_launch_M47									{ quality = 4; price = 6000; };
	class CUP_launch_M136									{ quality = 4; price = 6000; };
	//class CUP_launch_MAAWS_Scope							{ quality = 4; price = 6000; }; // дюп
	class CUP_launch_Metis									{ quality = 4; price = 6000; };
	class CUP_launch_NLAW									{ quality = 4; price = 6000; };
	class CUP_launch_RPG7V									{ quality = 4; price = 6000; };
	class CUP_launch_RPG18									{ quality = 4; price = 6000; };
	//class CUP_launch_Mk153Mod0_SMAWOptics					{ quality = 4; price = 6000; }; // дюп
	class CUP_launch_FIM92Stinger							{ quality = 4; price = 6000; };
	class CUP_launch_MAAWS									{ quality = 4; price = 6000; };
	class CUP_launch_Mk153Mod0								{ quality = 4; price = 6000; };
	class CUP_launch_9K32Strela								{ quality = 4; price = 6000; }; 

    //// Launcher
	class CUP_Igla_M										{ quality = 4; price = 1000; };
	class CUP_M136_M										{ quality = 4; price = 1000; };
	class CUP_MAAWS_HEAT_M									{ quality = 4; price = 1000; };
	class CUP_MAAWS_HEDP_M									{ quality = 4; price = 1000; };
	class CUP_AT13_M										{ quality = 4; price = 1000; };
	class CUP_NLAW_M										{ quality = 4; price = 1000; };
	class CUP_PG7V_M										{ quality = 4; price = 1000; };
	class CUP_PG7VL_M										{ quality = 4; price = 1000; };
	class CUP_PG7VR_M										{ quality = 4; price = 1000; };
	class CUP_OG7_M											{ quality = 4; price = 1000; };
	class CUP_RPG18_M										{ quality = 4; price = 1000; };
	class CUP_SMAW_HEAA_M									{ quality = 4; price = 1000; };
	class CUP_SMAW_HEDP_M									{ quality = 4; price = 1000; };
	class CUP_Stinger_M										{ quality = 4; price = 1000; };
	class CUP_Strela_2_M									{ quality = 4; price = 1000; };
	class CUP_Dragon_EP1_M									{ quality = 4; price = 1000; };
	class CUP_Javelin_M										{ quality = 4; price = 1000; };
	class CUP_6Rnd_HE_M203									{ quality = 4; price = 50; };
	class CUP_6Rnd_FlareWhite_M203							{ quality = 4; price = 50; };
	class CUP_6Rnd_FlareGreen_M203							{ quality = 4; price = 50; };
	class CUP_6Rnd_FlareRed_M203							{ quality = 4; price = 50; };
	class CUP_6Rnd_FlareYellow_M203							{ quality = 4; price = 50; };
	class CUP_6Rnd_Smoke_M203								{ quality = 4; price = 50; };
	class CUP_6Rnd_SmokeRed_M203							{ quality = 4; price = 50; };
	class CUP_6Rnd_SmokeGreen_M203							{ quality = 4; price = 50; };
	class CUP_6Rnd_SmokeYellow_M203							{ quality = 4; price = 50; };
	class CUP_1Rnd_HE_M203									{ quality = 4; price = 50; };
	class CUP_1Rnd_HEDP_M203								{ quality = 4; price = 50; };
	class CUP_FlareWhite_M203								{ quality = 4; price = 50; };
	class CUP_FlareGreen_M203								{ quality = 4; price = 50; };
	class CUP_FlareRed_M203									{ quality = 4; price = 50; };
	class CUP_FlareYellow_M203								{ quality = 4; price = 50; };
	class CUP_1Rnd_Smoke_M203								{ quality = 4; price = 50; };
	class CUP_1Rnd_SmokeRed_M203							{ quality = 4; price = 50; };
	class CUP_1Rnd_SmokeGreen_M203							{ quality = 4; price = 50; };
	class CUP_1Rnd_SmokeYellow_M203							{ quality = 4; price = 50; }; 

	///////////////////////////////////////////////////////////////////////////////
	// Uniforms
	///////////////////////////////////////////////////////////////////////////////
	class rhs_uniform_cu_ocp						        { quality = 2; price = 50; };
	class rhs_uniform_cu_ucp						        { quality = 2; price = 50; };
	class rhs_uniform_cu_ocp_101st                          { quality = 2; price = 50; };
	class rhs_uniform_df15                                  { quality = 2; price = 50; };
	class rhs_uniform_emr_patchless					        { quality = 2; price = 50; };
	class rhs_uniform_flora_patchless				        { quality = 2; price = 50; };
	class rhs_uniform_flora_patchless_alt			        { quality = 2; price = 50; };
	class rhs_uniform_m88_patchless					        { quality = 2; price = 50; };
	class rhs_uniform_mflora_patchless				        { quality = 2; price = 50; };
	class rhs_uniform_vdv_mflora                            { quality = 2; price = 55; };
	class rhs_uniform_FROG01_m81					        { quality = 2; price = 65; };
	class rhs_uniform_FROG01_d						        { quality = 2; price = 65; };
	class rhs_uniform_FROG01_wd						        { quality = 2; price = 65; };
	class rhs_uniform_vdv_emr_des					        { quality = 2; price = 65; };
	class rhs_uniform_msv_emr						        { quality = 2; price = 65; };
	class rhs_uniform_flora							        { quality = 2; price = 65; };
	class rhs_uniform_vdv_flora						        { quality = 2; price = 65; };
	class rhs_uniform_gorka_r_g						        { quality = 2; price = 100; };
	class rhs_uniform_gorka_r_y						        { quality = 2; price = 100; };
	class rhs_chdkz_uniform_5						        { quality = 2; price = 65; };
	class rhs_chdkz_uniform_4						        { quality = 2; price = 65; };
	class rhs_chdkz_uniform_3						        { quality = 2; price = 65; };
	class rhs_chdkz_uniform_2						        { quality = 2; price = 65; };
	class rhs_chdkz_uniform_1						        { quality = 2; price = 65; };
	class rhs_uniform_mvd_izlom						        { quality = 2; price = 65; };
	class rhs_uniform_cu_ocp_10th					        { quality = 2; price = 65; };
	class rhs_uniform_cu_ocp_1stcav					        { quality = 2; price = 65; };
	class rhs_uniform_cu_ocp_82nd					        { quality = 2; price = 65; };
	class rhs_uniform_cu_ucp_101st					        { quality = 2; price = 65; };
	class rhs_uniform_cu_ucp_10th					        { quality = 2; price = 65; };
	class rhs_uniform_cu_ucp_1stcav					        { quality = 2; price = 65; };
	class rhs_uniform_cu_ucp_82nd					        { quality = 2; price = 65; };
	// Added by ElShotte                                    
	class rhs_uniform_g3_m81						        { quality = 2; price = 65; };
	class rhs_uniform_g3_blk						        { quality = 2; price = 65; };
	class rhs_uniform_g3_mc							        { quality = 2; price = 65; };
	class rhs_uniform_g3_rgr						        { quality = 2; price = 65; };
	class rhs_uniform_g3_tan						        { quality = 2; price = 65; };

	///////////////////////////////////////////////////////////////////////////////
	// Vests
	///////////////////////////////////////////////////////////////////////////////
	class rhs_6sh92								    		{ quality = 2; price = 50; };
	class rhs_6sh92_radio									{ quality = 2; price = 50; };
	class rhs_6sh92_vog										{ quality = 2; price = 50; };
	class rhs_6sh92_vog_headset								{ quality = 2; price = 50; };
	class rhs_6sh92_headset									{ quality = 2; price = 50; };
	class rhs_6sh92_digi									{ quality = 2; price = 50; };
	class rhs_6sh92_digi_radio					    		{ quality = 2; price = 50; };
	class rhs_6sh92_digi_vog								{ quality = 2; price = 50; };
	class rhs_6sh92_digi_vog_headset						{ quality = 2; price = 50; };
	class rhs_6sh92_digi_headset							{ quality = 2; price = 50; };
	class rhs_6b23								    		{ quality = 2; price = 50; };
	class rhs_6b23_crew							    		{ quality = 2; price = 50; };
	class rhs_6b23_crewofficer								{ quality = 2; price = 50; };
	class rhs_6b23_engineer					        		{ quality = 2; price = 50; };
	class rhs_6b23_medic									{ quality = 2; price = 50; };
	class rhs_6b23_rifleman									{ quality = 2; price = 50; };
	class rhs_6b23_sniper									{ quality = 2; price = 50; };
	class rhs_6b23_6sh92									{ quality = 2; price = 50; };
	class rhs_6b23_6sh92_radio								{ quality = 2; price = 50; };
	class rhs_6b23_6sh92_vog								{ quality = 2; price = 50; };
	class rhs_6b23_6sh92_vog_headset						{ quality = 2; price = 50; };
	class rhs_6b23_6sh92_headset							{ quality = 2; price = 50; };
	class rhs_6b23_6sh92_headset_mapcase					{ quality = 2; price = 50; };
	class rhs_6b23_digi										{ quality = 2; price = 50; };
	class rhs_6b23_digi_crew								{ quality = 2; price = 50; };
	class rhs_6b23_digi_crewofficer							{ quality = 2; price = 50; };
	class rhs_6b23_digi_engineer							{ quality = 2; price = 50; };
	class rhs_6b23_digi_medic					    		{ quality = 2; price = 50; };
	class rhs_6b23_digi_rifleman							{ quality = 2; price = 50; };
	class rhs_6b23_digi_sniper								{ quality = 2; price = 50; };
	class rhs_6b23_digi_6sh92								{ quality = 2; price = 50; };
	class rhs_6b23_digi_6sh92_radio							{ quality = 2; price = 50; };
	class rhs_6b23_digi_6sh92_vog				    		{ quality = 2; price = 50; };
	class rhs_6b23_digi_6sh92_vog_headset					{ quality = 2; price = 50; };
	class rhs_6b23_digi_6sh92_headset						{ quality = 2; price = 50; };
	class rhs_6b23_digi_6sh92_headset_mapcase				{ quality = 2; price = 50; };
	class rhs_6b23_ML							    		{ quality = 2; price = 50; };
	class rhs_6b23_ML_crew									{ quality = 2; price = 50; };
	class rhs_6b23_ML_crewofficer							{ quality = 2; price = 50; };
	class rhs_6b23_ML_engineer								{ quality = 2; price = 50; };
	class rhs_6b23_ML_medic									{ quality = 2; price = 50; };
	class rhs_6b23_ML_rifleman					    		{ quality = 2; price = 50; };
	class rhs_6b23_ML_sniper								{ quality = 2; price = 50; };
	class rhs_6b23_ML_6sh92									{ quality = 2; price = 50; };
	class rhs_6b23_ML_6sh92_radio							{ quality = 2; price = 50; };
	class rhs_6b23_ML_6sh92_vog								{ quality = 2; price = 50; };
	class rhs_6b23_ML_6sh92_vog_headset						{ quality = 2; price = 50; };
	class rhs_6b23_ML_6sh92_headset							{ quality = 2; price = 50; };
	class rhs_6b23_ML_6sh92_headset_mapcase					{ quality = 2; price = 50; };
	class rhs_6sh46								    		{ quality = 2; price = 50; };
	class rhs_vest_commander								{ quality = 2; price = 50; };
	class rhs_vydra_3m										{ quality = 2; price = 50; };
	class rhsusf_iotv_ucp									{ quality = 2; price = 450; };
	class rhsusf_iotv_ucp_grenadier							{ quality = 2; price = 450; };
	class rhsusf_iotv_ucp_medic								{ quality = 2; price = 450; };
	class rhsusf_iotv_ucp_repair							{ quality = 2; price = 450; };
	class rhsusf_iotv_ucp_rifleman							{ quality = 2; price = 450; };
	class rhsusf_iotv_ucp_SAW								{ quality = 2; price = 450; };
	class rhsusf_iotv_ucp_squadleader						{ quality = 2; price = 450; };
	class rhsusf_iotv_ucp_teamleader						{ quality = 2; price = 450; };
	class rhsusf_iotv_ocp									{ quality = 2; price = 450; };
	class rhsusf_iotv_ocp_grenadier							{ quality = 2; price = 450; };
	class rhsusf_iotv_ocp_medic					    		{ quality = 2; price = 450; };
	class rhsusf_iotv_ocp_repair							{ quality = 2; price = 450; };
	class rhsusf_iotv_ocp_rifleman							{ quality = 2; price = 450; };
	class rhsusf_iotv_ocp_SAW								{ quality = 2; price = 450; };
	class rhsusf_iotv_ocp_squadleader						{ quality = 2; price = 450; };
	class rhsusf_iotv_ocp_teamleader						{ quality = 2; price = 450; };
	class rhsusf_spc					            		{ quality = 2; price = 450; };

	// Added by ElShotte
	class rhsusf_spc_corpsman								{ quality = 2; price = 450; };
	class rhsusf_spc_patchless								{ quality = 2; price = 450; };
	class rhsusf_spc_squadleader							{ quality = 2; price = 450; };
	class rhsusf_spc_teamleader								{ quality = 2; price = 450; };
	class rhsusf_spc_light									{ quality = 2; price = 450; };
	class rhsusf_spc_rifleman								{ quality = 2; price = 450; };
	class rhsusf_spc_iar									{ quality = 2; price = 450; };
	class rhsusf_spcs_ocp_rifleman							{ quality = 2; price = 450; };
	class rhsusf_spcs_ocp									{ quality = 2; price = 450; };
	class rhsusf_spcs_ucp_rifleman							{ quality = 2; price = 450; };
	class rhsusf_spcs_ucp									{ quality = 2; price = 450; };
	class rhs_6b43											{ quality = 2; price = 450; };

	///////////////////////////////////////////////////////////////////////////////
	// Backpacks
	///////////////////////////////////////////////////////////////////////////////
	// Modified by ElShotte
	class rhsusf_assault_eagleaiii_coy						{ quality = 2; price = 150; };
	class rhsusf_assault_eagleaiii_ocp						{ quality = 2; price = 150; };
	class rhsusf_assault_eagleaiii_ucp						{ quality = 2; price = 150; };
	class rhsusf_falconii_coy								{ quality = 2; price = 150; };
	class rhsusf_falconii_mc								{ quality = 2; price = 150; };
	class rhsusf_falconii									{ quality = 2; price = 150; };
	class rhs_assault_umbts									{ quality = 2; price = 150; };
	class rhs_assault_umbts_engineer_empty					{ quality = 2; price = 150; };
	class rhs_medic_bag 									{ quality = 2; price = 150; };
	class rhs_sidor 										{ quality = 2; price = 150; };
	class rhs_rpg_empty 									{ quality = 2; price = 150; };

	///////////////////////////////////////////////////////////////////////////////
	// Accessories
	///////////////////////////////////////////////////////////////////////////////
	// Added by ElShotte
	class rhs_ess_black										{ quality = 3; price = 50; };
	class rhs_googles_black									{ quality = 3; price = 50; };
	class rhs_googles_clear									{ quality = 3; price = 50; };
	class rhs_googles_yellow								{ quality = 3; price = 50; };
	class rhs_googles_orange								{ quality = 3; price = 50; };
	class rhs_scarf											{ quality = 3; price = 50; };
	class rhs_balaclava										{ quality = 3; price = 50; };
	class rhs_balaclava1_olive								{ quality = 3; price = 50; };
	class rhsusf_ANPVS_15									{ quality = 4; price = 650; };
	class rhsusf_ANPVS_14									{ quality = 3; price = 550; };
	class rhs_1PN138										{ quality = 3; price = 550; };

	///////////////////////////////////////////////////////////////////////////////
	// Helmets
	///////////////////////////////////////////////////////////////////////////////
	class rhs_6b27m_digi									{ quality = 2; price = 40; };
	class rhs_6b27m_digi_ess								{ quality = 2; price = 40; };
	class rhs_6b27m_digi_bala								{ quality = 2; price = 60; };
	class rhs_6b27m_digi_ess_bala							{ quality = 2; price = 60; };
	class rhs_6b27m											{ quality = 2; price = 40; };
	class rhs_6b27m_bala									{ quality = 2; price = 60; };
	class rhs_6b27m_ess										{ quality = 2; price = 40; };
	class rhs_6b27m_ess_bala								{ quality = 2; price = 60; };
	class rhs_6b27m_ml										{ quality = 2; price = 40; };
	class rhs_6b27m_ml_ess									{ quality = 2; price = 40; };
	class rhs_6b27m_ml_bala									{ quality = 2; price = 60; };
	class rhs_6b27m_ML_ess_bala								{ quality = 2; price = 60; };
	class rhs_6b27m_green									{ quality = 2; price = 90; };
	class rhs_6b27m_green_ess								{ quality = 2; price = 90; };
	class rhs_6b27m_green_ess_bala							{ quality = 2; price = 90; };
	class rhs_6b26_green									{ quality = 2; price = 90; };
	class rhs_6b26_bala_green								{ quality = 2; price = 90; };
	class rhs_6b26_ess_green								{ quality = 2; price = 90; };
	class rhs_6b26_ess_bala_green							{ quality = 2; price = 90; };
	class rhs_6b26											{ quality = 2; price = 90; };
	class rhs_6b26_bala										{ quality = 2; price = 90; };
	class rhs_6b26_ess										{ quality = 2; price = 90; };
	class rhs_6b26_ess_bala									{ quality = 2; price = 90; };
	class rhs_6b28_green									{ quality = 2; price = 90; };
	class rhs_6b28_green_bala								{ quality = 2; price = 90; };
	class rhs_6b28_green_ess								{ quality = 2; price = 90; };
	class rhs_6b28_green_ess_bala							{ quality = 2; price = 90; };
	class rhs_6b28											{ quality = 2; price = 90; };
	class rhs_6b28_bala										{ quality = 2; price = 90; };
	class rhs_6b28_ess										{ quality = 2; price = 90; };
	class rhs_6b28_ess_bala									{ quality = 2; price = 90; };
	class rhs_6b28_flora									{ quality = 2; price = 90; };
	class rhs_6b28_flora_bala								{ quality = 2; price = 90; };
	class rhs_6b28_flora_ess								{ quality = 2; price = 90; };
	class rhs_6b28_flora_ess_bala							{ quality = 2; price = 90; };
	class rhs_Booniehat_digi								{ quality = 2; price = 90; };
	class rhs_Booniehat_flora								{ quality = 2; price = 90; };
	class rhs_ssh68											{ quality = 2; price = 90; };
	class rhs_Booniehat_m81									{ quality = 2; price = 90; };
	class rhs_Booniehat_marpatd								{ quality = 2; price = 110; };
	class rhs_Booniehat_marpatwd							{ quality = 2; price = 120; };
	class rhs_Booniehat_ocp									{ quality = 2; price = 90; };
	class rhs_Booniehat_ucp									{ quality = 2; price = 90; };
	class rhsusf_Bowman										{ quality = 2; price = 90; };
	class rhsusf_ach_bare									{ quality = 2; price = 90; };
	class rhsusf_ach_bare_des								{ quality = 2; price = 90; };
	class rhsusf_ach_bare_des_ess							{ quality = 2; price = 90; };
	class rhsusf_ach_bare_des_headset						{ quality = 2; price = 120; };
	class rhsusf_ach_bare_des_headset_ess					{ quality = 2; price = 120; };
	class rhsusf_ach_bare_ess								{ quality = 2; price = 90; };
	class rhsusf_ach_bare_headset							{ quality = 2; price = 120; };
	class rhsusf_ach_bare_headset_ess						{ quality = 2; price = 120; };
	class rhsusf_ach_bare_semi								{ quality = 2; price = 90; };
	class rhsusf_ach_bare_semi_ess							{ quality = 2; price = 90; };
	class rhsusf_ach_bare_semi_headset						{ quality = 2; price = 120; };
	class rhsusf_ach_bare_semi_headset_ess					{ quality = 2; price = 120; };
	class rhsusf_ach_bare_tan								{ quality = 2; price = 90; };
	class rhsusf_ach_bare_tan_ess							{ quality = 2; price = 90; };
	class rhsusf_ach_bare_tan_headset						{ quality = 2; price = 120; };
	class rhsusf_ach_bare_tan_headset_ess					{ quality = 2; price = 120; };
	class rhsusf_ach_bare_wood								{ quality = 2; price = 90; };
	class rhsusf_ach_bare_wood_ess							{ quality = 2; price = 90; };
	class rhsusf_ach_bare_wood_headset						{ quality = 2; price = 120; };
	class rhsusf_ach_bare_wood_headset_ess					{ quality = 2; price = 120; };
	class rhsusf_ach_helmet_ESS_ocp							{ quality = 2; price = 90; };
	class rhsusf_ach_helmet_ESS_ucp							{ quality = 2; price = 90; };
	class rhsusf_ach_helmet_M81								{ quality = 2; price = 110; };
	class rhsusf_ach_helmet_camo_ocp						{ quality = 2; price = 120; };
	class rhsusf_ach_helmet_headset_ess_ocp					{ quality = 2; price = 120; };
	class rhsusf_ach_helmet_headset_ess_ucp					{ quality = 2; price = 120; };
	class rhsusf_ach_helmet_headset_ocp						{ quality = 2; price = 120; };
	class rhsusf_ach_helmet_headset_ucp						{ quality = 2; price = 120; };
	class rhsusf_ach_helmet_ocp								{ quality = 2; price = 90; };
	class rhsusf_ach_helmet_ocp_norotos						{ quality = 2; price = 90; };
	class rhsusf_ach_helmet_ucp								{ quality = 2; price = 90; };
	class rhsusf_ach_helmet_ucp_norotos						{ quality = 2; price = 90; };
	class rhsusf_bowman_cap									{ quality = 2; price = 90; };
	class rhsusf_lwh_helmet_M1942							{ quality = 2; price = 90; };
	class rhsusf_lwh_helmet_marpatd							{ quality = 2; price = 90; };
	class rhsusf_lwh_helmet_marpatd_ess						{ quality = 2; price = 90; };
	class rhsusf_lwh_helmet_marpatd_headset					{ quality = 2; price = 120; };
	class rhsusf_lwh_helmet_marpatwd						{ quality = 2; price = 90; };
	class rhsusf_lwh_helmet_marpatwd_ess					{ quality = 2; price = 90; };
	class rhsusf_lwh_helmet_marpatwd_headset				{ quality = 2; price = 120; };
	class rhsusf_mich_bare									{ quality = 2; price = 90; };
	class rhsusf_mich_bare_alt								{ quality = 2; price = 90; };
	class rhsusf_mich_bare_alt_semi							{ quality = 2; price = 90; };
	class rhsusf_mich_bare_alt_tan							{ quality = 2; price = 90; };
	class rhsusf_mich_bare_headset							{ quality = 2; price = 120; };
	class rhsusf_mich_bare_norotos							{ quality = 2; price = 90; };
	class rhsusf_mich_bare_norotos_alt						{ quality = 2; price = 90; };
	class rhsusf_mich_bare_norotos_alt_headset				{ quality = 2; price = 120; };
	class rhsusf_mich_bare_norotos_alt_semi					{ quality = 2; price = 90; };
	class rhsusf_mich_bare_norotos_alt_semi_headset			{ quality = 2; price = 120; };
	class rhsusf_mich_bare_norotos_alt_tan					{ quality = 2; price = 90; };
	class rhsusf_mich_bare_norotos_alt_tan_headset			{ quality = 2; price = 120; };
	class rhsusf_mich_bare_norotos_arc						{ quality = 2; price = 90; };
	class rhsusf_mich_bare_norotos_arc_alt					{ quality = 2; price = 90; };
	class rhsusf_mich_bare_norotos_arc_alt_headset			{ quality = 2; price = 120; };
	class rhsusf_mich_bare_norotos_arc_alt_semi				{ quality = 2; price = 90; };
	class rhsusf_mich_bare_norotos_arc_alt_semi_headset		{ quality = 2; price = 120; };
	class rhsusf_mich_bare_norotos_arc_alt_tan				{ quality = 2; price = 90; };
	class rhsusf_mich_bare_norotos_arc_alt_tan_headset		{ quality = 2; price = 120; };
	class rhsusf_mich_bare_norotos_arc_headset				{ quality = 2; price = 120; };
	class rhsusf_mich_bare_norotos_arc_semi					{ quality = 2; price = 90; };
	class rhsusf_mich_bare_norotos_arc_semi_headset			{ quality = 2; price = 120; };
	class rhsusf_mich_bare_norotos_arc_tan					{ quality = 2; price = 90; };
	class rhsusf_mich_bare_norotos_headset					{ quality = 2; price = 120; };
	class rhsusf_mich_bare_norotos_semi						{ quality = 2; price = 90; };
	class rhsusf_mich_bare_norotos_semi_headset				{ quality = 2; price = 120; };
	class rhsusf_mich_bare_norotos_tan						{ quality = 2; price = 90; };
	class rhsusf_mich_bare_norotos_tan_headset				{ quality = 2; price = 120; };
	class rhsusf_mich_bare_semi								{ quality = 2; price = 90; };
	class rhsusf_mich_bare_semi_headset						{ quality = 2; price = 120; };
	class rhsusf_mich_bare_tan								{ quality = 2; price = 90; };
	class rhsusf_mich_bare_tan_headset						{ quality = 2; price = 120; };
	class rhsusf_mich_helmet_marpatd_alt_headset			{ quality = 2; price = 120; };
	class rhsusf_mich_helmet_marpatd_headset				{ quality = 2; price = 120; };
	class rhsusf_mich_helmet_marpatd_norotos				{ quality = 2; price = 120; };
	class rhsusf_mich_helmet_marpatd_norotos_arc			{ quality = 2; price = 120; };
	class rhsusf_mich_helmet_marpatd_norotos_arc_headset	{ quality = 2; price = 120; };
	class rhsusf_mich_helmet_marpatd_norotos_headset		{ quality = 2; price = 120; };
	class rhsusf_mich_helmet_marpatwd						{ quality = 2; price = 90; };
	class rhsusf_mich_helmet_marpatwd_alt					{ quality = 2; price = 120; };
	class rhsusf_mich_helmet_marpatwd_alt_headset			{ quality = 2; price = 120; };
	class rhsusf_mich_helmet_marpatwd_headset				{ quality = 2; price = 120; };
	class rhsusf_mich_helmet_marpatwd_norotos				{ quality = 2; price = 90; };
	class rhsusf_mich_helmet_marpatwd_norotos_arc			{ quality = 2; price = 90; };
	class rhsusf_mich_helmet_marpatwd_norotos_arc_headset	{ quality = 2; price = 120; };
	class rhsusf_mich_helmet_marpatwd_norotos_headset		{ quality = 2; price = 120; };

	// Added by ElShotte
	class rhs_altyn_novisor 								{ quality = 2; price = 150; };
	class rhs_altyn_novisor_bala							{ quality = 2; price = 150; };
	class rhs_altyn_novisor_ess								{ quality = 2; price = 150; };
	class rhs_altyn_novisor_ess_bala						{ quality = 2; price = 150; };
	class rhs_altyn_visordown								{ quality = 2; price = 200; };
	class rhs_altyn											{ quality = 2; price = 200; };
	class rhs_altyn_bala									{ quality = 2; price = 200; };
	class rhsusf_opscore_bk_pelt							{ quality = 2; price = 200; };
	class rhsusf_opscore_bk									{ quality = 2; price = 200; };
	class rhsusf_opscore_coy_cover							{ quality = 2; price = 200; };
	class rhsusf_opscore_coy_cover_pelt						{ quality = 2; price = 200; };
	class rhsusf_opscore_fg									{ quality = 2; price = 200; };
	class rhsusf_opscore_fg_pelt							{ quality = 2; price = 200; };
	class rhsusf_opscore_fg_pelt_cam						{ quality = 2; price = 200; };
	class rhsusf_opscore_fg_pelt_nsw						{ quality = 2; price = 200; };
	class rhsusf_opscore_mc									{ quality = 2; price = 200; };
	class rhsusf_opscore_mc_pelt							{ quality = 2; price = 200; };
	class rhsusf_opscore_mc_pelt_nsw						{ quality = 2; price = 200; };
	class rhsusf_opscore_mc_cover							{ quality = 2; price = 200; };
	class rhsusf_opscore_mc_cover_pelt						{ quality = 2; price = 200; };
	class rhsusf_opscore_mc_cover_pelt_nsw					{ quality = 2; price = 200; };
	class rhsusf_opscore_mc_cover_pelt_cam					{ quality = 2; price = 200; };
	class rhsusf_opscore_paint								{ quality = 2; price = 200; };
	class rhsusf_opscore_paint_pelt							{ quality = 2; price = 200; };
	class rhsusf_opscore_paint_pelt_nsw						{ quality = 2; price = 200; };
	class rhsusf_opscore_paint_pelt_nsw_cam					{ quality = 2; price = 200; };
	class rhsusf_opscore_rg_cover							{ quality = 2; price = 200; };
	class rhsusf_opscore_rg_cover_pelt						{ quality = 2; price = 200; };
	class rhsusf_opscore_ut									{ quality = 2; price = 200; };
	class rhsusf_opscore_ut_pelt							{ quality = 2; price = 200; };
	class rhsusf_opscore_ut_pelt_cam						{ quality = 2; price = 200; };
	class rhsusf_opscore_ut_pelt_nsw						{ quality = 2; price = 200; };
	class rhsusf_opscore_ut_pelt_nsw_cam					{ quality = 2; price = 200; };
	class rhsusf_opscore_mar_ut_pelt						{ quality = 2; price = 200; };
	class rhsusf_opscore_mar_ut								{ quality = 2; price = 200; };
	class rhsusf_opscore_mar_fg_pelt						{ quality = 2; price = 200; };
	class rhsusf_opscore_mar_fg								{ quality = 2; price = 200; };
	class rhsusf_protech_helmet								{ quality = 2; price = 200; };
	class rhsusf_protech_helmet_ess							{ quality = 2; price = 200; };
	class rhsusf_protech_helmet_rhino						{ quality = 2; price = 200; };
	class rhsusf_protech_helmet_rhino_ess					{ quality = 2; price = 200; };

	///////////////////////////////////////////////////////////////////////////////
	// Launcher
	///////////////////////////////////////////////////////////////////////////////
	//class rhs_weap_rpg26  							{ quality = 4; price = 6000; };
	class rhs_weap_rpg7  							{ quality = 4; price = 6000; };
	class rhs_weap_rshg2  							{ quality = 4; price = 6000; };
	class rhs_weap_igla 							{ quality = 4; price = 6000; };
	class rhs_weap_fgm148 							{ quality = 4; price = 6000; };
	class rhs_weap_fim92 							{ quality = 4; price = 6000; };
	class rhs_weap_M136 							{ quality = 4; price = 6000; };
	class rhs_weap_M136_hedp 						{ quality = 4; price = 6000; };
	class rhs_weap_M136_hp 							{ quality = 4; price = 6000; };
	class rhs_weap_m72a7 							{ quality = 4; price = 6000; };
	class rhs_weap_smaw 							{ quality = 4; price = 6000; };
	class rhs_weap_smaw_green 						{ quality = 4; price = 6000; };

	///////////////////////////////////////////////////////////////////////////////
	// Launcher Ammo
	///////////////////////////////////////////////////////////////////////////////
	//class rhs_rpg26_mag								{ quality = 2; price = 1000; };
	class rhs_rshg2_mag								{ quality = 2; price = 1000; };
	class rhs_rpg18_mag								{ quality = 2; price = 1000; };
	class rhs_rpg7_PG7VL_mag						{ quality = 2; price = 1000; };
	class rhs_rpg7_PG7VR_mag						{ quality = 2; price = 1000; };
	class rhs_rpg7_TBG7V_mag						{ quality = 2; price = 1000; };
	class rhs_rpg7_OG7V_mag							{ quality = 2; price = 1000; };
	class rhs_mag_9k32_rocket						{ quality = 2; price = 1000; };
	class rhs_mag_9k38_rocket						{ quality = 2; price = 1000; };
	// Added by ElShotte
	class rhs_rpg7_type69_airburst_mag 				{ quality = 2; price = 1000; };
	class rhs_fgm148_magazine_AT 					{ quality = 2; price = 1000; };
	class rhs_fim92_mag 							{ quality = 2; price = 1000; };
	class rhs_m136_mag 								{ quality = 2; price = 1000; };
	class rhs_m136_hedp_mag 						{ quality = 2; price = 1000; };
	class rhs_M136_hp_mag 							{ quality = 2; price = 1000; };
	class rhs_m72a7_mag 							{ quality = 2; price = 1000; };
	class rhs_mag_smaw_HEAA 						{ quality = 2; price = 1000; };
	class rhs_mag_smaw_HEDP 						{ quality = 2; price = 1000; };
	class rhs_mag_smaw_SR 							{ quality = 2; price = 1000; };

	

	///////////////////////////////////////////////////////////////////////////////
	// Unerbarrel GL Ammunition
	///////////////////////////////////////////////////////////////////////////////
	// Added by ElShotte
	class rhs_mag_M433_HEDP								{ quality = 4; price = 50; };
	class rhs_mag_M397_HET								{ quality = 4; price = 50; };
	class rhs_mag_m4009									{ quality = 4; price = 50; };
	class rhs_mag_m576									{ quality = 4; price = 50; };
	class rhs_mag_M585_white							{ quality = 4; price = 50; };
	class rhs_mag_m661_green							{ quality = 4; price = 50; };
	class rhs_mag_m662_red								{ quality = 4; price = 50; };
	class rhs_mag_m713_Red								{ quality = 4; price = 50; };
	class rhs_mag_m714_White							{ quality = 4; price = 50; };
	class rhs_mag_m715_Green							{ quality = 4; price = 50; };
	class rhs_mag_m716_yellow							{ quality = 4; price = 50; };
	class rhs_VOG25										{ quality = 4; price = 50; };
	class rhs_VOG25p									{ quality = 4; price = 50; };
	class rhs_vg40tb									{ quality = 4; price = 50; };
	class rhs_vg40sz									{ quality = 4; price = 50; };
	class rhs_vg40op_white								{ quality = 4; price = 50; };
	class rhs_vg40op_green								{ quality = 4; price = 50; };
	class rhs_vg40op_red								{ quality = 4; price = 50; };
	class rhs_GRD40_white								{ quality = 4; price = 50; };
	class rhs_GRD40_green								{ quality = 4; price = 50; };
	class rhs_GRD40_red									{ quality = 4; price = 50; };
	class rhs_VG40MD_White								{ quality = 4; price = 50; };
	class rhs_VG40MD_Green								{ quality = 4; price = 50; };
	class rhs_VG40MD_Red								{ quality = 4; price = 50; };
	class rhs_GDM40										{ quality = 4; price = 50; };
	class rhsusf_20Rnd_762x51_SR25_m118_special_Mag     { quality = 0; price = 50; };
	class rhsusf_20Rnd_762x51_SR25_mk316_special_Mag    { quality = 0; price = 50; };  
	class rhsusf_20Rnd_762x51_SR25_m993_Mag             { quality = 0; price = 50; };
	class rhsusf_20Rnd_762x51_SR25_m62_Mag              { quality = 0; price = 50; };
	
    ///////////////////////////////////////////////////////////////////////////////
	//RHS VEHICLES 
	///////////////////////////////////////////////////////////////////////////////

	///////////////////////////////////////////////////////////////////////////////
	// GAZ-66
	//////////////////////////////////////////////////////////////////////////////
	class rhs_gaz66_vmf 							{ quality = 2; price = 18250; };
	class rhs_gaz66_vv 								{ quality = 2; price = 18250; };
	class rhs_gaz66_msv 							{ quality = 2; price = 18250; };
	class rhs_gaz66_r142_vmf						{ quality = 2; price = 18250; };
	class rhs_gaz66_r142_msv						{ quality = 2; price = 18250; };
	class rhs_gaz66_r142_vv							{ quality = 2; price = 18250; };
	class rhs_gaz66_repair_vmf						{ quality = 2; price = 20000; };
	class rhs_gaz66_repair_vv						{ quality = 2; price = 20000; };
	class rhs_gaz66_repair_msv						{ quality = 2; price = 20000; };
	class rhs_gaz66_ammo_vmf 						{ quality = 2; price = 30000; };
	class rhs_gaz66_flat_vmf						{ quality = 2; price = 18250; };
	class rhs_gaz66_flat_vv							{ quality = 2; price = 18250; };
	class rhs_gaz66_flat_msv						{ quality = 2; price = 18250; };
	class rhs_gaz66o_vmf							{ quality = 2; price = 18250; };
	class rhs_gaz66o_vv								{ quality = 2; price = 18250; };
	class rhs_gaz66o_msv							{ quality = 2; price = 18250; };
	class rhs_gaz66o_flat_vmf						{ quality = 2; price = 18250; };
	class rhs_gaz66o_flat_vv						{ quality = 2; price = 18250; };
	class rhs_gaz66o_flat_msv						{ quality = 2; price = 18250; };

	///////////////////////////////////////////////////////////////////////////////
	// HMVE
	//////////////////////////////////////////////////////////////////////////////
	class rhsusf_m1025_w							{ quality = 2; price = 16000; };
	class rhsusf_m1025_d							{ quality = 2; price = 16000; };
	class rhsusf_m1025_w_m2							{ quality = 2; price = 20000; };
	class rhsusf_m998_w_2dr							{ quality = 2; price = 15000; };
	class rhsusf_m998_w_4dr							{ quality = 2; price = 15000; sellPrice = 100; };
	class rhsusf_m998_w_s_2dr_fulltop				{ quality = 2; price = 19000; };
	class rhsusf_m998_d_s_2dr_fulltop				{ quality = 2; price = 19000; };
	class rhsusf_m998_w_s_2dr_halftop				{ quality = 2; price = 19000; };
	class rhsusf_m998_d_s_2dr_halftop				{ quality = 2; price = 19000; };
	class rhsusf_m998_d_s_4dr_fulltop				{ quality = 2; price = 19000; };
	class rhsusf_m998_w_s_4dr_fulltop				{ quality = 2; price = 19000; };
	class rhsusf_m998_d_s_4dr_halftop				{ quality = 2; price = 19000; };
	class rhsusf_m998_w_s_4dr_halftop				{ quality = 2; price = 19000; };
	class rhsusf_m1025_w_s_m2             		  	{ quality = 2; price = 35000; }; 

	///////////////////////////////////////////////////////////////////////////////
	// M1078A1P2
	//////////////////////////////////////////////////////////////////////////////
	class rhsusf_M1078A1P2_wd_fmtv_usarmy			{ quality = 2; price = 19500; sellPrice = 14000; };
	class rhsusf_M1078A1P2_d_fmtv_usarmy			{ quality = 2; price = 19500; };
	class rhsusf_M1078A1P2_wd_open_fmtv_usarmy		{ quality = 2; price = 19500; };
	class rhsusf_M1078A1P2_d_open_fmtv_usarmy		{ quality = 2; price = 19500; };
	class rhsusf_M1078A1P2_wd_flatbed_fmtv_usarmy	{ quality = 2; price = 19500; };
	class rhsusf_M1078A1P2_d_flatbed_fmtv_usarmy	{ quality = 2; price = 19500; };
	class rhsusf_M1078A1P2_B_d_fmtv_usarmy			{ quality = 2; price = 19000; };
	class rhsusf_M1078A1P2_B_wd_fmtv_usarmy			{ quality = 2; price = 19000; };
	class rhsusf_M1078A1P2_B_wd_open_fmtv_usarmy	{ quality = 2; price = 19500; };
	class rhsusf_M1078A1P2_B_d_open_fmtv_usarmy		{ quality = 2; price = 19500; };
	class rhsusf_M1078A1P2_B_wd_flatbed_fmtv_usarmy	{ quality = 2; price = 19500; };
	class rhsusf_M1078A1P2_B_d_flatbed_fmtv_usarmy	{ quality = 2; price = 19500; };
	class rhsusf_M1083A1P2_B_M2_d_MHQ_fmtv_usarmy	{ quality = 2; price = 19500; };
	class rhsusf_M1083A1P2_B_M2_d_Medical_fmtv_usarmy	{ quality = 2; price = 19500; };

	///////////////////////////////////////////////////////////////////////////////
	// UAZ
	//////////////////////////////////////////////////////////////////////////////
	class rhs_uaz_vmf 								{ quality = 1; price = 32000; sellprice = 10000; };
	class rhs_uaz_open_vmf	 						{ quality = 1; price = 30000; };

	///////////////////////////////////////////////////////////////////////////////
	// URAL
	//////////////////////////////////////////////////////////////////////////////
	class RHS_Ural_Open_Civ_01						{ quality = 2; price = 30000; };
	class RHS_Ural_Open_Civ_02						{ quality = 2; price = 30000; };
	class RHS_Ural_Open_Civ_03						{ quality = 2; price = 30000; };
	class RHS_Ural_Open_MSV_01						{ quality = 2; price = 30000; };
	class RHS_Ural_Open_VMF_01						{ quality = 2; price = 30000; };
	class RHS_Ural_Open_VV_01						{ quality = 2; price = 30000; };
	class RHS_Ural_MSV_01							{ quality = 2; price = 30000; };
	class RHS_Ural_VMF_01							{ quality = 2; price = 30000; };
	class RHS_Ural_VV_01							{ quality = 2; price = 30000; };
	class RHS_Ural_Open_Flat_MSV_01					{ quality = 1; price = 39000; };
	class RHS_Ural_Open_Flat_VDV_01					{ quality = 2; price = 39000; };
	class RHS_Ural_Open_Flat_VMF_01					{ quality = 2; price = 39000; };
	class RHS_Ural_Open_Flat_VV_01					{ quality = 2; price = 39000; };
	class RHS_Ural_Fuel_MSV_01						{ quality = 2; price = 39000; };
	class RHS_Ural_Fuel_VMF_01						{ quality = 2; price = 39000; };
	class RHS_Ural_Fuel_VV_01						{ quality = 2; price = 39000; };
	class RHS_Ural_Flat_MSV_01 						{ quality = 2; price = 28000; };
	class RHS_Ural_Flat_VDV_01 						{ quality = 2; price = 28000; };
	class RHS_Ural_Flat_VMF_01 						{ quality = 2; price = 28000; };
	class RHS_Ural_Flat_VV_01 						{ quality = 2; price = 28000; };

	///////////////////////////////////////////////////////////////////////////////
	// TRACKED
	//////////////////////////////////////////////////////////////////////////////
	class rhsusf_rg33_d         				    { quality = 4; price = 70000; sellprice = 30000; };
	class rhsusf_rg33_wd         				    { quality = 4; price = 70000; };
	class rhsusf_rg33_m2_d         				    { quality = 4; price = 70000; };
	class rhsusf_rg33_m2_wd         				{ quality = 4; price = 70000; };
	class rhsusf_rg33_usmc_d         				{ quality = 4; price = 70000; };
	class rhsusf_rg33_usmc_wd         				{ quality = 4; price = 70000; };
	class rhsusf_rg33_m2_usmc_d         			{ quality = 4; price = 70000; sellprice = 25000; };
	class rhsusf_rg33_m2_usmc_wd         			{ quality = 4; price = 70000; };
	class rhsusf_m113_usarmy_unarmed 				{ quality = 4; price = 51000; sellprice = 12000; };
	
	class RHS_Ural_Zu23_MSV_01						{ quality = 5; price = 100000; sellPrice = 40000; };
	
	///////////////////////////////////////////////////////////////////////////////
	//Tochka U
	///////////////////////////////////////////////////////////////////////////////
	//class rhs_9k79_B								{ quality = 6; price = 110000; };
	//class rhs_9k79_K					            { quality = 6; price = 110000; };
	//class rhs_9k79									{ quality = 6; price = 110000; };

	///////////////////////////////////////////////////////////////////////////////
	// CH-47
	//////////////////////////////////////////////////////////////////////////////
	class RHS_CH_47F_10					            { quality = 3; price = 110000; };
	///////////////////////////////////////////////////////////////////////////////
	//CH-53
	////////////////////////////////////////////////////////////////////////////////
	//class rhsusf_CH53E_USMC							{ quality = 6; price = 60000; };
	///////////////////////////////////////////////////////////////////////////////
	// UH-60M
	//////////////////////////////////////////////////////////////////////////////
	class RHS_UH60M              				    { quality = 3; price = 400000; };
	class RHS_UH60M_MEV         				    { quality = 3; price = 600000; };
	class RHS_UH60M_d         				    	{ quality = 3; price = 1400000; };

	///////////////////////////////////////////////////////////////////////////////
	// Mi8
	//////////////////////////////////////////////////////////////////////////////
	class RHS_Mi8mt_vv					        	{ quality = 3; price = 890000; };
	class RHS_Mi8AMT_vvs					        { quality = 3; price = 890000; };
	class RHS_Mi8AMT_vvsc					        { quality = 3; price = 890000; };
	class RHS_Mi8AMT_vdv					        { quality = 3; price = 890000; };
	class RHS_Mi8mt_Cargo_vvs 						{ quality = 3; price = 890000; };
	class RHS_Mi8mt_Cargo_vvsc 						{ quality = 3; price = 890000; };
	class RHS_Mi8mt_Cargo_vdv					    { quality = 3; price = 890000; };
	class RHS_Mi8mt_Cargo_vv 						{ quality = 3; price = 890000; };
	class RHS_Mi8amt_civilian					    { quality = 3; price = 700000; };
	class RHS_MI8MTV3_UPK23_vvsc		     	    { quality = 4; price = 1900000; };
	class RHS_MI8MTV3_UPK23_vvs				        { quality = 4; price = 1900000; };
	class RHS_Mi8MTV3_UPK23_vdv					    { quality = 4; price = 1900000; };
	class RHS_Mi8AMTSh_UPK23_vvs				    { quality = 4; price = 1900000; };
	class RHS_Mi8AMTSh_UPK23_vvsc				    { quality = 4; price = 1900000; };
	class RHS_Mi8MTV3_FAB_vvs					    { quality = 4; price = 2000000; };
	class RHS_Mi8MTV3_FAB_vvsc					    { quality = 4; price = 2000000; };
	class RHS_Mi8MTV3_FAB_vdv					    { quality = 4; price = 2000000; };
	class RHS_Mi8AMTSh_FAB_vvs					    { quality = 4; price = 2000000; };
	class RHS_Mi8AMTSh_FAB_vvsc					    { quality = 4; price = 2000000; };

	///////////////////////////////////////////////////////////////////////////////
	// UH1Y
	//////////////////////////////////////////////////////////////////////////////
	class rhs_UH1Y_unarmed 							{ quality = 3; price = 680000; };
	class RHS_UH1Y_UNARMED_d						{ quality = 3; price = 680000; };
	class RHS_UH1Y_d						        { quality = 4; price = 850000; };
	class RHS_UH1Y_FFAR						        { quality = 4; price = 1400000; };
	class RHS_UH1Y_FFAR_d						    { quality = 4; price = 1400000; };

	///////////////////////////////////////////////////////////////////////////////
	// Planes
	//////////////////////////////////////////////////////////////////////////////
	class RHS_C130J 								{ quality = 3; price = 600000; };
	class JS_JC_SU35 								{ quality = 8; price = 8000000; };
	
	
	//////////////////////////////////////////////////////////////////////////////////
	//Static MG
	//////////////////////////////////////////////////////////////////////////////////

	class I_mas_DSHkM_Mini_TriPod					{ quality = 1; price = 12000; };
	class I_mas_KORD_AAF							{ quality = 1; price = 15000; };
	class I_mas_M2StaticMG_MiniTripod_AAF			{ quality = 1; price = 10000; };
	////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////
	class RHS_MELB_AH6M_M    						{ quality = 5; price = 100000; };
	class RHS_MELB_AH6M_L                   		{ quality = 5; price = 100000; };
	class RHS_MELB_AH6M_H                   		{ quality = 5; price = 100000; };
	
	///////////////////////////////////////////////////////////////////////////////////
	class RHS_TU95MS_vvs_old                   		{ quality = 7; price = 150000; };
	class RHS_TU95MS_vvs_dubna                		{ quality = 7; price = 150000; };
	class RHS_TU95MS_vvs_irkutsk              		{ quality = 7; price = 150000; };
	class RHS_TU95MS_vvs_tambov               		{ quality = 7; price = 150000; };
	class RHS_TU95MS_vvs_chelyabinsk          		{ quality = 7; price = 150000; };
	////////////////////////////////////////////////////////////////////////////////////
	class rhsusf_mrzr4_d_mud		     			{ quality = 1; price = 10000; sellPrice = 100;};
	////////////////////////////////////////////////////////////////////////////////////
	class rhsusf_M1232_usarmy_d           		    { quality = 4; price = 80000; };       
	class rhsusf_M1232_usarmy_wd          		    { quality = 4; price = 80000; };
	///////////////////////////////////////////////////////////////////////////////////
	class rhsusf_M977A4_usarmy_wd                   { quality = 3; price = 60000; }; 
	class rhsusf_M977A4_usarmy_d                    { quality = 3; price = 60000; };                                        
	class rhsusf_M978A4_BKIT_usarmy_wd              { quality = 3; price = 60000; };
	//////////////////////////////////////////////////////////////////////////////////
	//class rhs_D30_msv                             { quality = 8; price = 750000; }; // D 30
	//class CUP_B_D30_CDF                           { quality = 8; price = 750000; }; // D 30
 
	//***************************************
	// Mammont
	class HTNK                                     { quality = 7; price = 50000000; sellPrice = 80000;  };
	class HTNK_Ghex                                { quality = 7; price = 50000000; sellPrice = 80000;  };
	class HTNK_Green                               { quality = 7; price = 50000000; sellPrice = 80000;  };
	class HTNK_SLA                                 { quality = 7; price = 50000000; sellPrice = 80000;  };
	class HTNK_Grey                                { quality = 7; price = 50000000; sellPrice = 80000;  };
	class HTNK_Desert                              { quality = 7; price = 50000000; sellPrice = 80000;  };
	class HTNK_Snow                                { quality = 7; price = 50000000; sellPrice = 80000;  };
	class HTNK_Nato                                { quality = 7; price = 50000000; sellPrice = 80000;  };
	class HTNK_Nato_Pacific                        { quality = 7; price = 50000000; sellPrice = 80000;  };
	class HTNK_Gdi                                 { quality = 7; price = 50000000; sellPrice = 80000;  };
	class HTNK_us_woodland                         { quality = 7; price = 50000000; sellPrice = 80000;  };
	class HTNK_us_desert                           { quality = 7; price = 50000000; sellPrice = 80000;  };
	class HTNK_us_snow                             { quality = 7; price = 50000000; sellPrice = 80000;  };
	
	class CUP_I_AAV_RACS                    { quality = 4; price = 95000; }; 
	class CUP_B_AAV_Unarmed_USMC			{ quality = 4; price = 85000; };
	class CUP_C_S1203_CIV					{ quality = 1; price = 10000; sellPrice = 8000; };
	class CUP_B_Challenger2_2CD_BAF			{ quality = 7; price = 760000; };
	class CUP_B_Challenger2_2CS_BAF			{ quality = 7; price = 760000; };
	class CUP_B_M1A1_Woodland_USMC          { quality = 7; price = 900000; };
	class CUP_B_M1A1_DES_USMC               { quality = 7; price = 900000; };


    //law of wars cars
	class I_G_Van_02_vehicle_F				{ quality = 2; price = 35000; };
	class B_G_Van_02_vehicle_F				{ quality = 2; price = 35000; };
	class I_G_Van_02_transport_F			{ quality = 2; price = 35000; };

    //law of wars vetsts
	class V_EOD_blue_F						{ quality = 2; price = 300; };
	class V_EOD_IDAP_blue_F					{ quality = 2; price = 300; };
	class V_EOD_coyote_F					{ quality = 2; price = 300; };
	class V_EOD_olive_F						{ quality = 2; price = 300; };	
	class V_Plain_crystal_F					{ quality = 2; price = 300; };
	class V_Plain_medical_F					{ quality = 2; price = 300; };
	class V_LegStrapBag_black_F				{ quality = 2; price = 300; };
	class V_LegStrapBag_coyote_F			{ quality = 2; price = 300; };
	class V_Pocketed_black_F				{ quality = 2; price = 300; };
	class V_Pocketed_coyote_F				{ quality = 2; price = 300; };
	class V_Pocketed_olive_F				{ quality = 2; price = 300; };
	class V_Safety_blue_F					{ quality = 2; price = 300; };
	class V_Safety_orange_F					{ quality = 2; price = 300; };
	class V_Safety_yellow_F					{ quality = 2; price = 300; };

    // law of wars uniforms
	class U_C_IDAP_Man_cargo_F				{ quality = 2; price = 300; };
	class U_C_IDAP_Man_Jeans_F				{ quality = 2; price = 300; };
	class U_C_IDAP_Man_casual_F				{ quality = 2; price = 300; };
	class U_C_IDAP_Man_shorts_F				{ quality = 2; price = 300; };
	class U_C_IDAP_Man_Tee_F				{ quality = 2; price = 300; };
	class U_C_IDAP_Man_TeeShorts_F			{ quality = 2; price = 300; };
	class U_C_ConstructionCoverall_Black_F	{ quality = 2; price = 300; };
	class U_C_ConstructionCoverall_Blue_F	{ quality = 2; price = 300; };
	class U_C_ConstructionCoverall_Red_F	{ quality = 2; price = 300; };
	class U_C_ConstructionCoverall_Vrana_F	{ quality = 2; price = 300; };
	class U_BG_Guerilla1_2_F				{ quality = 2; price = 300; };
	class U_C_Mechanic_01_F					{ quality = 2; price = 300; };
	class U_C_Paramedic_01_F				{ quality = 2; price = 300; };
	
    //law of wars head
	class H_PASGT_basic_blue_F				{ quality = 2; price = 200; };
	class H_PASGT_basic_olive_F				{ quality = 2; price = 200; };
	class H_PASGT_basic_white_F				{ quality = 2; price = 200; };
	class H_Construction_basic_orange_F		{ quality = 2; price = 200; };
	class H_Construction_earprot_orange_F	{ quality = 2; price = 200; };
	class H_Construction_headset_orange_F	{ quality = 2; price = 200; };
	class H_Construction_basic_red_F		{ quality = 2; price = 200; };
	class H_Construction_earprot_red_F		{ quality = 2; price = 200; };
	class H_Construction_basic_vrana_F		{ quality = 2; price = 200; };
	class H_Construction_earprot_vrana_F	{ quality = 2; price = 200; };
	class H_Construction_headset_vrana_F	{ quality = 2; price = 200; };
	class H_Construction_earprot_white_F	{ quality = 2; price = 200; };
	class H_Construction_basic_yellow_F		{ quality = 2; price = 200; };
	class H_Construction_earprot_yellow_F	{ quality = 2; price = 200; };
	class H_HeadBandage_clean_F				{ quality = 2; price = 200; };
	class H_HeadBandage_stained_F			{ quality = 2; price = 200; };
	class H_HeadBandage_bloody_F			{ quality = 2; price = 200; };
	class H_PASGT_basic_blue_press_F		{ quality = 2; price = 200; };
	class H_PASGT_neckprot_blue_press_F		{ quality = 2; price = 200; };
	class H_Hat_Safari_sand_F				{ quality = 2; price = 200; };
    //low of wars access
	class G_Respirator_blue_F				{ quality = 2; price = 100; };
	class G_Respirator_white_F				{ quality = 2; price = 100; };
	class G_Respirator_yellow_F				{ quality = 2; price = 100; };
	class G_EyeProtectors_F					{ quality = 2; price = 100; };
	class G_EyeProtectors_Earpiece_F		{ quality = 2; price = 100; };

	///////////////////////////////////////////////////////////////////////////////
	//	awc
	///////////////////////////////////////////////////////////////////////////////
	class I_LT_01_scout_F					{ quality = 5; price = 600000; };

	///////////////////////////////////////////////////////////////////////////////
	//	tankdlcclothing
	///////////////////////////////////////////////////////////////////////////////
	class H_Tank_black_F					{ quality = 3; price = 500; };
	class U_Tank_green_F					{ quality = 3; price = 1000; };
	
	///////////////////////////////////////////////////////////////////////////////	
	//	tankdlclaunchers
	///////////////////////////////////////////////////////////////////////////////	
	class launch_MRAWS_green_F				{ quality = 7; price = 10000; sellPrice = 5000; };
	class launch_MRAWS_green_rail_F			{ quality = 7; price = 10000; sellPrice = 5000; };
	class launch_MRAWS_olive_F				{ quality = 7; price = 10000; sellPrice = 5000; };
	class launch_MRAWS_olive_rail_F			{ quality = 7; price = 10000; sellPrice = 5000; };
	class launch_MRAWS_sand_F				{ quality = 7; price = 10000; sellPrice = 5000; };
	class launch_MRAWS_sand_rail_F			{ quality = 7; price = 10000; sellPrice = 5000; };
	/////VORONA
	class launch_O_Vorona_brown_F			{ quality = 7; price = 30000; sellPrice = 15000; };
	class launch_O_Vorona_green_F			{ quality = 7; price = 30000; sellPrice = 15000; };

	///////////////////////////////////////////////////////////////////////////////	
	//	tankdlclauncherammo
	///////////////////////////////////////////////////////////////////////////////	
	class MRAWS_HEAT_F						{ quality = 7; price = 1500; };
	class MRAWS_HE_F 						{ quality = 7; price = 1500; };
	//////VORONA
	class Vorona_HEAT						{ quality = 7; price = 1500; };
	class Vorona_HE 						{ quality = 7; price = 1500; };
	
	///////////////////////////////////////////////////////////////////////////////
	class O_T_APC_Wheeled_02_rcws_ghex_F                { quality = 5; price = 400000; };
	class O_APC_Wheeled_02_rcws_F                       { quality = 5; price = 400000; };
	class B_APC_Wheeled_03_cannon_F                     { quality = 6; price = 450000; };
	class O_LSV_02_unarmed_F                            { quality = 4; price = 40000; }; 
	
	///////////////////////////////////////////////////////////////////////////////
	// Diving
	///////////////////////////////////////////////////////////////////////////////
	class G_B_Diving			 	        { quality = 2; price = 1000; };
	class G_O_Diving			 	        { quality = 2; price = 1000; };
	class G_I_Diving			 	        { quality = 2; price = 1000; };
    class U_I_Wetsuit						{ quality = 2; price = 3000; };
	class U_O_Wetsuit						{ quality = 2; price = 3000; };
	class U_B_Wetsuit						{ quality = 2; price = 3000; };
    class V_RebreatherB						{ quality = 2; price = 5000; };
	class V_RebreatherIA					{ quality = 2; price = 5000; };
	class V_RebreatherIR					{ quality = 2; price = 5000; };
	
	class Exile_Headgear_GasMask			{ quality = 3; price = 5000; };
	
	//events
	class CUP_item_Money					{ quality = 1; price = 0; sellprice = 10000; };
	
	//EBM BLACKMARKET
	class EBM_Backpack_dev					{ quality = 6; price = 120000; sellprice = 1; };
	
	////////////////////////////////////////////////////////////////////////////////////
	// Стационарное
	////////////////////////////////////////////////////////////////////////////////////
	class RHS_NSV_Gun_Bag                   { quality = 6; price = 50000; };
    class RHS_NSV_Tripod_Bag                { quality = 6; price = 1000; };    //Пулемёт
	
	class I_E_HMG_02_high_weapon_F          { quality = 6; price = 50000; };
	class I_E_HMG_02_support_high_F         { quality = 6; price = 1000; };    //Пулемёт

    class RHS_DShkM_Gun_Bag                 { quality = 6; price = 50000; };
    class RHS_DShkM_TripodHigh_Bag          { quality = 6; price = 1000; };
    class RHS_DShkM_TripodLow_Bag           { quality = 6; price = 1000; };    //Пулемёт
    
    class RHS_Kord_Gun_Bag                  { quality = 6; price = 50000; };
    class RHS_Kord_Tripod_Bag               { quality = 6; price = 1000; };   //Пумемёт
    
    class RHS_Metis_Gun_Bag                 { quality = 7; price = 60000; };
    class RHS_Metis_Tripod_Bag              { quality = 7; price = 1500; };    //ТОУ
    
    class RHS_Kornet_Gun_Bag                { quality = 7; price = 65000; };
    class RHS_Kornet_Tripod_Bag             { quality = 7; price = 1500; };    //ТОУ +    
    
    class RHS_AGS30_Gun_Bag                 { quality = 7; price = 80000; };
    class RHS_AGS30_Tripod_Bag              { quality = 7; price = 1500; };    //АГС
    
    class RHS_SPG9_Gun_Bag                  { quality = 7; price = 45000; };
    class RHS_SPG9_Tripod_Bag               { quality = 7; price = 1500; };    //СПГ
    
    class RHS_Podnos_Gun_Bag                { quality = 7; price = 3000000; sellprice = 300000; };  
    class RHS_Podnos_Bipod_Bag              { quality = 7; price = 2000; };   //Миномёт
	
	class B_AA_01_weapon_F                  { quality = 7; price = 80000; };  //titan
	class B_HMG_01_support_F                { quality = 7; price = 2000; };
    
    class RHS_M2_Gun_Bag                    { quality = 7; price = 50000; };
    class RHS_M2_Tripod_Bag                 { quality = 7; price = 1000; };  //пулемёт
    class RHS_M2_MiniTripod_Bag             { quality = 6; price = 1000; };
    
    class RHS_Mk19_Gun_Bag                  { quality = 7; price = 80000; };
    class RHS_Mk19_Tripod_Bag               { quality = 7; price = 1500; };  //АГС
    
    class rhs_Tow_Gun_Bag                   { quality = 7; price = 65000; }; 
    class rhs_TOW_Tripod_Bag                { quality = 7; price = 1500; };  //ТОУ +
    
    class rhs_M252_Gun_Bag                  { quality = 7; price = 3000000; sellprice = 30000; };
    class rhs_M252_Bipod_Bag                { quality = 7; price = 2000; };  //Миномёт