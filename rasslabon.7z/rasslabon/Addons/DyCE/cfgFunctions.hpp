class DyCE
{
	class functions
	{
		file = "addons\DyCE\functions";
		class preInit
		{
			preInit = 1;
		};
		class postInit
		{
			postInit = 1;
		};
		class convoyController{};
		class spawnConvoy{};
		class spawnConvoyAI{};
		
		class addWaypoint{};
		class addWaypointGetIn{};
		class clearWaypoints{};
		class playerGetIn{};
		class repairVehicle{};
		class aiHeal{};
	};
};


